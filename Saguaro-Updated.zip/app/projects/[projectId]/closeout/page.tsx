'use client';
import React, { useState } from 'react';
import { useParams } from 'next/navigation';

const GOLD='#D4A017',DARK='#0d1117',RAISED='#1f2c3e',BORDER='#263347',DIM='#8fa3c0',TEXT='#e8edf8',GREEN='#22c55e',RED='#ef4444',YELLOW='#f59e0b';

type ItemStatus = 'complete'|'pending'|'missing';
interface ChecklistItem { id:string; category:string; item:string; status:ItemStatus; required:boolean; notes?:string; }

const INITIAL_CHECKLIST:ChecklistItem[] = [
  // AIA Documents
  {id:'g702',category:'AIA Documents',item:'Final Pay Application (G702/G703)',status:'complete',required:true},
  {id:'g704',category:'AIA Documents',item:'Certificate of Substantial Completion (G704)',status:'pending',required:true},
  {id:'g706',category:'AIA Documents',item:"Contractor's Affidavit of Payment (G706)",status:'missing',required:true},
  // Lien Waivers
  {id:'lw1',category:'Lien Waivers',item:'Unconditional Final — ABC Electrical Inc.',status:'complete',required:true},
  {id:'lw2',category:'Lien Waivers',item:'Unconditional Final — Southwest Plumbing Co.',status:'pending',required:true},
  {id:'lw3',category:'Lien Waivers',item:'Unconditional Final — Desert HVAC Solutions',status:'missing',required:true},
  {id:'lw4',category:'Lien Waivers',item:'Unconditional Final — SunState Concrete',status:'complete',required:true},
  {id:'lw5',category:'Lien Waivers',item:'Unconditional Final — Ironclad Steel Erectors',status:'complete',required:true},
  // Warranties
  {id:'w1',category:'Warranties & Manuals',item:'1-Year General Contractor Warranty',status:'pending',required:true},
  {id:'w2',category:'Warranties & Manuals',item:'Roofing Warranty (20-year)',status:'missing',required:true},
  {id:'w3',category:'Warranties & Manuals',item:'HVAC Equipment Warranties',status:'pending',required:true},
  {id:'w4',category:'Warranties & Manuals',item:'HVAC Operation & Maintenance Manuals',status:'missing',required:false},
  {id:'w5',category:'Warranties & Manuals',item:'Electrical Panel Schedules',status:'complete',required:true},
  // As-Builts
  {id:'ab1',category:'As-Built Drawings',item:'Architectural As-Builts',status:'pending',required:true},
  {id:'ab2',category:'As-Built Drawings',item:'Structural As-Builts',status:'missing',required:true},
  {id:'ab3',category:'As-Built Drawings',item:'MEP (Mechanical/Electrical/Plumbing) As-Builts',status:'missing',required:true},
  // Safety
  {id:'sf1',category:'Safety & Compliance',item:'OSHA 300 Log — Final Year',status:'complete',required:true},
  {id:'sf2',category:'Safety & Compliance',item:'Signed Punch List — All Items Resolved',status:'pending',required:true},
  // Turnover
  {id:'t1',category:'Owner Turnover',item:'Keys, Access Cards & Fobs',status:'missing',required:true},
  {id:'t2',category:'Owner Turnover',item:'Alarm Codes & Security System',status:'missing',required:true},
  {id:'t3',category:'Owner Turnover',item:'Utility Accounts Transfer',status:'missing',required:false},
  {id:'t4',category:'Owner Turnover',item:'Certificate of Occupancy',status:'complete',required:true},
];

function StatusIcon({status}:{status:ItemStatus}){
  if(status==='complete') return <span style={{fontSize:16}}>✅</span>;
  if(status==='pending') return <span style={{fontSize:16}}>⏳</span>;
  return <span style={{fontSize:16}}>❌</span>;
}

export default function CloseoutPage(){
  const {projectId} = useParams() as {projectId:string};
  const [items, setItems] = useState<ChecklistItem[]>(INITIAL_CHECKLIST);
  const [generating, setGenerating] = useState(false);

  const categories = [...new Set(items.map(i=>i.category))];
  const completeCount = items.filter(i=>i.status==='complete').length;
  const requiredItems = items.filter(i=>i.required);
  const requiredComplete = requiredItems.filter(i=>i.status==='complete').length;
  const allRequiredDone = requiredComplete === requiredItems.length;
  const pctComplete = Math.round((completeCount/items.length)*100);

  function toggleStatus(id:string){
    setItems(prev=>prev.map(item=>{
      if(item.id!==id) return item;
      const next:ItemStatus = item.status==='complete'?'missing':item.status==='missing'?'pending':'complete';
      return {...item,status:next};
    }));
  }

  async function generatePackage(){
    if(!allRequiredDone){ alert('Complete all required items before generating the closeout package.'); return; }
    setGenerating(true);
    try {
      const res = await fetch('/api/documents/closeout',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tenantId:'demo',projectId})});
      const d = await res.json();
      if(d.pdfUrl) window.open(d.pdfUrl,'_blank');
      else alert('Closeout package generated!\nIn production: Merged PDF with all documents, bookmarked sections, delivered to owner.');
    } catch(e){ alert('Error generating package.'); }
    setGenerating(false);
  }

  return (
    <div style={{padding:'28px 24px'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div>
          <h2 style={{margin:0,fontSize:20,fontWeight:800,color:TEXT}}>Project Closeout</h2>
          <div style={{fontSize:12,color:DIM,marginTop:3}}>Complete all items to generate the closeout package</div>
        </div>
        <button onClick={generatePackage} disabled={!allRequiredDone||generating}
          style={{padding:'10px 20px',background:allRequiredDone?`linear-gradient(135deg,${GOLD},#F0C040)`:'rgba(212,160,23,.3)',border:'none',borderRadius:8,color:'#0d1117',fontSize:13,fontWeight:800,cursor:allRequiredDone?'pointer':'not-allowed'}}>
          {generating?'Generating...':'📦 Generate Closeout Package'}
        </button>
      </div>

      {/* Progress bar */}
      <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,padding:'18px 20px',marginBottom:24}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
          <span style={{fontWeight:700,fontSize:14,color:TEXT}}>Closeout Progress</span>
          <span style={{fontWeight:800,fontSize:18,color:pctComplete===100?GREEN:GOLD}}>{pctComplete}%</span>
        </div>
        <div style={{background:DARK,borderRadius:8,height:12,overflow:'hidden',marginBottom:10}}>
          <div style={{width:`${pctComplete}%`,height:'100%',background:pctComplete===100?`linear-gradient(90deg,${GREEN},#16a34a)`:`linear-gradient(90deg,${GOLD},#F0C040)`,transition:'width .3s ease',borderRadius:8}}/>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12}}>
          {[
            {label:'Complete',value:completeCount,color:GREEN},
            {label:'Pending',value:items.filter(i=>i.status==='pending').length,color:YELLOW},
            {label:'Missing',value:items.filter(i=>i.status==='missing').length,color:RED},
          ].map(s=>(
            <div key={s.label} style={{textAlign:'center' as const}}>
              <div style={{fontSize:20,fontWeight:800,color:s.color}}>{s.value}</div>
              <div style={{fontSize:11,color:DIM}}>{s.label}</div>
            </div>
          ))}
        </div>
        {!allRequiredDone&&<div style={{marginTop:12,padding:'8px 12px',background:'rgba(239,68,68,.08)',border:'1px solid rgba(239,68,68,.2)',borderRadius:7,fontSize:11,color:RED}}>
          ⚠️ {requiredItems.length - requiredComplete} required items still missing. Complete all required items to generate the closeout package.
        </div>}
        {allRequiredDone&&<div style={{marginTop:12,padding:'8px 12px',background:'rgba(34,197,94,.08)',border:'1px solid rgba(34,197,94,.2)',borderRadius:7,fontSize:11,color:GREEN}}>
          ✅ All required items complete. Ready to generate closeout package.
        </div>}
      </div>

      {/* Checklist by category */}
      {categories.map(cat=>{
        const catItems = items.filter(i=>i.category===cat);
        const catComplete = catItems.filter(i=>i.status==='complete').length;
        return (
          <div key={cat} style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden',marginBottom:16}}>
            <div style={{padding:'12px 18px',borderBottom:`1px solid ${BORDER}`,background:'rgba(0,0,0,.2)',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <span style={{fontWeight:700,fontSize:13,color:TEXT}}>{cat}</span>
              <span style={{fontSize:12,color:catComplete===catItems.length?GREEN:DIM}}>{catComplete}/{catItems.length} complete</span>
            </div>
            {catItems.map(item=>(
              <div key={item.id} style={{padding:'12px 18px',borderBottom:`1px solid ${BORDER}`,display:'flex',alignItems:'center',gap:14}}>
                <button onClick={()=>toggleStatus(item.id)} style={{background:'none',border:'none',cursor:'pointer',fontSize:18,lineHeight:1,padding:0}}>
                  <StatusIcon status={item.status}/>
                </button>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,color:item.status==='complete'?TEXT:DIM,fontWeight:item.required?600:400,textDecoration:item.status==='complete'?'none':'none'}}>
                    {item.item}
                    {item.required&&<span style={{marginLeft:6,fontSize:9,background:'rgba(239,68,68,.15)',color:RED,padding:'1px 5px',borderRadius:3,fontWeight:700,letterSpacing:.5}}>REQUIRED</span>}
                  </div>
                </div>
                <div style={{display:'flex',gap:8}}>
                  {item.status!=='complete'&&(
                    <button onClick={()=>alert(`Uploading / generating: ${item.item}`)} style={{padding:'4px 10px',background:`rgba(212,160,23,.12)`,border:`1px solid rgba(212,160,23,.3)`,borderRadius:5,color:GOLD,fontSize:11,fontWeight:700,cursor:'pointer'}}>
                      {item.status==='missing'?'+ Add':'Upload'}
                    </button>
                  )}
                  {item.status==='complete'&&(
                    <button onClick={()=>alert(`Downloading: ${item.item}`)} style={{padding:'4px 10px',background:`rgba(34,197,94,.12)`,border:`1px solid rgba(34,197,94,.3)`,borderRadius:5,color:GREEN,fontSize:11,cursor:'pointer'}}>Download</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}
