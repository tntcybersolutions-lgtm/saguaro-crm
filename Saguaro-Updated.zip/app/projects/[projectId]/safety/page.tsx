'use client';
import React, { useState } from 'react';
import { useParams } from 'next/navigation';

const GOLD='#D4A017',DARK='#0d1117',RAISED='#1f2c3e',BORDER='#263347',DIM='#8fa3c0',TEXT='#e8edf8',GREEN='#22c55e',RED='#ef4444',YELLOW='#f59e0b';

interface Incident { id:string; case_no:number; employee_name:string; job_title:string; date_of_injury:string; location:string; description:string; classification:string; days_away:number; days_restricted:number; }

const CLASSIFICATIONS = ['Death','Days Away From Work','Job Transfer or Restriction','Other Recordable Cases','First Aid Only (Not Recordable)'];

const INITIAL_INCIDENTS:Incident[] = [
  {id:'i1',case_no:1,employee_name:'Marcus Johnson',job_title:'Laborer',date_of_injury:'2026-01-12',location:'Building A — Foundation',description:'Slip on wet concrete, lower back strain',classification:'Days Away From Work',days_away:4,days_restricted:0},
  {id:'i2',case_no:2,employee_name:'Carlos Rivera',job_title:'Ironworker',date_of_injury:'2026-02-08',location:'Level 3 — Steel Erection',description:'Minor laceration to left hand from steel edge',classification:'First Aid Only (Not Recordable)',days_away:0,days_restricted:0},
];

export default function SafetyPage(){
  const {projectId} = useParams() as {projectId:string};
  const [incidents, setIncidents] = useState<Incident[]>(INITIAL_INCIDENTS);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<Partial<Incident>>({date_of_injury:new Date().toISOString().slice(0,10),days_away:0,days_restricted:0,classification:'Other Recordable Cases'});

  const recordable = incidents.filter(i=>!i.classification.includes('First Aid'));
  const deaths = incidents.filter(i=>i.classification==='Death').length;
  const daysAway = incidents.filter(i=>i.classification==='Days Away From Work').length;
  const restricted = incidents.filter(i=>i.classification==='Job Transfer or Restriction').length;
  const otherRecordable = incidents.filter(i=>i.classification==='Other Recordable Cases').length;

  function addIncident(){
    if(!form.employee_name||!form.description){ alert('Employee name and description required'); return; }
    const newInc:Incident = {
      id:String(Date.now()), case_no:incidents.length+1,
      employee_name:form.employee_name||'',job_title:form.job_title||'',
      date_of_injury:form.date_of_injury||'',location:form.location||'',
      description:form.description||'',classification:form.classification||'Other Recordable Cases',
      days_away:form.days_away||0,days_restricted:form.days_restricted||0,
    };
    setIncidents(prev=>[...prev,newInc]);
    setShowForm(false);
    setForm({date_of_injury:new Date().toISOString().slice(0,10),days_away:0,days_restricted:0,classification:'Other Recordable Cases'});
  }

  return (
    <div style={{padding:'28px 24px'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div>
          <h2 style={{margin:0,fontSize:20,fontWeight:800,color:TEXT}}>Safety Log — OSHA 300</h2>
          <div style={{fontSize:12,color:DIM,marginTop:3}}>Log of Work-Related Injuries and Illnesses · Year 2026</div>
        </div>
        <div style={{display:'flex',gap:10}}>
          <button onClick={()=>alert('Generating OSHA 300A Annual Summary PDF...')} style={{padding:'8px 16px',background:RAISED,border:`1px solid ${BORDER}`,borderRadius:7,color:DIM,fontSize:13,cursor:'pointer'}}>Export 300A Summary</button>
          <button onClick={()=>setShowForm(true)} style={{padding:'8px 16px',background:`linear-gradient(135deg,${GOLD},#F0C040)`,border:'none',borderRadius:7,color:'#0d1117',fontSize:13,fontWeight:800,cursor:'pointer'}}>+ New Incident</button>
        </div>
      </div>

      {/* OSHA Summary Row */}
      <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,padding:'16px 20px',marginBottom:24}}>
        <div style={{fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:12}}>OSHA 300A Summary — Totals for 2026</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:16}}>
          {[
            {label:'(G) Deaths',value:deaths,color:deaths>0?RED:GREEN},
            {label:'(H) Days Away',value:daysAway,color:daysAway>0?YELLOW:GREEN},
            {label:'(I) Restricted/Transfer',value:restricted,color:restricted>0?YELLOW:GREEN},
            {label:'(J) Other Recordable',value:otherRecordable,color:otherRecordable>0?YELLOW:GREEN},
            {label:'Total Recordable',value:recordable.length,color:recordable.length>0?YELLOW:GREEN},
          ].map(s=>(
            <div key={s.label} style={{textAlign:'center' as const,padding:'12px 8px',background:'rgba(0,0,0,.2)',borderRadius:8}}>
              <div style={{fontSize:22,fontWeight:800,color:s.color}}>{s.value}</div>
              <div style={{fontSize:10,color:DIM,marginTop:3,lineHeight:1.3}}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Incidents table */}
      <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
        <div style={{padding:'12px 18px',borderBottom:`1px solid ${BORDER}`,background:'rgba(0,0,0,.2)'}}>
          <span style={{fontWeight:700,fontSize:13,color:TEXT}}>Incident Log</span>
        </div>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
            <thead>
              <tr style={{background:'rgba(0,0,0,.3)'}}>
                {['Case #','Employee','Title','Date','Location','Description','Classification','Days Away','Days Restricted',''].map(h=>(
                  <th key={h} style={{padding:'8px 12px',textAlign:'left' as const,fontWeight:700,color:DIM,fontSize:10,textTransform:'uppercase' as const,letterSpacing:.4,borderBottom:`1px solid ${BORDER}`,whiteSpace:'nowrap' as const}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {incidents.map((inc,i)=>{
                const isRecordable = !inc.classification.includes('First Aid');
                return (
                  <tr key={inc.id} style={{background:i%2===0?'transparent':'rgba(255,255,255,.02)',borderBottom:`1px solid ${BORDER}`,opacity:isRecordable?1:.6}}>
                    <td style={{padding:'10px 12px',fontWeight:700,color:TEXT}}>{inc.case_no}</td>
                    <td style={{padding:'10px 12px',color:TEXT}}>{inc.employee_name}</td>
                    <td style={{padding:'10px 12px',color:DIM}}>{inc.job_title}</td>
                    <td style={{padding:'10px 12px',color:DIM,whiteSpace:'nowrap' as const}}>{inc.date_of_injury}</td>
                    <td style={{padding:'10px 12px',color:DIM}}>{inc.location}</td>
                    <td style={{padding:'10px 12px',color:TEXT,maxWidth:200}}>{inc.description}</td>
                    <td style={{padding:'10px 12px'}}>
                      <span style={{fontSize:10,fontWeight:700,padding:'2px 6px',borderRadius:4,background:isRecordable?'rgba(239,68,68,.15)':'rgba(34,197,94,.1)',color:isRecordable?RED:GREEN}}>{inc.classification}</span>
                    </td>
                    <td style={{padding:'10px 12px',textAlign:'center' as const,color:inc.days_away>0?RED:DIM,fontWeight:inc.days_away>0?700:400}}>{inc.days_away}</td>
                    <td style={{padding:'10px 12px',textAlign:'center' as const,color:inc.days_restricted>0?YELLOW:DIM}}>{inc.days_restricted}</td>
                    <td style={{padding:'10px 12px'}}>
                      <button onClick={()=>alert('Editing incident...')} style={{padding:'3px 8px',background:RAISED,border:`1px solid ${BORDER}`,borderRadius:4,color:DIM,fontSize:10,cursor:'pointer'}}>Edit</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Incident Modal */}
      {showForm&&(
        <div style={{position:'fixed' as const,inset:0,background:'rgba(0,0,0,.7)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:200}}>
          <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:12,padding:28,width:520,maxWidth:'90vw',maxHeight:'80vh',overflowY:'auto'}}>
            <div style={{fontWeight:800,fontSize:16,color:TEXT,marginBottom:20}}>New Incident Report — OSHA 300</div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
              {[
                {label:'Employee Name',key:'employee_name',type:'text'},
                {label:'Job Title',key:'job_title',type:'text'},
                {label:'Date of Injury/Illness',key:'date_of_injury',type:'date'},
                {label:'Location on Jobsite',key:'location',type:'text'},
              ].map(f=>(
                <div key={f.key}>
                  <label style={{display:'block',fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:5}}>{f.label}</label>
                  <input type={f.type} value={(form as any)[f.key]||''} onChange={e=>setForm(p=>({...p,[f.key]:e.target.value}))}
                    style={{width:'100%',padding:'8px 12px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:TEXT,fontSize:13,outline:'none',boxSizing:'border-box' as const}}/>
                </div>
              ))}
            </div>
            <div style={{marginTop:14}}>
              <label style={{display:'block',fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:5}}>Description of Injury/Illness</label>
              <textarea value={form.description||''} onChange={e=>setForm(p=>({...p,description:e.target.value}))} rows={3}
                style={{width:'100%',padding:'8px 12px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:TEXT,fontSize:13,outline:'none',resize:'vertical' as const,boxSizing:'border-box' as const}}/>
            </div>
            <div style={{marginTop:14}}>
              <label style={{display:'block',fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:5}}>Classification</label>
              <select value={form.classification} onChange={e=>setForm(p=>({...p,classification:e.target.value}))}
                style={{width:'100%',padding:'8px 12px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:TEXT,fontSize:13}}>
                {CLASSIFICATIONS.map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginTop:14}}>
              {[{label:'Days Away From Work',key:'days_away'},{label:'Days on Restricted Duty',key:'days_restricted'}].map(f=>(
                <div key={f.key}>
                  <label style={{display:'block',fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:5}}>{f.label}</label>
                  <input type="number" min={0} value={(form as any)[f.key]||0} onChange={e=>setForm(p=>({...p,[f.key]:parseInt(e.target.value)||0}))}
                    style={{width:'100%',padding:'8px 12px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:TEXT,fontSize:13,outline:'none',boxSizing:'border-box' as const}}/>
                </div>
              ))}
            </div>
            <div style={{display:'flex',gap:10,marginTop:20}}>
              <button onClick={addIncident} style={{flex:1,padding:'10px',background:`linear-gradient(135deg,${GOLD},#F0C040)`,border:'none',borderRadius:7,color:'#0d1117',fontWeight:800,fontSize:13,cursor:'pointer'}}>Add to OSHA 300 Log</button>
              <button onClick={()=>setShowForm(false)} style={{padding:'10px 16px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:DIM,fontSize:13,cursor:'pointer'}}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
