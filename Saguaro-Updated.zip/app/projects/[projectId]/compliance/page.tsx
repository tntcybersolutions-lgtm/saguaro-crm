'use client';
import React, { useState } from 'react';
import { useParams } from 'next/navigation';

const GOLD='#D4A017',DARK='#0d1117',RAISED='#1f2c3e',BORDER='#263347',DIM='#8fa3c0',TEXT='#e8edf8',GREEN='#22c55e',RED='#ef4444',YELLOW='#f59e0b';

interface COI { id:string; sub_name:string; sub_email:string; insurer:string; gl_policy:string; gl_expiry:string; auto_expiry:string; wc_expiry:string; umbrella_limit:number; status:'active'|'expiring'|'expired'|'missing'; }

const today = new Date();
function daysUntil(dateStr:string){ return Math.ceil((new Date(dateStr).getTime()-today.getTime())/(1000*60*60*24)); }
function getStatus(coi:COI):string{
  if(coi.status==='missing') return 'missing';
  const minDays = Math.min(daysUntil(coi.gl_expiry),daysUntil(coi.auto_expiry),daysUntil(coi.wc_expiry));
  if(minDays<0) return 'expired';
  if(minDays<30) return 'expiring';
  return 'active';
}

const COIS:COI[] = [
  {id:'c1',sub_name:'ABC Electrical Inc.',sub_email:'insurance@abcelec.com',insurer:'Liberty Mutual',gl_policy:'GL-2024-8821',gl_expiry:'2026-09-15',auto_expiry:'2026-09-15',wc_expiry:'2026-12-01',umbrella_limit:5000000,status:'active'},
  {id:'c2',sub_name:'Southwest Plumbing Co.',sub_email:'swplumb@gmail.com',insurer:'Travelers',gl_policy:'TR-2024-4412',gl_expiry:'2026-03-25',auto_expiry:'2026-03-25',wc_expiry:'2026-03-25',umbrella_limit:2000000,status:'expiring'},
  {id:'c3',sub_name:'Desert HVAC Solutions',sub_email:'admin@deserthvac.com',insurer:'Hartford',gl_policy:'HF-2025-0091',gl_expiry:'2026-11-30',auto_expiry:'2026-11-30',wc_expiry:'2026-11-30',umbrella_limit:3000000,status:'active'},
  {id:'c4',sub_name:'SunState Concrete',sub_email:'',insurer:'',gl_policy:'',gl_expiry:'',auto_expiry:'',wc_expiry:'',umbrella_limit:0,status:'missing'},
  {id:'c5',sub_name:'Ironclad Steel Erectors',sub_email:'certs@ironcladsteel.com',insurer:'Zurich',gl_policy:'ZU-2024-3398',gl_expiry:'2026-01-31',auto_expiry:'2026-01-31',wc_expiry:'2026-06-30',umbrella_limit:10000000,status:'expired'},
];

const fmt = (n:number)=>'$'+n.toLocaleString();

export default function CompliancePage(){
  const {projectId} = useParams() as {projectId:string};
  const [cois] = useState<COI[]>(COIS);
  const [uploading, setUploading] = useState<string|null>(null);
  const [parsing, setParsing] = useState(false);
  const [tab, setTab] = useState<'insurance'|'preliminary'|'w9'>('insurance');

  function statusColor(s:string){ return {active:GREEN,expiring:YELLOW,expired:RED,missing:RED}[s]||DIM; }
  function statusBg(s:string){ return {active:'rgba(34,197,94,.1)',expiring:'rgba(245,158,11,.1)',expired:'rgba(239,68,68,.1)',missing:'rgba(239,68,68,.08)'}[s]||''; }

  async function requestCOI(coi:COI){
    alert(`Sending COI request to ${coi.sub_email||'(no email on file)'}...\nIn production: Email with upload link sent automatically.`);
  }

  async function uploadAndParse(coiId:string, file:File){
    setUploading(coiId); setParsing(true);
    try {
      const fd = new FormData(); fd.append('file',file); fd.append('projectId',projectId);
      const res = await fetch('/api/insurance/upload',{method:'POST',body:fd});
      const d = await res.json();
      alert(d.extracted ? `Parsed COI:\nInsurer: ${d.extracted.insurer}\nGL Expiry: ${d.extracted.gl_expiry}\nAuto Expiry: ${d.extracted.auto_expiry}` : 'COI uploaded. Parsing complete.');
    } catch(e){ alert('Upload failed. Try again.'); }
    setUploading(null); setParsing(false);
  }

  const activeCount = cois.filter(c=>getStatus(c)==='active').length;
  const expiringCount = cois.filter(c=>getStatus(c)==='expiring').length;
  const expiredCount = cois.filter(c=>getStatus(c)==='expired').length;
  const missingCount = cois.filter(c=>getStatus(c)==='missing').length;

  return (
    <div style={{padding:'28px 24px'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div>
          <h2 style={{margin:0,fontSize:20,fontWeight:800,color:TEXT}}>Compliance & Insurance</h2>
          <div style={{fontSize:12,color:DIM,marginTop:3}}>ACORD 25 · Preliminary Notices · W-9 Collection</div>
        </div>
        <button onClick={()=>alert('Sending requests to all non-compliant subs...')} style={{padding:'8px 16px',background:`linear-gradient(135deg,${GOLD},#F0C040)`,border:'none',borderRadius:7,color:'#0d1117',fontSize:13,fontWeight:800,cursor:'pointer'}}>Request All Missing</button>
      </div>

      {/* Tabs */}
      <div style={{display:'flex',gap:2,marginBottom:20,background:'rgba(0,0,0,.3)',borderRadius:8,padding:3,width:'fit-content'}}>
        {[{key:'insurance',label:'Insurance (ACORD 25)'},{key:'preliminary',label:'Preliminary Notices'},{key:'w9',label:'W-9 Collection'}].map(t=>(
          <button key={t.key} onClick={()=>setTab(t.key as any)}
            style={{padding:'7px 16px',borderRadius:6,border:'none',background:tab===t.key?RAISED:'transparent',color:tab===t.key?TEXT:DIM,fontSize:13,fontWeight:tab===t.key?700:400,cursor:'pointer'}}>
            {t.label}
          </button>
        ))}
      </div>

      {tab==='insurance'&&<>
        {/* Stats */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14,marginBottom:24}}>
          {[{label:'Active',v:activeCount,c:GREEN},{label:'Expiring Soon',v:expiringCount,c:YELLOW},{label:'Expired',v:expiredCount,c:RED},{label:'Missing',v:missingCount,c:RED}].map(s=>(
            <div key={s.label} style={{background:RAISED,border:`1px solid ${s.c}30`,borderRadius:10,padding:'14px 16px'}}>
              <div style={{fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:6}}>{s.label}</div>
              <div style={{fontSize:24,fontWeight:800,color:s.c}}>{s.v}</div>
            </div>
          ))}
        </div>

        {/* COI Table */}
        <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
          <div style={{padding:'12px 18px',borderBottom:`1px solid ${BORDER}`,background:'rgba(0,0,0,.2)'}}>
            <span style={{fontWeight:700,fontSize:13,color:TEXT}}>Certificate of Insurance Tracker</span>
          </div>
          {cois.map((coi,i)=>{
            const status = getStatus(coi);
            const glDays = coi.gl_expiry?daysUntil(coi.gl_expiry):null;
            return (
              <div key={coi.id} style={{padding:'14px 18px',borderBottom:`1px solid ${BORDER}`,background:i%2===0?'transparent':'rgba(255,255,255,.01)'}}>
                <div style={{display:'grid',gridTemplateColumns:'200px 1fr 1fr 1fr 100px 140px',gap:12,alignItems:'center'}}>
                  <div>
                    <div style={{fontWeight:700,color:TEXT,fontSize:13}}>{coi.sub_name}</div>
                    <div style={{fontSize:11,color:DIM}}>{coi.insurer||'No insurer on file'}</div>
                  </div>
                  <div>
                    <div style={{fontSize:10,color:DIM,marginBottom:2}}>GL EXPIRY</div>
                    <div style={{fontSize:13,color:coi.gl_expiry?(glDays!<0?RED:glDays!<30?YELLOW:GREEN):RED,fontWeight:600}}>{coi.gl_expiry||'—'}</div>
                    {glDays!==null&&glDays<30&&glDays>=0&&<div style={{fontSize:10,color:YELLOW}}>{glDays} days left</div>}
                    {glDays!==null&&glDays<0&&<div style={{fontSize:10,color:RED}}>Expired {Math.abs(glDays)} days ago</div>}
                  </div>
                  <div>
                    <div style={{fontSize:10,color:DIM,marginBottom:2}}>AUTO EXPIRY</div>
                    <div style={{fontSize:13,color:coi.auto_expiry?GREEN:RED,fontWeight:600}}>{coi.auto_expiry||'—'}</div>
                  </div>
                  <div>
                    <div style={{fontSize:10,color:DIM,marginBottom:2}}>WC EXPIRY</div>
                    <div style={{fontSize:13,color:coi.wc_expiry?GREEN:RED,fontWeight:600}}>{coi.wc_expiry||'—'}</div>
                  </div>
                  <div>
                    <span style={{fontSize:10,fontWeight:700,padding:'3px 8px',borderRadius:4,background:statusBg(status),color:statusColor(status),textTransform:'uppercase' as const}}>{status}</span>
                  </div>
                  <div style={{display:'flex',gap:6}}>
                    <label style={{padding:'5px 10px',background:'rgba(212,160,23,.12)',border:`1px solid rgba(212,160,23,.3)`,borderRadius:5,color:GOLD,fontSize:11,fontWeight:700,cursor:'pointer'}}>
                      Upload COI
                      <input type="file" accept=".pdf" style={{display:'none'}} onChange={e=>{if(e.target.files?.[0]) uploadAndParse(coi.id,e.target.files[0]);}}/>
                    </label>
                    <button onClick={()=>requestCOI(coi)} style={{padding:'5px 8px',background:RAISED,border:`1px solid ${BORDER}`,borderRadius:5,color:DIM,fontSize:11,cursor:'pointer'}}>Request</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </>}

      {tab==='preliminary'&&(
        <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,padding:32,textAlign:'center' as const}}>
          <div style={{fontSize:32,marginBottom:12}}>📋</div>
          <div style={{fontWeight:700,fontSize:16,color:TEXT,marginBottom:8}}>Preliminary Notices</div>
          <div style={{fontSize:13,color:DIM,marginBottom:20,maxWidth:400,margin:'0 auto 20px'}}>Auto-generates state-specific preliminary notices for AZ, CA, and TX when subs are onboarded. Required within 20 days of first furnishing.</div>
          <button onClick={()=>alert('Generating preliminary notices for all subs...')} style={{padding:'10px 22px',background:`linear-gradient(135deg,${GOLD},#F0C040)`,border:'none',borderRadius:8,color:'#0d1117',fontWeight:800,fontSize:13,cursor:'pointer'}}>Generate All Pending Notices</button>
        </div>
      )}

      {tab==='w9'&&(
        <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
          <div style={{padding:'12px 18px',borderBottom:`1px solid ${BORDER}`,background:'rgba(0,0,0,.2)'}}>
            <span style={{fontWeight:700,fontSize:13,color:TEXT}}>W-9 Collection</span>
            <span style={{fontSize:11,color:DIM,marginLeft:10}}>Required for any sub receiving more than $600</span>
          </div>
          {[
            {name:'ABC Electrical Inc.',status:'complete',tin:'**-***1234'},
            {name:'Southwest Plumbing Co.',status:'pending',tin:''},
            {name:'Desert HVAC Solutions',status:'complete',tin:'**-***5678'},
            {name:'SunState Concrete',status:'missing',tin:''},
            {name:'Ironclad Steel Erectors',status:'pending',tin:''},
          ].map((sub,i)=>(
            <div key={sub.name} style={{padding:'14px 18px',borderBottom:`1px solid ${BORDER}`,display:'flex',justifyContent:'space-between',alignItems:'center',background:i%2===0?'transparent':'rgba(255,255,255,.01)'}}>
              <div>
                <div style={{fontWeight:700,color:TEXT,fontSize:13}}>{sub.name}</div>
                <div style={{fontSize:11,color:DIM}}>{sub.tin?`TIN on file: ${sub.tin}`:'No TIN on file'}</div>
              </div>
              <div style={{display:'flex',gap:10,alignItems:'center'}}>
                <span style={{fontSize:10,fontWeight:700,padding:'3px 8px',borderRadius:4,
                  background:sub.status==='complete'?'rgba(34,197,94,.1)':sub.status==='pending'?'rgba(245,158,11,.1)':'rgba(239,68,68,.1)',
                  color:sub.status==='complete'?GREEN:sub.status==='pending'?YELLOW:RED,textTransform:'uppercase' as const}}>{sub.status}</span>
                {sub.status!=='complete'&&<button onClick={()=>alert(`Sending W-9 request portal link to ${sub.name}...`)} style={{padding:'5px 12px',background:`rgba(212,160,23,.12)`,border:`1px solid rgba(212,160,23,.3)`,borderRadius:5,color:GOLD,fontSize:11,fontWeight:700,cursor:'pointer'}}>Send Request</button>}
                {sub.status==='complete'&&<button onClick={()=>alert('Downloading W-9...')} style={{padding:'5px 12px',background:'rgba(34,197,94,.1)',border:`1px solid rgba(34,197,94,.3)`,borderRadius:5,color:GREEN,fontSize:11,cursor:'pointer'}}>Download</button>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
