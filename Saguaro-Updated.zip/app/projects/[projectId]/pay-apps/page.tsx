'use client';
import React, { useState } from 'react';
import { useParams } from 'next/navigation';

const GOLD='#D4A017',DARK='#0d1117',RAISED='#1f2c3e',BORDER='#263347',DIM='#8fa3c0',TEXT='#e8edf8',GREEN='#22c55e',RED='#ef4444',YELLOW='#f59e0b';
const fmt = (n:number) => '$'+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const pct = (n:number) => n.toFixed(1)+'%';

interface SOVLine { id:string; line_no:string; description:string; scheduled_value:number; prev_completed:number; this_period:number; stored_materials:number; }
interface PayApp { id:string; app_number:number; period_to:string; net_payment_due:number; status:string; }

const DEFAULT_SOV:SOVLine[] = [
  {id:'1',line_no:'1',description:'General Conditions / Mobilization',scheduled_value:45000,prev_completed:45000,this_period:0,stored_materials:0},
  {id:'2',line_no:'2',description:'Site Work & Excavation',scheduled_value:120000,prev_completed:96000,this_period:24000,stored_materials:0},
  {id:'3',line_no:'3',description:'Concrete Foundation',scheduled_value:185000,prev_completed:185000,this_period:0,stored_materials:0},
  {id:'4',line_no:'4',description:'Structural Steel / Framing',scheduled_value:210000,prev_completed:168000,this_period:42000,stored_materials:0},
  {id:'5',line_no:'5',description:'Roofing',scheduled_value:95000,prev_completed:0,this_period:0,stored_materials:0},
  {id:'6',line_no:'6',description:'Exterior Skin / Glazing',scheduled_value:140000,prev_completed:0,this_period:0,stored_materials:0},
  {id:'7',line_no:'7',description:'Rough Mechanical (HVAC)',scheduled_value:165000,prev_completed:82500,this_period:0,stored_materials:0},
  {id:'8',line_no:'8',description:'Rough Electrical',scheduled_value:145000,prev_completed:72500,this_period:0,stored_materials:0},
  {id:'9',line_no:'9',description:'Rough Plumbing',scheduled_value:98000,prev_completed:49000,this_period:0,stored_materials:0},
  {id:'10',line_no:'10',description:'Drywall & Insulation',scheduled_value:88000,prev_completed:0,this_period:0,stored_materials:0},
  {id:'11',line_no:'11',description:'Finishes & Painting',scheduled_value:76000,prev_completed:0,this_period:0,stored_materials:0},
  {id:'12',line_no:'12',description:'Finish MEP & Fixtures',scheduled_value:110000,prev_completed:0,this_period:0,stored_materials:0},
  {id:'13',line_no:'13',description:'Contingency / Allowances',scheduled_value:25000,prev_completed:0,this_period:0,stored_materials:0},
];

function StatusBadge({status}:{status:string}){
  const map:Record<string,{bg:string,color:string}> = {
    draft:{bg:'rgba(148,163,184,.15)',color:'#94a3b8'},
    submitted:{bg:'rgba(245,158,11,.15)',color:YELLOW},
    approved:{bg:'rgba(34,197,94,.15)',color:GREEN},
    paid:{bg:'rgba(34,197,94,.25)',color:GREEN},
  };
  const s = map[status]??map.draft;
  return <span style={{fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:4,background:s.bg,color:s.color,textTransform:'uppercase' as const,letterSpacing:.5}}>{status}</span>;
}

export default function PayAppsPage() {
  const { projectId } = useParams() as { projectId: string };
  const [view, setView] = useState<'list'|'new'>('list');
  const [sov, setSov] = useState<SOVLine[]>(DEFAULT_SOV);
  const [periodTo, setPeriodTo] = useState(new Date().toISOString().slice(0,10));
  const [retainagePct, setRetainagePct] = useState(10);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [pastApps] = useState<PayApp[]>([
    {id:'pa1',app_number:1,period_to:'2026-01-31',net_payment_due:198000,status:'paid'},
    {id:'pa2',app_number:2,period_to:'2026-02-28',net_payment_due:156750,status:'approved'},
  ]);

  const contractSum = sov.reduce((s,l)=>s+l.scheduled_value,0);
  const prevCertified = sov.reduce((s,l)=>s+l.prev_completed,0);
  const thisPeriod = sov.reduce((s,l)=>s+l.this_period,0);
  const storedMaterials = sov.reduce((s,l)=>s+l.stored_materials,0);
  const totalCompleted = prevCertified + thisPeriod + storedMaterials;
  const retainageAmt = totalCompleted * (retainagePct/100);
  const totalEarnedLessRetainage = totalCompleted - retainageAmt;
  const totalPrevCerts = pastApps.filter(p=>p.status==='paid'||p.status==='approved').reduce((s,p)=>s+p.net_payment_due,0);
  const currentPaymentDue = totalEarnedLessRetainage - totalPrevCerts;
  const balanceToFinish = contractSum - totalCompleted;
  const pctComplete = contractSum > 0 ? (totalCompleted/contractSum)*100 : 0;

  function updateSOV(id:string, field:keyof SOVLine, val:number){
    setSov(prev=>prev.map(l=>l.id===id?{...l,[field]:isNaN(val)?0:val}:l));
  }

  async function handleSubmit(){
    setSubmitting(true);
    try {
      const res = await fetch('/api/pay-apps/create',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({tenantId:'demo',projectId,contractId:'demo-contract',applicationNumber:pastApps.length+1,periodTo,thisPeriod,scheduleOfValues:sov,retainagePct,currentPaymentDue}),
      });
      const d = await res.json();
      setSubmitted(true);
      if(d.g702PdfUrl) window.open(d.g702PdfUrl,'_blank');
    } catch(e){ alert('Error creating pay app.'); }
    setSubmitting(false);
  }

  if(submitted) return (
    <div style={{padding:'60px 28px',textAlign:'center' as const}}>
      <div style={{fontSize:48,marginBottom:16}}>✅</div>
      <div style={{fontSize:22,fontWeight:800,color:TEXT,marginBottom:8}}>Pay Application #{pastApps.length+1} Created</div>
      <div style={{fontSize:14,color:DIM,marginBottom:24}}>G702/G703 PDFs generated. Conditional lien waivers auto-created for all subs.</div>
      <div style={{display:'flex',gap:12,justifyContent:'center'}}>
        <button onClick={()=>{setSubmitted(false);setView('list');}} style={{padding:'10px 22px',background:`linear-gradient(135deg,${GOLD},#F0C040)`,border:'none',borderRadius:8,color:'#0d1117',fontWeight:800,fontSize:13,cursor:'pointer'}}>Back to Pay Apps</button>
        <button onClick={()=>alert('Sending to owner portal...')} style={{padding:'10px 22px',background:RAISED,border:`1px solid ${BORDER}`,borderRadius:8,color:TEXT,fontSize:13,cursor:'pointer'}}>Submit to Owner →</button>
      </div>
    </div>
  );

  if(view==='list') return (
    <div style={{padding:'28px 24px'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div>
          <h2 style={{margin:0,fontSize:20,fontWeight:800,color:TEXT}}>Pay Applications</h2>
          <div style={{fontSize:12,color:DIM,marginTop:3}}>AIA G702/G703 — Application and Certificate for Payment</div>
        </div>
        <button onClick={()=>setView('new')} style={{padding:'9px 18px',background:`linear-gradient(135deg,${GOLD},#F0C040)`,border:'none',borderRadius:7,color:'#0d1117',fontSize:13,fontWeight:800,cursor:'pointer'}}>+ New Pay Application</button>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14,marginBottom:24}}>
        {[
          {label:'Contract Sum',value:fmt(contractSum)},
          {label:'Total Billed',value:fmt(totalPrevCerts)},
          {label:'Retainage Held',value:fmt(totalPrevCerts*0.1)},
          {label:'Balance to Bill',value:fmt(contractSum-totalPrevCerts)},
        ].map(c=>(
          <div key={c.label} style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,padding:'16px 18px'}}>
            <div style={{fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:6}}>{c.label}</div>
            <div style={{fontSize:20,fontWeight:800,color:GOLD}}>{c.value}</div>
          </div>
        ))}
      </div>
      <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
        <div style={{padding:'10px 18px',borderBottom:`1px solid ${BORDER}`,display:'grid',gridTemplateColumns:'60px 1fr 1fr 1fr 120px',gap:12,background:'rgba(0,0,0,.2)'}}>
          {['App #','Period Ending','Amount Due','Status','Actions'].map(h=>(
            <div key={h} style={{fontSize:10,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5}}>{h}</div>
          ))}
        </div>
        {pastApps.map(app=>(
          <div key={app.id} style={{padding:'14px 18px',borderBottom:`1px solid ${BORDER}`,display:'grid',gridTemplateColumns:'60px 1fr 1fr 1fr 120px',gap:12,alignItems:'center'}}>
            <div style={{fontWeight:700,color:TEXT}}>#{app.app_number}</div>
            <div style={{color:DIM,fontSize:13}}>{app.period_to}</div>
            <div style={{fontWeight:700,color:GOLD}}>{fmt(app.net_payment_due)}</div>
            <div><StatusBadge status={app.status}/></div>
            <div style={{display:'flex',gap:6}}>
              <button onClick={()=>alert('Opening PDF...')} style={{padding:'4px 10px',background:'rgba(212,160,23,.12)',border:`1px solid rgba(212,160,23,.3)`,borderRadius:5,color:GOLD,fontSize:11,fontWeight:700,cursor:'pointer'}}>PDF</button>
              <button onClick={()=>alert('Viewing...')} style={{padding:'4px 10px',background:RAISED,border:`1px solid ${BORDER}`,borderRadius:5,color:DIM,fontSize:11,cursor:'pointer'}}>View</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div style={{padding:'28px 24px'}}>
      <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:24}}>
        <button onClick={()=>setView('list')} style={{background:'none',border:'none',color:DIM,cursor:'pointer',fontSize:13}}>← Pay Applications</button>
        <span style={{color:BORDER}}>/</span>
        <span style={{color:TEXT,fontWeight:700}}>New Pay Application #{pastApps.length+1}</span>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 320px',gap:20,alignItems:'start'}}>
        <div>
          <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden',marginBottom:14}}>
            <div style={{padding:'12px 18px',borderBottom:`1px solid ${BORDER}`,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <span style={{fontWeight:700,fontSize:14,color:TEXT}}>Schedule of Values (G703)</span>
              <div style={{display:'flex',gap:8,alignItems:'center'}}>
                <span style={{fontSize:12,color:DIM}}>Period Ending:</span>
                <input type="date" value={periodTo} onChange={e=>setPeriodTo(e.target.value)} style={{padding:'4px 8px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:5,color:TEXT,fontSize:12}}/>
              </div>
            </div>
            <div style={{overflowX:'auto'}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead>
                  <tr style={{background:'rgba(0,0,0,.3)'}}>
                    {['#','Description','Scheduled $','Prev Completed','This Period ✏️','Stored Matl','% Complete','Balance'].map(h=>(
                      <th key={h} style={{padding:'8px 10px',textAlign:'left' as const,fontWeight:700,color:DIM,fontSize:10,textTransform:'uppercase' as const,letterSpacing:.4,borderBottom:`1px solid ${BORDER}`,whiteSpace:'nowrap' as const}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sov.map((line,i)=>{
                    const lineTotal = line.prev_completed+line.this_period+line.stored_materials;
                    const linePct = line.scheduled_value>0?(lineTotal/line.scheduled_value)*100:0;
                    return (
                      <tr key={line.id} style={{background:i%2===0?'transparent':'rgba(255,255,255,.02)',borderBottom:`1px solid ${BORDER}`}}>
                        <td style={{padding:'6px 10px',color:DIM}}>{line.line_no}</td>
                        <td style={{padding:'6px 10px',color:TEXT}}>{line.description}</td>
                        <td style={{padding:'6px 10px',color:TEXT,textAlign:'right' as const}}>{fmt(line.scheduled_value)}</td>
                        <td style={{padding:'6px 10px',color:DIM,textAlign:'right' as const}}>{fmt(line.prev_completed)}</td>
                        <td style={{padding:'4px 6px'}}>
                          <input type="number" min={0} value={line.this_period||''} onChange={e=>updateSOV(line.id,'this_period',parseFloat(e.target.value))} placeholder="0"
                            style={{width:90,padding:'5px 8px',background:line.this_period>0?'rgba(212,160,23,.08)':DARK,border:`1px solid ${line.this_period>0?'rgba(212,160,23,.5)':BORDER}`,borderRadius:5,color:line.this_period>0?GOLD:TEXT,fontSize:12,outline:'none',textAlign:'right' as const}}/>
                        </td>
                        <td style={{padding:'4px 6px'}}>
                          <input type="number" min={0} value={line.stored_materials||''} onChange={e=>updateSOV(line.id,'stored_materials',parseFloat(e.target.value))} placeholder="0"
                            style={{width:70,padding:'5px 8px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:5,color:TEXT,fontSize:12,outline:'none',textAlign:'right' as const}}/>
                        </td>
                        <td style={{padding:'6px 10px',textAlign:'right' as const}}>
                          <span style={{color:linePct>=100?GREEN:linePct>50?GOLD:DIM,fontWeight:linePct>0?700:400}}>{pct(linePct)}</span>
                        </td>
                        <td style={{padding:'6px 10px',color:linePct>=100?GREEN:DIM,textAlign:'right' as const}}>{fmt(line.scheduled_value-lineTotal)}</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr style={{background:'rgba(212,160,23,.05)',borderTop:`2px solid rgba(212,160,23,.3)`}}>
                    <td colSpan={2} style={{padding:'10px',fontWeight:800,color:TEXT,fontSize:12}}>TOTALS</td>
                    <td style={{padding:'10px',fontWeight:800,color:TEXT,textAlign:'right' as const}}>{fmt(contractSum)}</td>
                    <td style={{padding:'10px',fontWeight:800,color:DIM,textAlign:'right' as const}}>{fmt(prevCertified)}</td>
                    <td style={{padding:'10px',fontWeight:800,color:GOLD,textAlign:'right' as const}}>{fmt(thisPeriod)}</td>
                    <td style={{padding:'10px',fontWeight:800,color:DIM,textAlign:'right' as const}}>{fmt(storedMaterials)}</td>
                    <td style={{padding:'10px',fontWeight:800,color:GOLD,textAlign:'right' as const}}>{pct(pctComplete)}</td>
                    <td style={{padding:'10px',fontWeight:800,color:DIM,textAlign:'right' as const}}>{fmt(balanceToFinish)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
          <button onClick={()=>setSov(p=>[...p,{id:String(Date.now()),line_no:String(p.length+1),description:'New Line Item',scheduled_value:0,prev_completed:0,this_period:0,stored_materials:0}])}
            style={{padding:'7px 14px',background:'rgba(255,255,255,.04)',border:`1px dashed ${BORDER}`,borderRadius:7,color:DIM,fontSize:12,cursor:'pointer'}}>+ Add Line Item</button>
        </div>
        <div style={{position:'sticky' as const,top:76}}>
          <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden',marginBottom:14}}>
            <div style={{padding:'12px 16px',borderBottom:`1px solid ${BORDER}`,background:'rgba(0,0,0,.2)'}}>
              <span style={{fontWeight:700,fontSize:13,color:TEXT}}>G702 Summary</span>
            </div>
            <div style={{padding:16}}>
              {[
                {label:'1. Original Contract Sum',value:fmt(contractSum),color:TEXT},
                {label:'2. Net Change by Change Orders',value:fmt(0),color:DIM},
                {label:'3. Contract Sum to Date',value:fmt(contractSum),color:TEXT},
                {label:'4. Total Completed & Stored to Date',value:fmt(totalCompleted),color:TEXT},
                {label:`5. Retainage (${retainagePct}%)`,value:`(${fmt(retainageAmt)})`,color:RED},
                {label:'6. Total Earned Less Retainage',value:fmt(totalEarnedLessRetainage),color:TEXT},
                {label:'7. Less Previous Certificates for Payment',value:`(${fmt(totalPrevCerts)})`,color:DIM},
              ].map(row=>(
                <div key={row.label} style={{display:'flex',justifyContent:'space-between',padding:'6px 0',borderBottom:`1px solid ${BORDER}`,fontSize:11}}>
                  <span style={{color:DIM,maxWidth:'60%',lineHeight:1.4}}>{row.label}</span>
                  <span style={{fontWeight:600,color:row.color}}>{row.value}</span>
                </div>
              ))}
              <div style={{marginTop:12,padding:'14px',background:'rgba(212,160,23,.1)',border:`1px solid rgba(212,160,23,.3)`,borderRadius:8}}>
                <div style={{fontSize:10,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:4}}>8. Current Payment Due</div>
                <div style={{fontSize:28,fontWeight:900,color:GOLD}}>{fmt(Math.max(0,currentPaymentDue))}</div>
              </div>
              <div style={{marginTop:10,display:'flex',justifyContent:'space-between',fontSize:12,padding:'4px 0'}}>
                <span style={{color:DIM}}>Balance to Finish (incl. Retainage)</span>
                <span style={{color:TEXT,fontWeight:600}}>{fmt(balanceToFinish)}</span>
              </div>
            </div>
          </div>
          <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,padding:14,marginBottom:14}}>
            <div style={{fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:8}}>Retainage %</div>
            <div style={{display:'flex',gap:6}}>
              {[5,10,15].map(p=>(
                <button key={p} onClick={()=>setRetainagePct(p)} style={{flex:1,padding:'6px 0',background:retainagePct===p?'rgba(212,160,23,.2)':DARK,border:`1px solid ${retainagePct===p?'rgba(212,160,23,.5)':BORDER}`,borderRadius:6,color:retainagePct===p?GOLD:DIM,fontSize:13,fontWeight:700,cursor:'pointer'}}>{p}%</button>
              ))}
            </div>
          </div>
          <div style={{background:'rgba(212,160,23,.05)',border:'1px solid rgba(212,160,23,.15)',borderRadius:8,padding:'10px 12px',marginBottom:14,fontSize:11,color:DIM,lineHeight:1.6}}>
            🤖 <strong style={{color:GOLD}}>Auto on submit:</strong> G702 + G703 PDFs generated, conditional lien waivers created for all subs, package emailed to owner portal for approval.
          </div>
          <div style={{display:'flex',flexDirection:'column' as const,gap:8}}>
            <button onClick={handleSubmit} disabled={submitting||thisPeriod===0}
              style={{padding:'12px 0',background:thisPeriod>0?`linear-gradient(135deg,${GOLD},#F0C040)`:'rgba(212,160,23,.3)',border:'none',borderRadius:8,color:'#0d1117',fontSize:14,fontWeight:800,cursor:thisPeriod>0?'pointer':'not-allowed',width:'100%',opacity:submitting?.7:1}}>
              {submitting?'Generating PDFs...':'Generate Pay App + PDFs'}
            </button>
            <button onClick={()=>alert('Draft saved')} style={{padding:'9px 0',background:RAISED,border:`1px solid ${BORDER}`,borderRadius:8,color:DIM,fontSize:13,cursor:'pointer',width:'100%'}}>Save Draft</button>
            <button onClick={()=>setView('list')} style={{padding:'9px 0',background:'none',border:'none',color:DIM,fontSize:12,cursor:'pointer'}}>Cancel</button>
          </div>
          {thisPeriod===0&&<div style={{fontSize:11,color:RED,marginTop:8,textAlign:'center' as const}}>Enter amounts in "This Period" column to enable submission</div>}
        </div>
      </div>
    </div>
  );
}
