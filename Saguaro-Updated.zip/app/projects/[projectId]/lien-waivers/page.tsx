'use client';
import React, { useState } from 'react';
import { useParams } from 'next/navigation';

const GOLD='#D4A017',DARK='#0d1117',RAISED='#1f2c3e',BORDER='#263347',DIM='#8fa3c0',TEXT='#e8edf8',GREEN='#22c55e',RED='#ef4444',YELLOW='#f59e0b';
const fmt = (n:number) => '$'+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});

type WaiverType = 'conditional_partial'|'unconditional_partial'|'conditional_final'|'unconditional_final';
interface Sub { id:string; name:string; trade:string; amount:number; }
interface Waiver { sub_id:string; type:WaiverType; status:'signed'|'pending'|'missing'; amount:number; through_date:string; }

const SUBS:Sub[] = [
  {id:'s1',name:'ABC Electrical Inc.',trade:'Electrical',amount:145000},
  {id:'s2',name:'Southwest Plumbing Co.',trade:'Plumbing',amount:98000},
  {id:'s3',name:'Desert HVAC Solutions',trade:'Mechanical',amount:165000},
  {id:'s4',name:'SunState Concrete',trade:'Concrete',amount:185000},
  {id:'s5',name:'Ironclad Steel Erectors',trade:'Structural',amount:210000},
];

const WAIVER_TYPES:WaiverType[] = ['conditional_partial','unconditional_partial','conditional_final','unconditional_final'];
const WAIVER_LABELS:Record<WaiverType,string> = {
  conditional_partial:'Conditional Progress',
  unconditional_partial:'Unconditional Progress',
  conditional_final:'Conditional Final',
  unconditional_final:'Unconditional Final',
};
const WAIVER_DESC:Record<WaiverType,string> = {
  conditional_partial:'Waive lien rights WHEN payment clears',
  unconditional_partial:'Payment received, waiving through period date',
  conditional_final:'Waive ALL rights WHEN final payment clears',
  unconditional_final:'Final payment received, all rights waived forever',
};

const INITIAL_WAIVERS:Waiver[] = [
  {sub_id:'s1',type:'conditional_partial',status:'signed',amount:72500,through_date:'2026-01-31'},
  {sub_id:'s1',type:'unconditional_partial',status:'signed',amount:72500,through_date:'2026-01-31'},
  {sub_id:'s2',type:'conditional_partial',status:'signed',amount:49000,through_date:'2026-01-31'},
  {sub_id:'s2',type:'unconditional_partial',status:'pending',amount:49000,through_date:'2026-01-31'},
  {sub_id:'s3',type:'conditional_partial',status:'signed',amount:82500,through_date:'2026-01-31'},
  {sub_id:'s4',type:'conditional_partial',status:'signed',amount:185000,through_date:'2026-01-31'},
  {sub_id:'s4',type:'unconditional_partial',status:'signed',amount:185000,through_date:'2026-01-31'},
];

export default function LienWaiversPage(){
  const {projectId} = useParams() as {projectId:string};
  const [waivers, setWaivers] = useState<Waiver[]>(INITIAL_WAIVERS);
  const [generating, setGenerating] = useState<string|null>(null);
  const [modal, setModal] = useState<{sub:Sub,type:WaiverType}|null>(null);
  const [amount, setAmount] = useState('');
  const [throughDate, setThroughDate] = useState(new Date().toISOString().slice(0,10));
  const [state, setState] = useState('AZ');

  function getWaiver(subId:string,type:WaiverType){ return waivers.find(w=>w.sub_id===subId&&w.type===type); }

  async function generateWaiver(sub:Sub, type:WaiverType, amt:number, thru:string){
    const key = `${sub.id}-${type}`;
    setGenerating(key);
    try {
      const res = await fetch('/api/documents/lien-waiver',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({tenantId:'demo',projectId,subId:sub.id,subName:sub.name,waiverType:type,amount:amt,throughDate:thru,state}),
      });
      const d = await res.json();
      setWaivers(prev=>[...prev.filter(w=>!(w.sub_id===sub.id&&w.type===type)),
        {sub_id:sub.id,type,status:'pending',amount:amt,through_date:thru}]);
      if(d.pdfUrl) window.open(d.pdfUrl,'_blank');
      else alert(`${WAIVER_LABELS[type]} waiver generated for ${sub.name}!\nIn production: PDF + email to sub for signature.`);
    } catch(e){ alert('Error generating waiver'); }
    setGenerating(null);
    setModal(null);
  }

  const signedCount = waivers.filter(w=>w.status==='signed').length;
  const pendingCount = waivers.filter(w=>w.status==='pending').length;
  const totalPossible = SUBS.length * WAIVER_TYPES.length;

  return (
    <div style={{padding:'28px 24px'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div>
          <h2 style={{margin:0,fontSize:20,fontWeight:800,color:TEXT}}>Lien Waivers</h2>
          <div style={{fontSize:12,color:DIM,marginTop:3}}>State-specific statutory forms — AZ, CA, TX, and all 50 states</div>
        </div>
        <div style={{display:'flex',gap:10,alignItems:'center'}}>
          <select value={state} onChange={e=>setState(e.target.value)} style={{padding:'7px 12px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:TEXT,fontSize:13}}>
            {['AZ','CA','TX','NV','CO','FL','WA','OR','UT','NM','OTHER'].map(s=><option key={s} value={s}>{s}</option>)}
          </select>
          <button onClick={()=>alert('Sending waiver requests to all subs...')} style={{padding:'8px 16px',background:`linear-gradient(135deg,${GOLD},#F0C040)`,border:'none',borderRadius:7,color:'#0d1117',fontSize:13,fontWeight:800,cursor:'pointer'}}>Request All Pending</button>
        </div>
      </div>

      {/* Stats */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14,marginBottom:24}}>
        {[
          {label:'Signed',value:signedCount,color:GREEN,bg:'rgba(34,197,94,.1)'},
          {label:'Pending Signature',value:pendingCount,color:YELLOW,bg:'rgba(245,158,11,.1)'},
          {label:'Missing',value:totalPossible-signedCount-pendingCount,color:RED,bg:'rgba(239,68,68,.1)'},
          {label:'Total Required',value:totalPossible,color:DIM,bg:'rgba(143,163,192,.1)'},
        ].map(c=>(
          <div key={c.label} style={{background:c.bg,border:`1px solid ${c.color}30`,borderRadius:10,padding:'14px 16px'}}>
            <div style={{fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:6}}>{c.label}</div>
            <div style={{fontSize:24,fontWeight:800,color:c.color}}>{c.value}</div>
          </div>
        ))}
      </div>

      {/* Matrix */}
      <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
        <div style={{padding:'12px 18px',borderBottom:`1px solid ${BORDER}`,background:'rgba(0,0,0,.2)'}}>
          <span style={{fontWeight:700,fontSize:13,color:TEXT}}>Waiver Status Matrix</span>
          <span style={{fontSize:11,color:DIM,marginLeft:10}}>Click any cell to generate or view</span>
        </div>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead>
              <tr style={{background:'rgba(0,0,0,.3)'}}>
                <th style={{padding:'10px 16px',textAlign:'left' as const,fontWeight:700,color:DIM,fontSize:11,textTransform:'uppercase' as const,letterSpacing:.4,borderBottom:`1px solid ${BORDER}`,minWidth:200}}>Subcontractor</th>
                {WAIVER_TYPES.map(t=>(
                  <th key={t} style={{padding:'10px 14px',textAlign:'center' as const,fontWeight:700,color:DIM,fontSize:10,textTransform:'uppercase' as const,letterSpacing:.3,borderBottom:`1px solid ${BORDER}`,minWidth:140}}>
                    {WAIVER_LABELS[t]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {SUBS.map((sub,i)=>(
                <tr key={sub.id} style={{background:i%2===0?'transparent':'rgba(255,255,255,.02)',borderBottom:`1px solid ${BORDER}`}}>
                  <td style={{padding:'12px 16px'}}>
                    <div style={{fontWeight:700,color:TEXT,fontSize:13}}>{sub.name}</div>
                    <div style={{fontSize:11,color:DIM}}>{sub.trade} · {fmt(sub.amount)}</div>
                  </td>
                  {WAIVER_TYPES.map(type=>{
                    const w = getWaiver(sub.id,type);
                    const key = `${sub.id}-${type}`;
                    const isGen = generating===key;
                    return (
                      <td key={type} style={{padding:'8px 10px',textAlign:'center' as const}}>
                        {w ? (
                          <div onClick={()=>!isGen&&setModal({sub,type})} style={{cursor:'pointer',padding:'8px',borderRadius:7,background:w.status==='signed'?'rgba(34,197,94,.1)':'rgba(245,158,11,.1)',border:`1px solid ${w.status==='signed'?'rgba(34,197,94,.3)':'rgba(245,158,11,.3)'}`}}>
                            <div style={{fontSize:16}}>{w.status==='signed'?'✅':'⏳'}</div>
                            <div style={{fontSize:10,fontWeight:700,color:w.status==='signed'?GREEN:YELLOW,marginTop:2}}>{w.status.toUpperCase()}</div>
                            <div style={{fontSize:10,color:DIM}}>{fmt(w.amount)}</div>
                          </div>
                        ) : (
                          <button onClick={()=>{setModal({sub,type});setAmount(String(sub.amount));}} disabled={isGen}
                            style={{width:'100%',padding:'8px',borderRadius:7,background:'rgba(239,68,68,.08)',border:`1px dashed rgba(239,68,68,.3)`,color:RED,fontSize:11,cursor:'pointer',fontWeight:700}}>
                            {isGen?'Generating...':'+ Generate'}
                          </button>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Legend */}
      <div style={{display:'flex',gap:20,marginTop:14,fontSize:11,color:DIM}}>
        {[{icon:'✅',label:'Signed & received'},{icon:'⏳',label:'Generated, pending sub signature'},{icon:'🔴',label:'Not yet generated'}].map(l=>(
          <span key={l.label}>{l.icon} {l.label}</span>
        ))}
      </div>

      {/* Generate Modal */}
      {modal&&(
        <div style={{position:'fixed' as const,inset:0,background:'rgba(0,0,0,.7)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:200}}>
          <div style={{background:RAISED,border:`1px solid ${BORDER}`,borderRadius:12,padding:28,width:440,maxWidth:'90vw'}}>
            <div style={{fontWeight:800,fontSize:16,color:TEXT,marginBottom:4}}>Generate {WAIVER_LABELS[modal.type]}</div>
            <div style={{fontSize:12,color:DIM,marginBottom:20}}>{modal.sub.name} · {WAIVER_DESC[modal.type]}</div>
            <div style={{display:'flex',flexDirection:'column' as const,gap:14}}>
              {[
                {label:'Amount',elem:<input type="number" value={amount} onChange={e=>setAmount(e.target.value)} style={{width:'100%',padding:'8px 12px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:TEXT,fontSize:13,outline:'none'}}/>},
                {label:'Through Date',elem:<input type="date" value={throughDate} onChange={e=>setThroughDate(e.target.value)} style={{width:'100%',padding:'8px 12px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:TEXT,fontSize:13,outline:'none'}}/>},
                {label:'State',elem:<select value={state} onChange={e=>setState(e.target.value)} style={{width:'100%',padding:'8px 12px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:TEXT,fontSize:13}}>{['AZ','CA','TX','NV','CO','FL','WA','OR','UT','NM','OTHER'].map(s=><option key={s}>{s}</option>)}</select>},
              ].map(f=>(
                <div key={f.label}>
                  <label style={{display:'block',fontSize:11,fontWeight:700,color:DIM,textTransform:'uppercase' as const,letterSpacing:.5,marginBottom:5}}>{f.label}</label>
                  {f.elem}
                </div>
              ))}
            </div>
            <div style={{background:'rgba(212,160,23,.06)',border:'1px solid rgba(212,160,23,.2)',borderRadius:7,padding:'10px 12px',margin:'16px 0',fontSize:11,color:DIM}}>
              📋 Uses {state} statutory form. PDF generated + emailed to sub for e-signature.
            </div>
            <div style={{display:'flex',gap:10}}>
              <button onClick={()=>generateWaiver(modal.sub,modal.type,parseFloat(amount)||0,throughDate)}
                style={{flex:1,padding:'10px 0',background:`linear-gradient(135deg,${GOLD},#F0C040)`,border:'none',borderRadius:7,color:'#0d1117',fontWeight:800,fontSize:13,cursor:'pointer'}}>
                Generate PDF + Send to Sub
              </button>
              <button onClick={()=>setModal(null)} style={{padding:'10px 16px',background:DARK,border:`1px solid ${BORDER}`,borderRadius:7,color:DIM,fontSize:13,cursor:'pointer'}}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
