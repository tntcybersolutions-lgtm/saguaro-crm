# Autopilot AI Engine

This bundle includes:

- `supabase/migrations/20260307_autopilot.sql`
- `src/lib/supabase/admin.ts`
- `src/lib/autopilot/engine.ts`
- `src/app/api/internal/autopilot/run/route.ts`
- `scripts/run-autopilot.ts`

## What it does

- scans overdue RFIs
- scans unpaid invoices
- scans schedule slippage
- scans unresolved field issues
- writes/upserts alerts into `autopilot_alerts`
- auto-resolves stale alerts when a risk condition clears
- writes run history into `autopilot_runs`
- creates project-level rollup alerts when risk concentration increases

## Required environment variables

- `NEXT_PUBLIC_SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `AUTOPILOT_CRON_SECRET`

## Run manually

```bash
npx tsx scripts/run-autopilot.ts <tenant-id> [project-id]
```

## HTTP trigger

```bash
curl -X POST "https://your-app.example.com/api/internal/autopilot/run" \
  -H "Authorization: Bearer $AUTOPILOT_CRON_SECRET" \
  -H "Content-Type: application/json" \
  -d '{"tenantId":"<tenant-id>","projectId":"<project-id-optional>"}'
```

## Important mapping note

The engine assumes canonical tables named:

- `rfis`
- `invoices`
- `schedule_tasks`
- `field_issues`
- `tenants` (only for the optional CLI all-tenant loop)

If your schema uses different names or column labels, only the four source queries and the row field mappings in `engine.ts` need to be adjusted.
