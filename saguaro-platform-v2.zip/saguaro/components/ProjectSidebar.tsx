'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

interface ProjectSidebarProps {
  tenantSlug: string;
  projectId: string;
  projectName: string;
  projectNumber: string;
  status: string;
  alertCount?: number;
}

const PROJECT_TABS = [
  { label: 'Overview', slug: '', icon: '◈' },
  { label: 'Autopilot', slug: 'autopilot', icon: '⚡', badge: true },
  { label: 'Schedule', slug: 'schedule', icon: '◷' },
  { label: 'Financials', slug: 'financials', icon: '◉' },
  { label: 'Change Orders', slug: 'change-orders', icon: '⊕' },
  { label: 'Procurement', slug: 'procurement', icon: '⬦' },
  { label: 'RFIs', slug: 'rfis', icon: '◳' },
  { label: 'Submittals', slug: 'submittals', icon: '◨' },
  { label: 'Field', slug: 'field-issues', icon: '⚑' },
  { label: 'Daily Logs', slug: 'daily-logs', icon: '▦' },
  { label: 'Photos', slug: 'photos', icon: '⬜' },
  { label: 'Quality', slug: 'quality', icon: '◈' },
  { label: 'Safety', slug: 'safety', icon: '◎' },
  { label: 'Permits', slug: 'permits', icon: '◑' },
  { label: 'Inspections', slug: 'inspections', icon: '✓' },
  { label: 'Documents', slug: 'documents', icon: '▣' },
  { label: 'Drawings', slug: 'drawings', icon: '◫' },
  { label: 'Systems / LV', slug: 'systems', icon: '⬡' },
  { label: 'Meetings', slug: 'meetings', icon: '◷' },
  { label: 'Closeout', slug: 'closeout', icon: '★' },
  { label: 'Bid Packages', slug: 'bid-packages', icon: '⊞' },
];

export default function ProjectSidebar({ tenantSlug, projectId, projectName, projectNumber, status, alertCount }: ProjectSidebarProps) {
  const pathname = usePathname();
  const base = `/${tenantSlug}/app/projects/${projectId}`;

  return (
    <div style={{ borderRight: '1px solid var(--border-color)', minHeight: '100vh', width: 200, background: 'white' }}>
      <div style={{ padding: '16px', borderBottom: '1px solid var(--border-color)' }}>
        <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{projectNumber}</div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, marginTop: 2, lineHeight: 1.3 }}>{projectName}</div>
        <span className={`badge badge-${status === 'active' ? 'green' : status === 'precon' ? 'blue' : 'gray'}`} style={{ marginTop: 6 }}>{status}</span>
      </div>
      <nav style={{ padding: '8px 0' }}>
        {PROJECT_TABS.map(tab => {
          const href = tab.slug ? `${base}/${tab.slug}` : base;
          const isActive = tab.slug ? pathname.startsWith(`${base}/${tab.slug}`) : pathname === base;
          return (
            <Link
              key={tab.slug}
              href={href}
              className={`sidebar-item ${isActive ? 'active' : ''}`}
              style={{ margin: '1px 6px', padding: '7px 12px', fontSize: 12 }}
            >
              <span style={{ fontSize: 11, opacity: 0.6 }}>{tab.icon}</span>
              {tab.label}
              {tab.badge && alertCount && alertCount > 0 ? <span className="sidebar-badge">{alertCount}</span> : null}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
