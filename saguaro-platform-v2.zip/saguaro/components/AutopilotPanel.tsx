'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getSupabaseClient } from '../lib/supabaseClient';

type Alert = {
  id: string;
  title: string;
  summary: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'acknowledged' | 'resolved' | 'dismissed';
  rule_code: string;
  entity_type: string;
  last_detected_at: string;
  project_id: string | null;
};

type Props = {
  tenantId: string;
  projectId?: string;
  tenantSlug: string;
  compact?: boolean;
};

const SEV_ORDER = { critical: 0, high: 1, medium: 2, low: 3 };

const SEV_STYLES: Record<string, { badge: string; dot: string }> = {
  critical: { badge: 'badge-critical', dot: 'dot-critical' },
  high:     { badge: 'badge-red',      dot: 'dot-red' },
  medium:   { badge: 'badge-yellow',   dot: 'dot-yellow' },
  low:      { badge: 'badge-muted',    dot: 'dot-muted' },
};

export function AutopilotPanel({ tenantId, projectId, tenantSlug, compact }: Props) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
  }, [tenantId, projectId]);

  async function loadAlerts() {
    const supabase = getSupabaseClient();
    let query = supabase
      .from('autopilot_alerts')
      .select('*')
      .eq('tenant_id', tenantId)
      .in('status', ['open', 'acknowledged'])
      .order('severity', { ascending: true })
      .limit(compact ? 5 : 50);

    if (projectId) query = query.eq('project_id', projectId);

    const { data } = await query;
    setAlerts((data ?? []).sort((a, b) =>
      (SEV_ORDER[a.severity as keyof typeof SEV_ORDER] ?? 3)
      - (SEV_ORDER[b.severity as keyof typeof SEV_ORDER] ?? 3)
    ));
    setLoading(false);
  }

  async function acknowledge(id: string) {
    const supabase = getSupabaseClient();
    await supabase.from('autopilot_alerts').update({ status: 'acknowledged' }).eq('id', id);
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'acknowledged' as const } : a));
  }

  const criticalCount = alerts.filter(a => a.severity === 'critical').length;
  const highCount = alerts.filter(a => a.severity === 'high').length;

  if (loading) return (
    <div className="card" style={{ padding: 16 }}>
      <div style={{ color: 'var(--sag-text-mute)', fontSize: 13 }}>Loading autopilot...</div>
    </div>
  );

  const alertsPageHref = projectId
    ? `/${tenantSlug}/app/projects/${projectId}/autopilot-alerts`
    : `/${tenantSlug}/app/autopilot`;

  return (
    <div className="card">
      <div className="card-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            background: criticalCount > 0 ? 'rgba(255,59,59,0.15)' : 'var(--sag-blue-glow)',
            borderRadius: 6,
            padding: '4px 8px',
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <span style={{ fontSize: 14 }}>⚡</span>
            <span style={{
              fontSize: 12, fontWeight: 700,
              color: criticalCount > 0 ? 'var(--sag-critical)' : 'var(--sag-blue-light)',
              fontFamily: 'var(--font-display)',
            }}>AUTOPILOT</span>
          </div>
          {criticalCount > 0 && (
            <span className={`badge badge-critical pulse-critical`}>{criticalCount} CRITICAL</span>
          )}
        </div>
        <Link href={alertsPageHref} className="btn btn-ghost btn-sm">View All</Link>
      </div>

      {alerts.length === 0 ? (
        <div style={{
          textAlign: 'center',
          padding: '24px 0',
          color: 'var(--sag-text-dim)',
          fontSize: 13,
        }}>
          <div style={{ fontSize: 24, marginBottom: 8 }}>✓</div>
          No active alerts — all systems normal
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {alerts.map(alert => {
            const styles = SEV_STYLES[alert.severity] ?? SEV_STYLES.low;
            return (
              <div key={alert.id} style={{
                background: 'var(--sag-raised)',
                border: `1px solid var(--sag-border)`,
                borderLeft: `3px solid ${alert.severity === 'critical' ? 'var(--sag-critical)' : alert.severity === 'high' ? 'var(--sag-red)' : alert.severity === 'medium' ? 'var(--sag-yellow)' : 'var(--sag-muted)'}`,
                borderRadius: '0 6px 6px 0',
                padding: '10px 12px',
              }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                      <span className={`badge ${styles.badge}`} style={{ flexShrink: 0 }}>{alert.severity}</span>
                      <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--sag-text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {alert.title}
                      </span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--sag-text-dim)', lineHeight: 1.4 }}>
                      {alert.summary}
                    </div>
                  </div>
                  {alert.status === 'open' && (
                    <button
                      className="btn btn-ghost btn-sm"
                      onClick={() => acknowledge(alert.id)}
                      style={{ flexShrink: 0, fontSize: 11 }}
                    >
                      ACK
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {compact && alerts.length > 5 && (
        <div style={{ marginTop: 10, textAlign: 'center' }}>
          <Link href={alertsPageHref} style={{ fontSize: 12, color: 'var(--sag-blue-light)' }}>
            +{alerts.length - 5} more alerts →
          </Link>
        </div>
      )}
    </div>
  );
}
