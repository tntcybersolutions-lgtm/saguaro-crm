'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ReactNode, useState } from 'react';
import { useTenantRole } from '../lib/useTenantRole';

interface NavItem {
  label: string;
  href: string;
  icon: string;
  badge?: number;
  roles?: string[];
}

const NAV_SECTIONS = [
  {
    label: 'Operations',
    items: [
      { label: 'Dashboard', href: '/app', icon: '◈' },
      { label: 'Portfolio', href: '/app/projects', icon: '⬡' },
      { label: 'Work Queue', href: '/app/work', icon: '⊞' },
    ],
  },
  {
    label: 'Project',
    items: [
      { label: 'Schedule', href: '#', icon: '◷' },
      { label: 'Financials', href: '#', icon: '◉' },
      { label: 'Change Orders', href: '#', icon: '⊕' },
      { label: 'Procurement', href: '#', icon: '⬦' },
    ],
  },
  {
    label: 'Field',
    items: [
      { label: 'Daily Logs', href: '#', icon: '▦' },
      { label: 'Photos', href: '#', icon: '⬜' },
      { label: 'RFIs', href: '#', icon: '◳' },
      { label: 'Submittals', href: '#', icon: '◨' },
      { label: 'Field Issues', href: '#', icon: '⚑', badge: 3 },
    ],
  },
  {
    label: 'Quality & Safety',
    items: [
      { label: 'Quality', href: '#', icon: '◈' },
      { label: 'Safety', href: '#', icon: '◎' },
      { label: 'Inspections', href: '#', icon: '◉' },
    ],
  },
  {
    label: 'Business',
    items: [
      { label: 'Compliance', href: '/app/compliance', icon: '◑' },
      { label: 'Inventory', href: '/app/inventory', icon: '▣' },
      { label: 'Reports', href: '/app/reports', icon: '◫' },
      { label: 'Admin', href: '/app/admin', icon: '⚙' },
    ],
  },
];

export default function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { role, isMaster } = useTenantRole();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="app-shell">
      {/* Sidebar */}
      <aside className={`app-sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-logo">
          <div className="sidebar-logo-mark">S</div>
          <div>
            <div className="sidebar-logo-text">SAGUARO</div>
            <div className="sidebar-logo-sub">Construction Intelligence</div>
          </div>
        </div>

        <nav className="sidebar-nav">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label} className="sidebar-section">
              <div className="sidebar-section-label">{section.label}</div>
              {section.items.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`sidebar-item ${pathname === item.href ? 'active' : ''}`}
                >
                  <span className="sidebar-item-icon">{item.icon}</span>
                  {item.label}
                  {item.badge ? <span className="sidebar-badge">{item.badge}</span> : null}
                </Link>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-footer">
          {isMaster && (
            <div style={{ padding: '6px 8px', background: 'rgba(201,102,60,0.15)', borderRadius: '6px', marginBottom: '8px' }}>
              <span style={{ fontSize: '10px', color: '#e8895c', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                ★ Master Control
              </span>
            </div>
          )}
          <Link href="/app/profile" className="sidebar-item">
            <span className="sidebar-item-icon">◎</span>
            Profile & Settings
          </Link>
          <Link href="/logout" className="sidebar-item">
            <span className="sidebar-item-icon">→</span>
            Sign Out
          </Link>
        </div>
      </aside>

      {/* Main */}
      <main className="app-main">
        <header className="app-topbar">
          <button
            className="btn btn-ghost btn-icon"
            style={{ display: 'none' }}
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            ☰
          </button>
          <div style={{ flex: 1 }}>
            <input
              className="form-input"
              placeholder="Search projects, RFIs, documents…"
              style={{ maxWidth: 360, height: 34 }}
            />
          </div>
          <button className="btn btn-ghost btn-icon" title="Notifications" style={{ position: 'relative' }}>
            🔔
            <span style={{ position: 'absolute', top: 4, right: 4, width: 8, height: 8, borderRadius: '50%', background: 'var(--color-clay-700)' }} />
          </button>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--color-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: 13, fontWeight: 700 }}>
            U
          </div>
        </header>

        <div className="app-content">
          {children}
        </div>
      </main>
    </div>
  );
}
