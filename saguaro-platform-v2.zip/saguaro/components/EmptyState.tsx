import { ReactNode } from 'react';

interface EmptyStateProps {
  icon?: string;
  title: string;
  body?: string;
  action?: ReactNode;
}

export default function EmptyState({ icon = '◫', title, body, action }: EmptyStateProps) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon" style={{ fontSize: 40 }}>{icon}</div>
      <div className="empty-state-title">{title}</div>
      {body && <p className="empty-state-body">{body}</p>}
      {action}
    </div>
  );
}
