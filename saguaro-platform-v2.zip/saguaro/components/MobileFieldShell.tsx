'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';

type MobileFieldShellProps = {
  tenantSlug: string;
  projectId: string;
  projectName: string;
  children: React.ReactNode;
};

const MOBILE_NAV = [
  { label: 'Home',     path: '',             icon: '⬡' },
  { label: 'Photos',   path: '/photos',      icon: '📷' },
  { label: 'Logs',     path: '/daily-logs',  icon: '📋' },
  { label: 'Issues',   path: '/field-issues',icon: '⚠' },
  { label: 'Schedule', path: '/schedule',    icon: '📅' },
  { label: 'Inspect',  path: '/inspections', icon: '✓' },
];

export function MobileFieldShell({ tenantSlug, projectId, projectName, children }: MobileFieldShellProps) {
  const pathname = usePathname();
  const [isOnline, setIsOnline] = useState(true);

  const base = `/${tenantSlug}/mobile/${projectId}`;

  useEffect(() => {
    const update = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    setIsOnline(navigator.onLine);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, []);

  const isActive = (path: string) => {
    if (path === '') return pathname === base;
    return pathname.startsWith(`${base}${path}`);
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--sag-canvas)', display: 'flex', flexDirection: 'column' }}>
      {!isOnline && (
        <div className="offline-banner">📡 Offline — changes will sync when connected</div>
      )}

      {/* Mobile topbar */}
      <header style={{
        background: 'var(--sag-void)',
        borderBottom: '1px solid var(--sag-border)',
        padding: '12px 16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        position: 'sticky',
        top: 0,
        zIndex: 20,
      }}>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14 }}>SAGUARO</div>
          <div style={{ fontSize: 11, color: 'var(--sag-text-dim)', marginTop: 1 }}>{projectName}</div>
        </div>
        <Link
          href={`/${tenantSlug}/app/projects/${projectId}`}
          style={{ fontSize: 11, color: 'var(--sag-text-dim)', padding: '4px 8px', border: '1px solid var(--sag-border)', borderRadius: 4, textDecoration: 'none' }}
        >
          Desktop →
        </Link>
      </header>

      {/* Content */}
      <main style={{ flex: 1, padding: '16px', paddingBottom: 80, overflowY: 'auto' }}>
        {children}
      </main>

      {/* Bottom nav */}
      <nav className="mobile-bottom-nav">
        {MOBILE_NAV.map((item) => (
          <Link
            key={item.path}
            href={`${base}${item.path}`}
            className={`mobile-nav-item ${isActive(item.path) ? 'active' : ''}`}
          >
            <span style={{ fontSize: 18 }}>{item.icon}</span>
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
