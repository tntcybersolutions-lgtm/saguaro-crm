'use client';
import { useEffect, useState } from 'react';
import { getSupabaseClient } from './supabaseClient';

export type TenantRole = {
  userId: string;
  tenantId: string | null;
  role: string;
  portal: string;
  isMaster: boolean;
  isLoading: boolean;
};

export function useTenantRole(): TenantRole {
  const [state, setState] = useState<TenantRole>({
    userId: '',
    tenantId: null,
    role: 'customer',
    portal: 'customer',
    isMaster: false,
    isLoading: true,
  });

  useEffect(() => {
    const supabase = getSupabaseClient();
    
    async function loadRole() {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setState(prev => ({ ...prev, isLoading: false }));
        return;
      }

      const { data: user } = await supabase
        .from('users')
        .select('id, tenant_id, role, portal, is_master')
        .eq('id', session.user.id)
        .single();

      if (user) {
        setState({
          userId: user.id,
          tenantId: user.tenant_id,
          role: user.role,
          portal: user.portal,
          isMaster: user.is_master,
          isLoading: false,
        });
      }
    }

    loadRole();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      loadRole();
    });

    return () => subscription.unsubscribe();
  }, []);

  return state;
}
