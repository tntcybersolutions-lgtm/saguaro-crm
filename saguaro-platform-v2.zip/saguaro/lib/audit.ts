import { supabaseAdmin } from './supabaseAdmin';

interface AuditEntry {
  tenantId: string;
  userId?: string;
  impersonatedBy?: string;
  portal?: 'internal' | 'customer' | 'trade';
  action: string;
  tableName?: string;
  recordId?: string;
  oldData?: Record<string, unknown>;
  newData?: Record<string, unknown>;
  ipAddress?: string;
  overrideReason?: string;
}

export async function auditLog(entry: AuditEntry) {
  const diff = entry.oldData && entry.newData
    ? computeDiff(entry.oldData, entry.newData)
    : undefined;

  const { error } = await supabaseAdmin.from('audit_logs').insert({
    tenant_id: entry.tenantId,
    user_id: entry.userId ?? null,
    impersonated_by: entry.impersonatedBy ?? null,
    portal: entry.portal ?? null,
    action: entry.action,
    table_name: entry.tableName ?? null,
    record_id: entry.recordId ?? null,
    old_data: entry.oldData ?? null,
    new_data: entry.newData ?? null,
    diff: diff ?? null,
    ip_address: entry.ipAddress ?? null,
    override_reason: entry.overrideReason ?? null,
  });

  if (error) {
    console.error('[audit] Failed to write audit log:', error.message);
  }
}

function computeDiff(
  oldData: Record<string, unknown>,
  newData: Record<string, unknown>
): Record<string, { from: unknown; to: unknown }> {
  const diff: Record<string, { from: unknown; to: unknown }> = {};
  const allKeys = new Set([...Object.keys(oldData), ...Object.keys(newData)]);
  
  for (const key of allKeys) {
    if (JSON.stringify(oldData[key]) !== JSON.stringify(newData[key])) {
      diff[key] = { from: oldData[key], to: newData[key] };
    }
  }
  return diff;
}
