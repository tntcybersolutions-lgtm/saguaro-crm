/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { typedRoutes: false },
  images: { domains: ['your-supabase-project.supabase.co'] },
};
module.exports = nextConfig;
