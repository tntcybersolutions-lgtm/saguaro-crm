'use client';
import { useState } from 'react';

export default function RequestAccessPage() {
  const [form, setForm] = useState({ name: '', email: '', company: '', role: 'trade', message: '' });
  const [sent, setSent] = useState(false);

  async function submit() {
    // In production: POST to /api/request-access → email admin
    setSent(true);
  }

  if (sent) return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0f172a, #1e3a5f)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 20px' }}>
      <div style={{ background: 'white', borderRadius: 16, padding: 48, maxWidth: 440, width: '100%', textAlign: 'center' }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>✓</div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, color: '#16a34a', marginBottom: 8 }}>Request Sent!</h2>
        <p style={{ color: '#6b7280', fontSize: 14 }}>Your access request has been submitted. The project manager will send you an invitation within 1 business day.</p>
        <a href="/" style={{ display: 'inline-block', marginTop: 20, padding: '10px 24px', background: '#1e3a5f', color: 'white', borderRadius: 8, textDecoration: 'none', fontWeight: 600, fontSize: 14 }}>Back to Login</a>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0f172a, #1e3a5f)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 20px' }}>
      <div style={{ background: 'white', borderRadius: 16, padding: 40, maxWidth: 480, width: '100%' }}>
        <div style={{ marginBottom: 28, textAlign: 'center' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.5rem', color: '#1e3a5f', marginBottom: 6 }}>⬡ Request Portal Access</div>
          <p style={{ fontSize: 13, color: '#6b7280' }}>Fill out this form and your project manager will send you an invitation.</p>
        </div>
        {[
          { label: 'Full Name', key: 'name', placeholder: 'John Smith' },
          { label: 'Email Address', key: 'email', placeholder: 'john@company.com' },
          { label: 'Company', key: 'company', placeholder: 'Smith Framing LLC' },
        ].map(f => (
          <div key={f.key} style={{ marginBottom: 14 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 5 }}>{f.label}</label>
            <input value={form[f.key as keyof typeof form]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} style={{ width: '100%', padding: '11px 13px', border: '1.5px solid #d1d5db', borderRadius: 8, fontSize: 14, boxSizing: 'border-box' }} />
          </div>
        ))}
        <div style={{ marginBottom: 14 }}>
          <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 5 }}>I am a…</label>
          <select value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))} style={{ width: '100%', padding: '11px 13px', border: '1.5px solid #d1d5db', borderRadius: 8, fontSize: 14, boxSizing: 'border-box' }}>
            <option value="trade">Subcontractor / Trade</option>
            <option value="customer">Project Owner / Client</option>
            <option value="internal">General Contractor Staff</option>
          </select>
        </div>
        <div style={{ marginBottom: 24 }}>
          <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 5 }}>Message (optional)</label>
          <textarea rows={3} value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))} placeholder="Project name or other details…" style={{ width: '100%', padding: '11px 13px', border: '1.5px solid #d1d5db', borderRadius: 8, fontSize: 14, fontFamily: 'inherit', boxSizing: 'border-box' }} />
        </div>
        <button onClick={submit} disabled={!form.name || !form.email} style={{ width: '100%', padding: '13px', background: !form.name || !form.email ? '#d1d5db' : '#1e3a5f', color: 'white', border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>
          Submit Request →
        </button>
        <p style={{ textAlign: 'center', marginTop: 16, fontSize: 12, color: '#9ca3af' }}>
          Already have access? <a href="/login" style={{ color: '#1e3a5f', fontWeight: 600 }}>Sign in here</a>
        </p>
      </div>
    </div>
  );
}
