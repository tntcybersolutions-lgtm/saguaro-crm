import { createServerSupabase } from '../../../../lib/serverAuth';
import AppShell from '../../../../components/AppShell';
import PageHeader from '../../../../components/PageHeader';

export default async function AdminAuditPage() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase.from('users').select('tenant_id, is_master').eq('id', user!.id).single();

  if (!profile?.is_master) {
    return (
      <AppShell>
        <PageHeader title="Audit Log" breadcrumb={[{ label: 'Admin', href: '/app/admin' }, { label: 'Audit Log' }]} />
        <div className="card" style={{ padding: 48, textAlign: 'center', color: 'var(--text-muted)' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>🔒</div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 6 }}>Master Admin Only</div>
          <p style={{ fontSize: 13 }}>The full audit log is accessible only to Master Admin (Robert). Contact your administrator for access.</p>
        </div>
      </AppShell>
    );
  }

  const { data: logs } = await supabase
    .from('audit_logs')
    .select('*')
    .eq('tenant_id', profile.tenant_id)
    .order('created_at', { ascending: false })
    .limit(200);

  const ACTION_COLORS: Record<string, string> = { create: 'green', update: 'blue', delete: 'red', approve: 'green', reject: 'red', login: 'gray', export: 'clay' };

  return (
    <AppShell>
      <PageHeader title="Audit Log"
        subtitle={`Last 200 events · Master admin view`}
        breadcrumb={[{ label: 'Admin', href: '/app/admin' }, { label: 'Audit Log' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <select className="form-select" style={{ height: 34, width: 'auto' }}>
              <option>All Actions</option>
              <option>create</option><option>update</option><option>delete</option><option>approve</option><option>login</option><option>export</option>
            </select>
            <button className="btn btn-secondary btn-sm">↓ Export CSV</button>
          </div>
        }
      />
      <div className="card">
        <div className="table-wrap" style={{ border: 'none' }}>
          <table className="table">
            <thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Table</th><th>Record</th><th>Changes</th><th>IP</th></tr></thead>
            <tbody>
              {(logs ?? []).map(log => (
                <tr key={log.id}>
                  <td style={{ fontSize: 11, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{new Date(log.created_at).toLocaleString()}</td>
                  <td style={{ fontSize: 12 }}>{log.actor_id?.slice(0,8) ?? 'system'}</td>
                  <td><span className={`badge badge-${ACTION_COLORS[log.action] ?? 'gray'}`} style={{ fontSize: 11 }}>{log.action}</span></td>
                  <td style={{ fontFamily: 'monospace', fontSize: 11, color: 'var(--text-muted)' }}>{log.table_name}</td>
                  <td style={{ fontFamily: 'monospace', fontSize: 11, color: 'var(--text-muted)', maxWidth: 100 }} className="truncate">{log.record_id?.slice(0,12) ?? '—'}</td>
                  <td style={{ fontSize: 11, color: 'var(--text-muted)', maxWidth: 200 }} className="truncate">
                    {log.diff ? JSON.stringify(log.diff).slice(0, 80) : '—'}
                  </td>
                  <td style={{ fontFamily: 'monospace', fontSize: 11, color: 'var(--text-muted)' }}>{log.ip_address ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
