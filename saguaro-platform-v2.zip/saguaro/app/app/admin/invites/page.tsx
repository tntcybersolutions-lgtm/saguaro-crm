import { createServerSupabase } from '../../../../lib/serverAuth';
import AppShell from '../../../../components/AppShell';
import PageHeader from '../../../../components/PageHeader';

export default async function AdminInvitesPage() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase.from('users').select('tenant_id, role, is_master').eq('id', user!.id).single();
  const { data: invites } = await supabase.from('tenant_invites').select('*').eq('tenant_id', profile!.tenant_id).order('created_at', { ascending: false });

  return (
    <AppShell>
      <PageHeader title="Team Invitations"
        subtitle="Invite team members to internal, customer, and trade portals"
        breadcrumb={[{ label: 'Admin', href: '/app/admin' }, { label: 'Invitations' }]}
        actions={<button className="btn btn-primary btn-sm">+ Send Invite</button>}
      />
      <div className="card">
        <div className="table-wrap" style={{ border: 'none' }}>
          <table className="table">
            <thead><tr><th>Email</th><th>Portal</th><th>Role</th><th>Status</th><th>Sent</th><th>Expires</th><th>Actions</th></tr></thead>
            <tbody>
              {(invites ?? []).length === 0 ? (
                <tr><td colSpan={7} style={{ textAlign: 'center', padding: '32px', color: 'var(--text-muted)' }}>No invitations sent yet.</td></tr>
              ) : (invites ?? []).map(inv => {
                const expired = inv.expires_at && new Date(inv.expires_at) < new Date();
                return (
                  <tr key={inv.id}>
                    <td style={{ fontWeight: 500 }}>{inv.email}</td>
                    <td><span className={`badge badge-${inv.portal_type === 'internal' ? 'blue' : inv.portal_type === 'customer' ? 'green' : 'clay'}`}>{inv.portal_type}</span></td>
                    <td><span className="badge badge-gray">{inv.role}</span></td>
                    <td>
                      {inv.accepted_at
                        ? <span className="badge badge-green">Accepted</span>
                        : expired
                          ? <span className="badge badge-red">Expired</span>
                          : <span className="badge badge-yellow">Pending</span>}
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{new Date(inv.created_at).toLocaleDateString()}</td>
                    <td style={{ fontSize: 12, color: expired ? 'var(--color-danger-600)' : 'var(--text-muted)' }}>{inv.expires_at ? new Date(inv.expires_at).toLocaleDateString() : '—'}</td>
                    <td>
                      {!inv.accepted_at && !expired && <button className="btn btn-ghost btn-sm">Resend</button>}
                      {expired && <button className="btn btn-primary btn-sm">Resend</button>}
                      {!inv.accepted_at && <button className="btn btn-ghost btn-sm" style={{ color: 'var(--color-danger-600)' }}>Revoke</button>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
