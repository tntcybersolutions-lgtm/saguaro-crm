import AppShell from '../../../components/AppShell';
import PageHeader from '../../../components/PageHeader';

const REPORTS = [
  { id: 'project_health', label: 'Portfolio Health Report', desc: 'All projects: budget, schedule, risk scores, open alerts. Weekly snapshot.', icon: '⬡', color: '#1e4d8c', tags: ['portfolio','executive'] },
  { id: 'financial_summary', label: 'Financial Summary', desc: 'Budget vs actual, committed costs, retainage, forecasted EAC across all projects.', icon: '▦', color: '#16a34a', tags: ['finance','accounting'] },
  { id: 'ar_aging', label: 'A/R Aging Report', desc: 'Outstanding invoices by age bucket (30/60/90/120+ days). Retainage held.', icon: '◕', color: '#d97706', tags: ['finance','ar'] },
  { id: 'subcontractor_payments', label: 'Subcontractor Payment Status', desc: 'All sub invoices, approval status, lien waivers received/missing.', icon: '◳', color: '#7c3aed', tags: ['finance','compliance'] },
  { id: 'vendor_compliance', label: 'Vendor Compliance Matrix', desc: 'COI, W-9, and tax cert status for all active vendors and subs.', icon: '◑', color: '#c9663c', tags: ['compliance','legal'] },
  { id: 'rfi_log', label: 'RFI Log', desc: 'All RFIs with status, priority, age, and outstanding responses.', icon: '◳', color: '#0284c7', tags: ['field','pm'] },
  { id: 'schedule_variance', label: 'Schedule Variance Report', desc: 'Critical path tasks, baseline vs planned vs actual, days slipped per phase.', icon: '◷', color: '#16a34a', tags: ['schedule','pm'] },
  { id: 'safety_summary', label: 'Safety Summary', desc: 'Incidents, near-misses, OSHA recordables, toolbox talks by project.', icon: '⚑', color: '#dc2626', tags: ['safety','compliance'] },
  { id: 'closeout_readiness', label: 'Closeout Readiness Report', desc: 'Which projects are ready for closeout: punch status, permits, O&M manuals.', icon: '◈', color: '#16a34a', tags: ['closeout','pm'] },
  { id: 'claims_readiness', label: 'Claims Readiness Pack', desc: 'Compiles all RFIs, change orders, daily logs, photos, and correspondence for a project into a claims-ready package.', icon: '◫', color: '#991b1b', tags: ['legal','claims'] },
];

export default function AdminReportsPage() {
  return (
    <AppShell>
      <PageHeader title="Reports"
        subtitle="Generate, schedule, and export platform reports"
        breadcrumb={[{ label: 'Admin', href: '/app/admin' }, { label: 'Reports' }]}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 14 }}>
        {REPORTS.map(r => (
          <div key={r.id} className="card" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            <div style={{ padding: '18px 20px', flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 10 }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: `${r.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>{r.icon}</div>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{r.label}</div>
                  <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.5 }}>{r.desc}</p>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                {r.tags.map(t => <span key={t} className="badge badge-gray" style={{ fontSize: 10 }}>{t}</span>)}
              </div>
            </div>
            <div style={{ padding: '12px 20px', borderTop: '1px solid var(--border-color)', display: 'flex', gap: 8 }}>
              <button className="btn btn-primary btn-sm" style={{ flex: 1 }}>Run Report</button>
              <button className="btn btn-ghost btn-sm">Schedule</button>
              <button className="btn btn-ghost btn-sm">↓ CSV</button>
            </div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
