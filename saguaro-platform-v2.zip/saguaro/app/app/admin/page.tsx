import AppShell from '../../../components/AppShell';
import PageHeader from '../../../components/PageHeader';
import { createServerSupabase } from '../../../lib/serverAuth';

export default async function AdminPage() {
  const supabase = await createServerSupabase();
  const { data: users } = await supabase.from('users').select('*').order('created_at', { ascending: false });

  return (
    <AppShell>
      <PageHeader title="Admin" subtitle="Manage users, roles, and settings"
        actions={<a href="/app/admin/invites" className="btn btn-primary btn-sm">+ Invite User</a>}
      />
      <div className="table-wrap">
        <table className="table">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Portal</th><th>Master</th><th>Active</th></tr></thead>
          <tbody>
            {(users ?? []).map(u => (
              <tr key={u.id}>
                <td style={{ fontWeight: 500 }}>{u.full_name}</td>
                <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{u.email}</td>
                <td><span className="badge badge-blue">{u.role}</span></td>
                <td><span className="badge badge-gray">{u.portal}</span></td>
                <td>{u.is_master ? <span className="badge badge-clay">★ Master</span> : '—'}</td>
                <td><span className={`badge badge-${u.is_active ? 'green' : 'red'}`}>{u.is_active ? 'Active' : 'Inactive'}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
