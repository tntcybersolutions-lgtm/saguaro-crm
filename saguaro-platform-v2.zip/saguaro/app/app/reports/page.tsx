import AppShell from '../../../components/AppShell';
import PageHeader from '../../../components/PageHeader';

const REPORT_TYPES = [
  { title: 'Executive Portfolio Summary', desc: 'All projects: budget, schedule, health scores', icon: '◈', tag: 'Finance' },
  { title: 'Cost Report by Project', desc: 'Budget vs committed vs actuals with variance', icon: '◉', tag: 'Finance' },
  { title: 'RFI Aging Report', desc: 'Open RFIs by age, assigned party, project', icon: '◳', tag: 'Field' },
  { title: 'Schedule Slippage Report', desc: 'Critical path tasks behind baseline', icon: '◷', tag: 'Schedule' },
  { title: 'Compliance Expiry Report', desc: 'COIs and W-9s expiring in 30/60/90 days', icon: '◑', tag: 'Compliance' },
  { title: 'Safety Incident Log', desc: 'All incidents by project, type, severity', icon: '◎', tag: 'Safety' },
  { title: 'Daily Log Summary', desc: 'Field activity and headcount by date range', icon: '▦', tag: 'Field' },
  { title: 'Invoice Aging Report', desc: 'Pending invoices by age and vendor', icon: '⬦', tag: 'Finance' },
];

export default function ReportsPage() {
  return (
    <AppShell>
      <PageHeader title="Reports" subtitle="Generate, export, and schedule reports across all modules" />
      <div className="grid-3" style={{ marginBottom: 24 }}>
        {REPORT_TYPES.map(r => (
          <div key={r.title} className="card" style={{ cursor: 'pointer' }}>
            <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <span style={{ fontSize: 24 }}>{r.icon}</span>
                <span className="badge badge-gray">{r.tag}</span>
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13 }}>{r.title}</div>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.5 }}>{r.desc}</p>
              <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                <button className="btn btn-primary btn-sm">Run Report</button>
                <button className="btn btn-ghost btn-sm">Schedule</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
