import { createServerSupabase } from '../../../lib/serverAuth';
import AppShell from '../../../components/AppShell';
import PageHeader from '../../../components/PageHeader';

export default async function CompliancePage() {
  const supabase = await createServerSupabase();
  const { data: compliance } = await supabase
    .from('vendor_compliance')
    .select('*, companies(name)')
    .order('expiration_date', { ascending: true });

  const today = new Date();
  const in30 = new Date(today.getTime() + 30 * 86400000);

  const expired = (compliance ?? []).filter(c => c.expiration_date && new Date(c.expiration_date) < today).length;
  const expiring = (compliance ?? []).filter(c => c.expiration_date && new Date(c.expiration_date) >= today && new Date(c.expiration_date) <= in30).length;
  const missing = (compliance ?? []).filter(c => c.status === 'missing').length;

  return (
    <AppShell>
      <PageHeader title="Compliance Center" subtitle="Vendor COIs, W-9s, certificates, and employee certifications"
        actions={<button className="btn btn-secondary btn-sm">Export Compliance Packet</button>}
      />

      <div className="stat-cards" style={{ marginBottom: 20 }}>
        {[
          { label: 'Expired Documents', value: expired, color: 'var(--color-danger-600)' },
          { label: 'Expiring in 30 Days', value: expiring, color: 'var(--color-warning-600)' },
          { label: 'Missing Documents', value: missing, color: 'var(--color-clay-700)' },
          { label: 'Active & Compliant', value: (compliance ?? []).filter(c => c.status === 'active').length, color: 'var(--color-success-600)' },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ '--stat-color': s.color } as React.CSSProperties}>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value">{s.value}</div>
          </div>
        ))}
      </div>

      <div className="table-wrap">
        <table className="table">
          <thead><tr><th>Company</th><th>Document Type</th><th>Status</th><th>Expiration</th><th>Gate</th><th>Action</th></tr></thead>
          <tbody>
            {(compliance ?? []).map(c => {
              const isExpired = c.expiration_date && new Date(c.expiration_date) < today;
              const isExpiring = c.expiration_date && new Date(c.expiration_date) <= in30 && !isExpired;
              return (
                <tr key={c.id}>
                  <td style={{ fontWeight: 500 }}>{(c as any).companies?.name ?? '—'}</td>
                  <td><span className="badge badge-gray">{c.doc_type?.toUpperCase()}</span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div className={`sev-dot ${isExpired ? 'sev-critical' : isExpiring ? 'sev-high' : c.status === 'missing' ? 'sev-medium' : 'sev-info'}`} />
                      <span className={`badge badge-${isExpired ? 'critical' : isExpiring ? 'yellow' : c.status === 'active' ? 'green' : 'gray'}`}>{isExpired ? 'Expired' : isExpiring ? 'Expiring' : c.status}</span>
                    </div>
                  </td>
                  <td style={{ fontSize: 12, color: isExpired ? 'var(--color-danger-600)' : isExpiring ? 'var(--color-warning-600)' : undefined }}>
                    {c.expiration_date ? new Date(c.expiration_date).toLocaleDateString() : '—'}
                  </td>
                  <td>
                    <span className={`badge badge-${c.gate_status === 'blocked' ? 'critical' : c.gate_status === 'warning' ? 'yellow' : 'green'}`}>
                      {c.gate_status ?? 'clear'}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-ghost btn-sm">Request Docs</button>
                  </td>
                </tr>
              );
            })}
            {(compliance ?? []).length === 0 && (
              <tr><td colSpan={6} style={{ textAlign: 'center', padding: 32, color: 'var(--text-muted)' }}>No compliance records. Add vendor companies to track compliance.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
