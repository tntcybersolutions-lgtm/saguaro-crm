import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function FinancialsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const [codesRes, invoicesRes] = await Promise.all([
    supabase.from('cost_codes').select('*').eq('project_id', params.projectId).order('code'),
    supabase.from('invoices').select('amount, status, type').eq('project_id', params.projectId),
  ]);

  const codes = codesRes.data ?? [];
  const invoices = invoicesRes.data ?? [];

  const totalBudget = codes.reduce((s, c) => s + Number(c.budget || 0), 0);
  const totalCommitted = codes.reduce((s, c) => s + Number(c.committed || 0), 0);
  const totalActuals = codes.reduce((s, c) => s + Number(c.actuals || 0), 0);
  const totalEAC = codes.reduce((s, c) => s + Number(c.eac || 0), 0);
  const variance = totalBudget - totalCommitted - totalActuals;

  return (
    <AppShell>
      <PageHeader title="Financials" subtitle="Budget, commitments, actuals, forecast, and EAC"
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Financials' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm">Export Cost Report</button>
            <button className="btn btn-primary btn-sm">+ Add Cost Code</button>
          </div>
        }
      />

      {/* Financial KPIs */}
      <div className="stat-cards" style={{ marginBottom: 20 }}>
        {[
          { label: 'Contract Budget', value: `$${(totalBudget/1000).toFixed(0)}K`, color: 'var(--color-blue-700)' },
          { label: 'Committed', value: `$${(totalCommitted/1000).toFixed(0)}K`, color: 'var(--color-clay-700)' },
          { label: 'Actuals', value: `$${(totalActuals/1000).toFixed(0)}K`, color: 'var(--color-warning-600)' },
          { label: 'Variance', value: `${variance >= 0 ? '+' : ''}$${(variance/1000).toFixed(0)}K`, color: variance >= 0 ? 'var(--color-success-600)' : 'var(--color-danger-600)' },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ '--stat-color': s.color } as React.CSSProperties}>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value" style={{ fontSize: '1.4rem' }}>{s.value}</div>
          </div>
        ))}
      </div>

      {codes.length === 0 ? (
        <div className="card"><EmptyState icon="◉" title="No cost codes" body="Add cost codes to track budget, commitments, and actuals." /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Code</th><th>Description</th><th>Phase</th>
                <th style={{ textAlign: 'right' }}>Budget</th>
                <th style={{ textAlign: 'right' }}>Committed</th>
                <th style={{ textAlign: 'right' }}>Actuals</th>
                <th style={{ textAlign: 'right' }}>EAC</th>
                <th style={{ textAlign: 'right' }}>Variance</th>
                <th>Note</th>
              </tr>
            </thead>
            <tbody>
              {codes.map(c => {
                const variance = Number(c.budget || 0) - Number(c.committed || 0) - Number(c.actuals || 0);
                return (
                  <tr key={c.id}>
                    <td style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 600 }}>{c.code}</td>
                    <td style={{ fontWeight: 500 }}>{c.description}</td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{c.phase ?? '—'}</td>
                    <td style={{ textAlign: 'right', fontSize: 13 }}>${Number(c.budget || 0).toLocaleString()}</td>
                    <td style={{ textAlign: 'right', fontSize: 13 }}>${Number(c.committed || 0).toLocaleString()}</td>
                    <td style={{ textAlign: 'right', fontSize: 13 }}>${Number(c.actuals || 0).toLocaleString()}</td>
                    <td style={{ textAlign: 'right', fontSize: 13, fontWeight: 600 }}>${Number(c.eac || 0).toLocaleString()}</td>
                    <td style={{ textAlign: 'right', fontSize: 13, fontWeight: 600, color: variance >= 0 ? 'var(--color-success-600)' : 'var(--color-danger-600)' }}>
                      {variance >= 0 ? '+' : ''}{variance.toLocaleString()}
                    </td>
                    <td style={{ fontSize: 11, color: 'var(--text-muted)', maxWidth: 160 }}>
                      {variance < 0 && !c.variance_note ? <span style={{ color: 'var(--color-danger-600)', fontWeight: 600 }}>Note required</span> : c.variance_note ?? ''}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
