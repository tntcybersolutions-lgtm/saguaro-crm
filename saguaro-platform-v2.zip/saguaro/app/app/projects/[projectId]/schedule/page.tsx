import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const STATUS_BAR: Record<string, string> = { not_started:'var(--color-stone-300)', in_progress:'var(--color-blue-600)', complete:'var(--color-success-600)', on_hold:'var(--color-warning-600)', cancelled:'var(--color-stone-400)' };

export default async function SchedulePage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: tasks } = await supabase.from('schedule_tasks').select('*').eq('project_id', params.projectId).order('planned_start', { ascending: true });

  const overdue = (tasks ?? []).filter(t => t.planned_finish && new Date(t.planned_finish) < new Date() && !['complete','cancelled'].includes(t.status)).length;
  const criticalPath = (tasks ?? []).filter(t => t.is_critical_path).length;

  return (
    <AppShell>
      <PageHeader title="Schedule" subtitle={`${(tasks ?? []).length} tasks · ${overdue} overdue · ${criticalPath} on critical path`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Schedule' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm">📊 Gantt View</button>
            <button className="btn btn-secondary btn-sm">Export</button>
            <button className="btn btn-primary btn-sm">+ Add Task</button>
          </div>
        }
      />
      {(tasks ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="◷" title="No schedule tasks" body="Add tasks to build your project schedule." /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Task</th><th>Phase</th><th>Status</th><th>Progress</th><th>Planned Start</th><th>Planned Finish</th><th>Critical Path</th><th>Assigned</th></tr></thead>
            <tbody>
              {(tasks ?? []).map(t => (
                <tr key={t.id}>
                  <td>
                    <span style={{ fontWeight: 500 }}>{t.name}</span>
                    {t.is_milestone && <span className="badge badge-blue" style={{ marginLeft: 8, fontSize: 10 }}>Milestone</span>}
                  </td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{t.phase ?? '—'}</td>
                  <td><span className={`badge badge-${t.status === 'complete' ? 'green' : t.status === 'in_progress' ? 'blue' : t.status === 'on_hold' ? 'yellow' : 'gray'}`}>{t.status?.replace('_',' ')}</span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 80, height: 6, background: 'var(--border-color)', borderRadius: 3 }}>
                        <div style={{ width: `${t.percent_complete ?? 0}%`, height: '100%', background: STATUS_BAR[t.status] ?? 'var(--color-blue-600)', borderRadius: 3, transition: 'width 0.3s' }} />
                      </div>
                      <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{t.percent_complete ?? 0}%</span>
                    </div>
                  </td>
                  <td style={{ fontSize: 12 }}>{t.planned_start ?? '—'}</td>
                  <td style={{ fontSize: 12, color: t.planned_finish && new Date(t.planned_finish) < new Date() && t.status !== 'complete' ? 'var(--color-danger-600)' : undefined }}>
                    {t.planned_finish ?? '—'}
                  </td>
                  <td>{t.is_critical_path ? <span className="badge badge-red">CP</span> : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>—</span>}</td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{t.trade ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
