import { createServerSupabase } from '../../../../../../lib/serverAuth';
import AppShell from '../../../../../../components/AppShell';
import { notFound } from 'next/navigation';

interface Props { params: { projectId: string; taskId: string } }

export default async function TaskDetailPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: task } = await supabase.from('schedule_tasks').select('*').eq('id', params.taskId).single();
  if (!task) notFound();

  const slipDays = task.baseline_finish && task.planned_finish
    ? Math.round((new Date(task.planned_finish).getTime() - new Date(task.baseline_finish).getTime()) / 86400000)
    : null;

  return (
    <AppShell>
      <div style={{ maxWidth: 760 }}>
        <div style={{ marginBottom: 20 }}>
          <a href={`/app/projects/${params.projectId}/schedule`} style={{ fontSize: 12, color: 'var(--text-muted)' }}>← Back to Schedule</a>
        </div>
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-body">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>{task.phase ?? 'Phase'} · {task.trade ?? '—'}</div>
                <h2 style={{ fontSize: '1.2rem' }}>{task.name}</h2>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {task.is_milestone && <span className="badge badge-blue">Milestone</span>}
                {task.is_critical_path && <span className="badge badge-red">Critical Path</span>}
                <span className={`badge badge-${task.status === 'complete' ? 'green' : task.status === 'in_progress' ? 'blue' : 'gray'}`}>{task.status?.replace(/_/g,' ')}</span>
              </div>
            </div>

            {/* Progress */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)' }}>PROGRESS</span>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{task.percent_complete ?? 0}%</span>
              </div>
              <div style={{ height: 10, background: 'var(--color-stone-100)', borderRadius: 5 }}>
                <div style={{ width: `${task.percent_complete ?? 0}%`, height: '100%', background: 'var(--color-blue-700)', borderRadius: 5 }} />
              </div>
            </div>

            <div className="grid-2" style={{ marginBottom: 20 }}>
              {[
                ['Planned Start', task.planned_start ?? '—'],
                ['Planned Finish', task.planned_finish ?? '—'],
                ['Actual Start', task.actual_start ?? '—'],
                ['Actual Finish', task.actual_finish ?? '—'],
                ['Baseline Finish', task.baseline_finish ?? '—'],
                ['Slip vs Baseline', slipDays !== null ? (slipDays > 0 ? `+${slipDays} days late` : slipDays === 0 ? 'On schedule' : `${Math.abs(slipDays)} days early`) : '—'],
              ].map(([k, v]) => (
                <div key={k}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>{k}</div>
                  <div style={{ fontSize: 13, color: k === 'Slip vs Baseline' && slipDays && slipDays > 0 ? 'var(--color-danger-600)' : undefined, fontWeight: k === 'Slip vs Baseline' && slipDays && slipDays > 0 ? 600 : 400 }}>{v as string}</div>
                </div>
              ))}
            </div>

            {(task.constraints_json as any[])?.length > 0 && (
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Constraints</div>
                {(task.constraints_json as any[]).map((c: any, i: number) => (
                  <div key={i} style={{ background: 'var(--color-warning-100)', border: '1px solid var(--color-warning-600)', borderRadius: 6, padding: '8px 12px', marginBottom: 6, fontSize: 13 }}>
                    <strong>{c.type ?? 'Constraint'}:</strong> {c.description ?? '—'}
                    {c.owner && <span style={{ color: 'var(--text-muted)', marginLeft: 8 }}>Owner: {c.owner}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary">Edit Task</button>
          {task.status !== 'complete' && <button className="btn btn-primary">Update Progress</button>}
          {task.status === 'in_progress' && <button className="btn btn-ghost">Mark Complete</button>}
        </div>
      </div>
    </AppShell>
  );
}
