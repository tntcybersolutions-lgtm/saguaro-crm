import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const RESULT_BADGE: Record<string, string> = { passed:'green', failed:'red', partial:'yellow', cancelled:'gray' };

export default async function InspectionsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: inspections } = await supabase.from('inspections').select('*').eq('project_id', params.projectId).order('scheduled_date', { ascending: false });

  const failed = (inspections ?? []).filter(i => i.result === 'failed').length;
  const upcoming = (inspections ?? []).filter(i => !i.completed_date && i.scheduled_date).length;

  return (
    <AppShell>
      <PageHeader title="Inspections"
        subtitle={`${upcoming} upcoming · ${failed} failed (require corrective action)`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Inspections' }]}
        actions={<button className="btn btn-primary btn-sm">+ Schedule Inspection</button>}
      />
      {failed > 0 && <div className="alert alert-danger" style={{ marginBottom: 16 }}><strong>{failed} failed inspection(s).</strong> Corrective actions required before re-inspection.</div>}
      {(inspections ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="✓" title="No inspections" body="Schedule and track building inspections, framing, MEP rough-ins, and final inspections." /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Type</th><th>Agency</th><th>Scheduled</th><th>Completed</th><th>Result</th><th>Inspector</th><th>Notes</th></tr></thead>
            <tbody>
              {(inspections ?? []).map(i => (
                <tr key={i.id} style={{ background: i.result === 'failed' ? 'rgba(220,38,38,0.03)' : undefined }}>
                  <td style={{ fontWeight: 500 }}>{i.inspection_type}</td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{i.agency ?? '—'}</td>
                  <td style={{ fontSize: 12 }}>{i.scheduled_date ?? '—'}</td>
                  <td style={{ fontSize: 12 }}>{i.completed_date ?? <span style={{ color: 'var(--text-muted)' }}>Pending</span>}</td>
                  <td>
                    {i.result
                      ? <span className={`badge badge-${RESULT_BADGE[i.result] ?? 'gray'}`}>{i.result}</span>
                      : <span className="badge badge-gray">Scheduled</span>}
                  </td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{i.inspector_name ?? '—'}</td>
                  <td style={{ fontSize: 12, maxWidth: 200, color: i.result === 'failed' ? 'var(--color-danger-600)' : 'var(--text-muted)' }}>
                    {i.notes ? i.notes.slice(0, 80) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
