import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const CATEGORY_LABEL: Record<string, string> = {
  punch: 'Punch List',
  asbuilt: 'As-Builts',
  om_manual: 'O&M Manuals',
  warranty: 'Warranties',
  training: 'Training Signoffs',
  permit_final: 'Final Permits',
  lien_waiver: 'Lien Waivers',
  final_invoice: 'Final Invoice',
};

const CATEGORY_ORDER = ['punch','asbuilt','om_manual','warranty','training','permit_final','lien_waiver','final_invoice'];

export default async function CloseoutPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const [itemsRes, projectRes] = await Promise.all([
    supabase.from('closeout_items').select('*').eq('project_id', params.projectId).order('category'),
    supabase.from('projects').select('id, name, status').eq('id', params.projectId).single(),
  ]);

  const items = itemsRes.data ?? [];
  const project = projectRes.data;

  const completed = items.filter(i => i.status === 'complete' || i.completed_at).length;
  const required = items.filter(i => i.required).length;
  const completedRequired = items.filter(i => i.required && (i.status === 'complete' || i.completed_at)).length;
  const pct = required > 0 ? Math.round((completedRequired / required) * 100) : 0;
  const canExport = completedRequired === required || items.length === 0;

  const byCategory = CATEGORY_ORDER.reduce((acc, cat) => {
    const catItems = items.filter(i => i.category === cat);
    if (catItems.length > 0) acc[cat] = catItems;
    return acc;
  }, {} as Record<string, typeof items>);

  // Seed default closeout categories if empty
  const hasItems = items.length > 0;

  return (
    <AppShell>
      <PageHeader title="Closeout"
        subtitle={hasItems ? `${completedRequired}/${required} required items complete · ${pct}% ready` : 'Project closeout checklist and binder export'}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Closeout' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm">+ Add Item</button>
            <button
              className={`btn btn-${canExport ? 'primary' : 'secondary'} btn-sm`}
              disabled={!canExport}
              title={!canExport ? 'Complete all required items before exporting binder' : 'Export closeout binder'}
            >
              {canExport ? '↓ Export Binder' : `🔒 Export Binder (${pct}% ready)`}
            </button>
          </div>
        }
      />

      {/* Progress Bar */}
      {hasItems && (
        <div className="card" style={{ marginBottom: 20, padding: '20px 24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>Closeout Readiness</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 20, color: pct === 100 ? 'var(--color-success-600)' : pct >= 75 ? 'var(--color-warning-600)' : 'var(--color-danger-600)' }}>
              {pct}%
            </div>
          </div>
          <div style={{ height: 10, background: 'var(--border-color)', borderRadius: 5 }}>
            <div style={{
              width: `${pct}%`,
              height: '100%',
              background: pct === 100 ? 'var(--color-success-600)' : pct >= 75 ? 'var(--color-warning-600)' : 'var(--color-danger-600)',
              borderRadius: 5,
              transition: 'width 0.4s ease'
            }} />
          </div>
          <div className="stat-cards" style={{ marginTop: 16, marginBottom: 0 }}>
            {[
              { label: 'Total Items', value: items.length, color: 'var(--color-blue-700)' },
              { label: 'Completed', value: completed, color: 'var(--color-success-600)' },
              { label: 'Required Remaining', value: required - completedRequired, color: required - completedRequired > 0 ? 'var(--color-danger-600)' : 'var(--color-success-600)' },
              { label: 'Optional', value: items.filter(i => !i.required).length, color: 'var(--color-stone-500)' },
            ].map(s => (
              <div key={s.label} className="stat-card" style={{ '--stat-color': s.color, padding: '12px 16px' } as React.CSSProperties}>
                <div className="stat-label" style={{ fontSize: 10 }}>{s.label}</div>
                <div className="stat-value" style={{ fontSize: '1.4rem' }}>{s.value}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!canExport && (
        <div className="alert alert-warning" style={{ marginBottom: 16 }}>
          <strong>Binder export locked.</strong> Complete all {required - completedRequired} remaining required item(s) to unlock the binder export. Robert (Master) can override this gate.
        </div>
      )}

      {!hasItems ? (
        <div className="card">
          <EmptyState icon="★" title="No closeout items yet"
            body="Add items to build your closeout checklist: punch list, as-builts, O&M manuals, warranties, training signoffs, permits, lien waivers, and final invoice."
            action={<button className="btn btn-primary">+ Initialize Closeout Checklist</button>}
          />
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {Object.entries(byCategory).map(([cat, catItems]) => {
            const catComplete = catItems.filter(i => i.status === 'complete' || i.completed_at).length;
            const catRequired = catItems.filter(i => i.required).length;
            return (
              <div key={cat} className="card">
                <div className="card-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span className="card-title">{CATEGORY_LABEL[cat] ?? cat}</span>
                    <span className="badge badge-gray">{catItems.length} items</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 12, color: catComplete === catRequired ? 'var(--color-success-600)' : 'var(--text-muted)', fontWeight: 600 }}>
                      {catComplete}/{catRequired} required
                    </span>
                    {catComplete === catRequired && catRequired > 0 && <span className="badge badge-green">✓ Complete</span>}
                  </div>
                </div>
                <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
                  <table className="table">
                    <thead><tr><th>Item</th><th>Required</th><th>Status</th><th>Document</th><th>Completed By</th><th>Date</th><th>Notes</th><th>Action</th></tr></thead>
                    <tbody>
                      {catItems.map(item => (
                        <tr key={item.id} style={{ background: (item.status === 'complete' || item.completed_at) ? 'rgba(22,163,74,0.03)' : undefined }}>
                          <td style={{ fontWeight: 500 }}>{item.title}</td>
                          <td>
                            {item.required
                              ? <span className="badge badge-blue">Required</span>
                              : <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Optional</span>}
                          </td>
                          <td>
                            <span className={`badge badge-${(item.status === 'complete' || item.completed_at) ? 'green' : item.status === 'in_progress' ? 'yellow' : 'gray'}`}>
                              {item.completed_at ? 'Complete' : item.status ?? 'pending'}
                            </span>
                          </td>
                          <td>
                            {item.doc_id
                              ? <a href={`/app/documents/${item.doc_id}`} style={{ fontSize: 12, color: 'var(--color-blue-700)' }}>View Doc →</a>
                              : <button className="btn btn-ghost btn-sm" style={{ fontSize: 11 }}>+ Attach</button>}
                          </td>
                          <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>—</td>
                          <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                            {item.completed_at ? new Date(item.completed_at).toLocaleDateString() : '—'}
                          </td>
                          <td style={{ fontSize: 12, color: 'var(--text-muted)', maxWidth: 160 }}>{item.notes ?? '—'}</td>
                          <td>
                            {!(item.status === 'complete' || item.completed_at) && (
                              <button className="btn btn-primary btn-sm">Mark Complete</button>
                            )}
                            {(item.status === 'complete' || item.completed_at) && (
                              <span style={{ color: 'var(--color-success-600)', fontSize: 13 }}>✓</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
