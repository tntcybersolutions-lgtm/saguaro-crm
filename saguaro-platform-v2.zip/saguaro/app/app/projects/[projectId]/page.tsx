import { createServerSupabase } from '../../../../lib/serverAuth';
import AppShell from '../../../../components/AppShell';
import PageHeader from '../../../../components/PageHeader';
import AutopilotPanel from '../../../../components/AutopilotPanel';
import { notFound } from 'next/navigation';

interface Props { params: { projectId: string } }

export default async function ProjectHubPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: project } = await supabase
    .from('projects')
    .select('*')
    .eq('id', params.projectId)
    .single();

  if (!project) notFound();

  const [rfisRes, invoicesRes, tasksRes, issuesRes, logsRes] = await Promise.all([
    supabase.from('rfis').select('id, status').eq('project_id', params.projectId),
    supabase.from('invoices').select('id, status, amount').eq('project_id', params.projectId),
    supabase.from('schedule_tasks').select('id, status, percent_complete').eq('project_id', params.projectId),
    supabase.from('field_issues').select('id, status, severity').eq('project_id', params.projectId),
    supabase.from('daily_logs').select('id, log_date').eq('project_id', params.projectId).order('log_date', { ascending: false }).limit(1),
  ]);

  const rfis = rfisRes.data ?? [];
  const invoices = invoicesRes.data ?? [];
  const tasks = tasksRes.data ?? [];
  const issues = issuesRes.data ?? [];

  const openRfis = rfis.filter(r => !['closed','answered','resolved'].includes(r.status)).length;
  const pendingInvoices = invoices.filter(i => i.status === 'pending').length;
  const pendingInvoiceValue = invoices.filter(i => i.status === 'pending').reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const taskProgress = tasks.length > 0 ? Math.round(tasks.reduce((s, t) => s + (Number(t.percent_complete) || 0), 0) / tasks.length) : 0;
  const openIssues = issues.filter(i => !['closed','resolved'].includes(i.status)).length;
  const criticalIssues = issues.filter(i => i.severity === 'critical' && !['closed','resolved'].includes(i.status)).length;

  const TABS = [
    { label: 'Overview', href: `/app/projects/${params.projectId}` },
    { label: 'Autopilot ⚡', href: `/app/projects/${params.projectId}/autopilot` },
    { label: 'Schedule', href: `/app/projects/${params.projectId}/schedule` },
    { label: 'Financials', href: `/app/projects/${params.projectId}/financials` },
    { label: 'Changes', href: `/app/projects/${params.projectId}/change-orders` },
    { label: 'Procurement', href: `/app/projects/${params.projectId}/procurement` },
    { label: 'RFIs', href: `/app/projects/${params.projectId}/rfis` },
    { label: 'Submittals', href: `/app/projects/${params.projectId}/submittals` },
    { label: 'Field', href: `/app/projects/${params.projectId}/field-issues` },
    { label: 'Logs', href: `/app/projects/${params.projectId}/daily-logs` },
    { label: 'Photos', href: `/app/projects/${params.projectId}/photos` },
    { label: 'Safety', href: `/app/projects/${params.projectId}/safety` },
    { label: 'Quality', href: `/app/projects/${params.projectId}/quality` },
    { label: 'Docs', href: `/app/projects/${params.projectId}/documents` },
    { label: 'Systems', href: `/app/projects/${params.projectId}/systems` },
    { label: 'Closeout', href: `/app/projects/${params.projectId}/closeout` },
  ];

  return (
    <AppShell>
      {/* Project Header */}
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-lg)', padding: '20px 24px', marginBottom: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>
              {project.project_number}
            </div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 800, marginBottom: 4 }}>{project.name}</h1>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', fontSize: 13, color: 'var(--text-muted)' }}>
              {project.site_city && <span>📍 {project.site_city}, {project.site_state}</span>}
              {project.contract_type && <span>◷ {project.contract_type}</span>}
              {project.contract_value && <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>${Number(project.contract_value).toLocaleString()}</span>}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span className={`badge badge-${project.status === 'active' ? 'green' : project.status === 'precon' ? 'blue' : 'gray'}`} style={{ fontSize: 12, padding: '4px 10px' }}>
              {project.status}
            </span>
            <button className="btn btn-secondary btn-sm">Edit</button>
            <button className="btn btn-secondary btn-sm">Export</button>
          </div>
        </div>

        {/* Tab Bar */}
        <div className="tabs" style={{ marginBottom: -1, gap: 0 }}>
          {TABS.map(tab => (
            <a key={tab.href} href={tab.href} className="tab active" style={{ fontSize: 12, padding: '8px 14px' }}>
              {tab.label}
            </a>
          ))}
        </div>
      </div>

      {/* KPI Row */}
      <div className="stat-cards" style={{ marginBottom: 20 }}>
        <div className="stat-card" style={{ '--stat-color': 'var(--color-blue-700)' } as React.CSSProperties}>
          <div className="stat-label">Schedule Progress</div>
          <div className="stat-value">{taskProgress}%</div>
          <div className="stat-sub">{tasks.length} tasks tracked</div>
        </div>
        <div className="stat-card" style={{ '--stat-color': openRfis > 0 ? 'var(--color-warning-600)' : 'var(--color-success-600)' } as React.CSSProperties}>
          <div className="stat-label">Open RFIs</div>
          <div className="stat-value">{openRfis}</div>
          <div className="stat-sub">{rfis.length} total</div>
        </div>
        <div className="stat-card" style={{ '--stat-color': pendingInvoices > 0 ? 'var(--color-clay-700)' : 'var(--color-success-600)' } as React.CSSProperties}>
          <div className="stat-label">Pending Invoices</div>
          <div className="stat-value">{pendingInvoices}</div>
          <div className="stat-sub">${pendingInvoiceValue.toLocaleString()} pending</div>
        </div>
        <div className="stat-card" style={{ '--stat-color': criticalIssues > 0 ? 'var(--color-danger-600)' : openIssues > 0 ? 'var(--color-warning-600)' : 'var(--color-success-600)' } as React.CSSProperties}>
          <div className="stat-label">Field Issues</div>
          <div className="stat-value">{openIssues}</div>
          <div className="stat-sub">{criticalIssues} critical</div>
        </div>
      </div>

      {/* Autopilot Panel + Quick Info */}
      <div className="grid-2">
        <div>
          <AutopilotPanel
            tenantId={project.tenant_id}
            projectId={params.projectId}
            tenantSlug="app"
          />
        </div>
        <div className="card">
          <div className="card-header"><span className="card-title">Project Details</span></div>
          <div className="card-body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {[
                ['Project Manager', 'Assigned PM'],
                ['Superintendent', 'Assigned Super'],
                ['Contract Type', project.contract_type ?? '—'],
                ['Retainage', `${project.retainage_pct ?? 10}%`],
                ['Start Date', project.start_date ?? '—'],
                ['Target Finish', project.target_finish_date ?? '—'],
                ['Bonding', project.bonding ? 'Yes' : 'No'],
              ].map(([label, value]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span style={{ color: 'var(--text-muted)' }}>{label}</span>
                  <span style={{ fontWeight: 500 }}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
