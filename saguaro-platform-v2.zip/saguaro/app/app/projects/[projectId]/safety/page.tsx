import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function SafetyPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const [incidentsRes, talksRes] = await Promise.all([
    supabase.from('safety_incidents').select('*').eq('project_id', params.projectId).order('incident_date', { ascending: false }),
    supabase.from('toolbox_talks').select('*').eq('project_id', params.projectId).order('conducted_at', { ascending: false }),
  ]);

  const incidents = incidentsRes.data ?? [];
  const talks = talksRes.data ?? [];
  const openIncidents = incidents.filter(i => i.status === 'open').length;
  const oshaRecordable = incidents.filter(i => i.osha_recordable).length;

  return (
    <AppShell>
      <PageHeader title="Safety"
        subtitle={`${openIncidents} open incidents · ${oshaRecordable} OSHA recordable · ${talks.length} toolbox talks`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Safety' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-ghost btn-sm">+ Toolbox Talk</button>
            <button className="btn btn-danger btn-sm">+ Report Incident</button>
          </div>
        }
      />

      {openIncidents > 0 && (
        <div className="alert alert-critical" style={{ marginBottom: 16 }}>
          <strong>{openIncidents} open incident(s) require corrective action review.</strong>
          {oshaRecordable > 0 && ` ${oshaRecordable} are OSHA recordable.`}
        </div>
      )}

      <div className="grid-2" style={{ marginBottom: 20 }}>
        {[
          { label: 'Days Without Incident', value: '—', color: 'var(--color-success-600)' },
          { label: 'Open Incidents', value: openIncidents, color: openIncidents > 0 ? 'var(--color-danger-600)' : 'var(--color-success-600)' },
          { label: 'OSHA Recordable', value: oshaRecordable, color: oshaRecordable > 0 ? 'var(--color-critical-600)' : 'var(--color-success-600)' },
          { label: 'Toolbox Talks', value: talks.length, color: 'var(--color-blue-700)' },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ '--stat-color': s.color } as React.CSSProperties}>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value">{s.value}</div>
          </div>
        ))}
      </div>

      {/* Incidents */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-header">
          <span className="card-title">Incidents & Near-Misses</span>
          <button className="btn btn-danger btn-sm">+ Report Incident</button>
        </div>
        {incidents.length === 0 ? (
          <div style={{ padding: '32px', textAlign: 'center', color: 'var(--color-success-600)', fontWeight: 600 }}>✓ No incidents recorded</div>
        ) : (
          <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
            <table className="table">
              <thead><tr><th>Date</th><th>Type</th><th>Severity</th><th>Description</th><th>OSHA</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {incidents.map(i => (
                  <tr key={i.id} style={{ background: i.osha_recordable ? 'rgba(153,27,27,0.03)' : undefined }}>
                    <td style={{ fontSize: 12 }}>{new Date(i.incident_date).toLocaleDateString()}</td>
                    <td><span className="badge badge-gray">{i.incident_type?.replace(/_/g,' ')}</span></td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <div className={`sev-dot sev-${i.severity === 'critical' ? 'critical' : i.severity === 'serious' ? 'high' : i.severity === 'moderate' ? 'medium' : 'low'}`} />
                        <span style={{ fontSize: 12 }}>{i.severity}</span>
                      </div>
                    </td>
                    <td style={{ fontSize: 12, maxWidth: 240 }}>{i.description?.slice(0, 100)}{(i.description?.length ?? 0) > 100 ? '…' : ''}</td>
                    <td>{i.osha_recordable ? <span className="badge badge-critical">Recordable</span> : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>No</span>}</td>
                    <td><span className={`badge badge-${i.status === 'closed' ? 'green' : 'yellow'}`}>{i.status}</span></td>
                    <td><button className="btn btn-ghost btn-sm">View</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Toolbox Talks */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">Toolbox Talks</span>
          <button className="btn btn-secondary btn-sm">+ New Talk</button>
        </div>
        {talks.length === 0 ? (
          <EmptyState icon="◎" title="No toolbox talks recorded" body="Document safety meetings with topic, attendees, and signatures." />
        ) : (
          <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
            <table className="table">
              <thead><tr><th>Date</th><th>Topic</th><th>Attendees</th><th>Facilitator</th><th>Actions</th></tr></thead>
              <tbody>
                {talks.map(t => (
                  <tr key={t.id}>
                    <td style={{ fontSize: 12 }}>{new Date(t.conducted_at).toLocaleDateString()}</td>
                    <td style={{ fontWeight: 500 }}>{t.topic}</td>
                    <td style={{ fontSize: 12 }}>{(t.attendees as any[])?.length ?? 0} signed</td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>—</td>
                    <td><button className="btn btn-ghost btn-sm">↓ Export</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppShell>
  );
}
