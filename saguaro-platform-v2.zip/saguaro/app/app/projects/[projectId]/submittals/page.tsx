import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const STATUS_BADGE: Record<string, string> = {
  draft:'gray', submitted:'blue', under_review:'yellow',
  approved:'green', approved_as_noted:'green', revise_resubmit:'red', rejected:'critical'
};

export default async function SubmittalsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: subs } = await supabase
    .from('submittals')
    .select('*')
    .eq('project_id', params.projectId)
    .order('number', { ascending: true });

  const open = (subs ?? []).filter(s => !['approved','rejected'].includes(s.status)).length;

  return (
    <AppShell>
      <PageHeader title="Submittals"
        subtitle={`${open} open · ${(subs ?? []).length} total`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Submittals' }]}
        actions={<button className="btn btn-primary btn-sm">+ New Submittal</button>}
      />
      {(subs ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="◨" title="No submittals" body="Track product data, shop drawings, and material approvals." /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>#</th><th>Title</th><th>Spec Section</th><th>Status</th><th>Rev</th><th>Required By</th><th>Reviewer</th><th>Procurement Trigger</th></tr></thead>
            <tbody>
              {(subs ?? []).map(s => (
                <tr key={s.id}>
                  <td style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 600 }}>{s.number}</td>
                  <td style={{ fontWeight: 500 }}>{s.title}</td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{s.spec_section ?? '—'}</td>
                  <td><span className={`badge badge-${STATUS_BADGE[s.status] ?? 'gray'}`}>{s.status?.replace(/_/g,' ')}</span></td>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>Rev {s.revision}</td>
                  <td style={{ fontSize: 12 }}>{s.required_by ?? '—'}</td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>—</td>
                  <td>
                    {s.triggers_procurement ? (
                      s.procurement_triggered_at
                        ? <span className="badge badge-green">Triggered ✓</span>
                        : <span className="badge badge-yellow">Pending approval</span>
                    ) : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>N/A</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
