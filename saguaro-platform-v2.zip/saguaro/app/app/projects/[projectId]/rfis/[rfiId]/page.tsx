import { createServerSupabase } from '../../../../../../lib/serverAuth';
import AppShell from '../../../../../../components/AppShell';
import { notFound } from 'next/navigation';

interface Props { params: { projectId: string; rfiId: string } }

export default async function RFIDetailPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: rfi } = await supabase.from('rfis').select('*').eq('id', params.rfiId).single();
  if (!rfi) notFound();

  return (
    <AppShell>
      <div style={{ maxWidth: 800 }}>
        <div style={{ marginBottom: 20 }}>
          <a href={`/app/projects/${params.projectId}/rfis`} style={{ fontSize: 12, color: 'var(--text-muted)' }}>← Back to RFIs</a>
        </div>
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-body">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>RFI-{String(rfi.number).padStart(3,'0')}</div>
                <h2 style={{ fontSize: '1.2rem' }}>{rfi.subject}</h2>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <span className={`badge badge-${rfi.status === 'answered' ? 'green' : rfi.status === 'under_review' ? 'yellow' : rfi.status === 'submitted' ? 'blue' : 'gray'}`} style={{ fontSize: 13, padding: '5px 12px' }}>
                  {rfi.status?.replace(/_/g,' ')}
                </span>
              </div>
            </div>
            <div className="grid-2" style={{ marginBottom: 20 }}>
              {[
                ['Spec Section', rfi.spec_section ?? '—'],
                ['Drawing Refs', rfi.drawing_refs?.join(', ') ?? '—'],
                ['Priority', rfi.priority ?? 'normal'],
                ['Due Date', rfi.response_due_date ?? rfi.due_date ?? '—'],
                ['Schedule Impact', rfi.schedule_impact ? 'Yes' : 'No'],
                ['Cost Impact', rfi.cost_impact ? (rfi.cost_impact_amount ? `$${Number(rfi.cost_impact_amount).toLocaleString()}` : 'Yes') : 'No'],
              ].map(([k, v]) => (
                <div key={k}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>{k}</div>
                  <div style={{ fontSize: 13 }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Question</div>
              <div style={{ background: 'var(--color-stone-50)', borderRadius: 8, padding: '16px', fontSize: 13, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>{rfi.question}</div>
            </div>
            {rfi.response ? (
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--color-success-600)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Response</div>
                <div style={{ background: 'rgba(22,163,74,0.06)', border: '1px solid rgba(22,163,74,0.2)', borderRadius: 8, padding: '16px', fontSize: 13, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>{rfi.response}</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
                  Responded {rfi.responded_at ? new Date(rfi.responded_at).toLocaleDateString() : ''}
                </div>
              </div>
            ) : (
              <div style={{ background: 'var(--color-stone-50)', borderRadius: 8, padding: '20px', textAlign: 'center' }}>
                <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 12 }}>No response yet. Due: {rfi.response_due_date ?? '—'}</div>
                <button className="btn btn-primary">Add Response</button>
              </div>
            )}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary">↓ Export PDF</button>
          <button className="btn btn-secondary">Send Reminder</button>
          {!rfi.response && <button className="btn btn-primary">Respond to RFI</button>}
          {rfi.status !== 'closed' && <button className="btn btn-ghost">Close RFI</button>}
        </div>
      </div>
    </AppShell>
  );
}
