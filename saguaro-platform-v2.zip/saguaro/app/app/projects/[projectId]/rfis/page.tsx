import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const STATUS_BADGE: Record<string, string> = {
  draft: 'gray', submitted: 'blue', under_review: 'yellow', answered: 'green', closed: 'gray',
};

export default async function RFIsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: rfis } = await supabase
    .from('rfis')
    .select('*')
    .eq('project_id', params.projectId)
    .order('number', { ascending: false });

  const open = (rfis ?? []).filter(r => !['closed','answered'].includes(r.status)).length;

  return (
    <AppShell>
      <PageHeader title="RFIs" subtitle={`${open} open · ${(rfis ?? []).length} total`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'RFIs' }]}
        actions={<button className="btn btn-primary btn-sm">+ New RFI</button>}
      />

      {(rfis ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="◳" title="No RFIs yet" body="Create an RFI to track design questions and clarifications." action={<button className="btn btn-primary">+ Create RFI</button>} /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>#</th><th>Subject</th><th>Status</th><th>Priority</th><th>Due Date</th><th>Assigned To</th><th>Schedule Impact</th><th>Cost Impact</th>
              </tr>
            </thead>
            <tbody>
              {(rfis ?? []).map(r => (
                <tr key={r.id}>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{r.number}</td>
                  <td style={{ fontWeight: 500, maxWidth: 300 }}>
                    <a href={`/app/projects/${params.projectId}/rfis/${r.id}`} style={{ color: 'var(--color-blue-700)' }}>{r.subject}</a>
                    {r.spec_section && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>§ {r.spec_section}</div>}
                  </td>
                  <td><span className={`badge badge-${STATUS_BADGE[r.status] ?? 'gray'}`}>{r.status?.replace('_',' ')}</span></td>
                  <td><span className={`badge badge-${r.priority === 'high' ? 'red' : r.priority === 'urgent' ? 'critical' : 'gray'}`}>{r.priority ?? 'normal'}</span></td>
                  <td style={{ fontSize: 12 }}>{r.response_due_date ?? r.due_date ?? '—'}</td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>—</td>
                  <td>{r.schedule_impact ? <span className="badge badge-yellow">Yes</span> : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>No</span>}</td>
                  <td>
                    {r.cost_impact ? (
                      <span className="badge badge-clay">{r.cost_impact_amount ? `$${Number(r.cost_impact_amount).toLocaleString()}` : 'Yes'}</span>
                    ) : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>No</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
