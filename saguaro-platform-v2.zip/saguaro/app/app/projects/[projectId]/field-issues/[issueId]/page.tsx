import { createServerSupabase } from '../../../../../../lib/serverAuth';
import AppShell from '../../../../../../components/AppShell';
import { notFound } from 'next/navigation';

interface Props { params: { projectId: string; issueId: string } }

export default async function FieldIssueDetailPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: issue } = await supabase.from('field_issues').select('*').eq('id', params.issueId).single();
  if (!issue) notFound();

  return (
    <AppShell>
      <div style={{ maxWidth: 800 }}>
        <div style={{ marginBottom: 20 }}>
          <a href={`/app/projects/${params.projectId}/field-issues`} style={{ fontSize: 12, color: 'var(--text-muted)' }}>← Back to Field Issues</a>
        </div>
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-body">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Issue #{issue.number} · {issue.category?.toUpperCase()}</div>
                <h2 style={{ fontSize: '1.2rem' }}>{issue.title}</h2>
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <div className={`sev-dot sev-${issue.severity ?? 'medium'}`} style={{ width: 10, height: 10 }} />
                <span className={`badge badge-${['closed','resolved'].includes(issue.status) ? 'green' : issue.status === 'in_progress' ? 'blue' : 'yellow'}`} style={{ fontSize: 13, padding: '5px 12px' }}>{issue.status}</span>
              </div>
            </div>
            <div className="grid-2" style={{ marginBottom: 20 }}>
              {[
                ['Category', issue.category ?? '—'],
                ['Severity', issue.severity ?? 'medium'],
                ['Location', issue.location ?? issue.room ?? '—'],
                ['Floor', issue.floor_level ?? '—'],
                ['Due Date', issue.due_date ?? '—'],
                ['Created', issue.created_at ? new Date(issue.created_at).toLocaleDateString() : '—'],
              ].map(([k, v]) => (
                <div key={k}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>{k}</div>
                  <div style={{ fontSize: 13 }}>{v}</div>
                </div>
              ))}
            </div>
            {issue.description && (
              <div style={{ marginBottom: 20 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Description</div>
                <div style={{ background: 'var(--color-stone-50)', borderRadius: 8, padding: '14px', fontSize: 13, lineHeight: 1.6 }}>{issue.description}</div>
              </div>
            )}
            {issue.root_cause && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Root Cause</div>
                <div style={{ fontSize: 13 }}>{issue.root_cause}</div>
              </div>
            )}
            {issue.corrective_action && (
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Corrective Action</div>
                <div style={{ fontSize: 13 }}>{issue.corrective_action}</div>
              </div>
            )}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary">Edit</button>
          {!['closed','resolved'].includes(issue.status) && <button className="btn btn-primary">Mark Resolved</button>}
        </div>
      </div>
    </AppShell>
  );
}
