import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function FieldIssuesPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: issues } = await supabase.from('field_issues').select('*').eq('project_id', params.projectId).order('created_at', { ascending: false });

  const open = (issues ?? []).filter(i => !['closed','resolved'].includes(i.status)).length;
  const critical = (issues ?? []).filter(i => i.severity === 'critical' && !['closed','resolved'].includes(i.status)).length;

  return (
    <AppShell>
      <PageHeader title="Field Issues" subtitle={`${open} open · ${critical} critical`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Field Issues' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <select className="form-select" style={{ height: 34, width: 'auto' }}>
              <option>All Categories</option>
              <option>Punch</option>
              <option>Deficiency</option>
              <option>Safety</option>
              <option>NCR</option>
            </select>
            <button className="btn btn-primary btn-sm">+ New Issue</button>
          </div>
        }
      />
      {(issues ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="⚑" title="No field issues" body="Log punch items, deficiencies, NCRs, and safety issues from the field." /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>#</th><th>Title</th><th>Category</th><th>Severity</th><th>Status</th><th>Location</th><th>Assigned</th><th>Due</th></tr></thead>
            <tbody>
              {(issues ?? []).map(i => (
                <tr key={i.id}>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{i.number}</td>
                  <td style={{ fontWeight: 500, maxWidth: 260 }}>
                    <a href={`/app/projects/${params.projectId}/field-issues/${i.id}`} style={{ color: 'var(--color-blue-700)' }}>{i.title}</a>
                  </td>
                  <td><span className="badge badge-gray">{i.category ?? '—'}</span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div className={`sev-dot sev-${i.severity ?? 'medium'}`} />
                      <span style={{ fontSize: 12 }}>{i.severity ?? 'medium'}</span>
                    </div>
                  </td>
                  <td><span className={`badge badge-${i.status === 'resolved' || i.status === 'closed' ? 'green' : i.status === 'in_progress' ? 'blue' : 'yellow'}`}>{i.status}</span></td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{i.location ?? i.room ?? '—'}</td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>—</td>
                  <td style={{ fontSize: 12 }}>{i.due_date ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
