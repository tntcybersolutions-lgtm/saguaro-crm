'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getSupabaseClient } from '../../../../../lib/supabaseClient';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

type Alert = {
  id: string;
  title: string;
  summary: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'acknowledged' | 'resolved' | 'dismissed';
  rule_code: string;
  entity_type: string;
  last_detected_at: string;
  first_detected_at: string;
  metadata: Record<string, unknown>;
};

const SEV_LABEL: Record<string, string> = { low: 'badge-blue', medium: 'badge-yellow', high: 'badge-red', critical: 'badge-critical' };
const RULE_LABEL: Record<string, string> = {
  RFI_OVERDUE: 'RFI Overdue', INVOICE_OVERDUE: 'Invoice Overdue', SCHEDULE_SLIPPAGE: 'Schedule Slippage',
  FIELD_ISSUE_UNRESOLVED: 'Field Issue', PROJECT_RISK_ROLLUP: 'Project Risk',
};

export default function AutopilotAlertsPage() {
  const params = useParams();
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('open');
  const [sevFilter, setSevFilter] = useState<string>('all');

  async function load() {
    const supabase = getSupabaseClient();
    let query = supabase
      .from('autopilot_alerts')
      .select('*')
      .eq('project_id', params.projectId as string)
      .order('last_detected_at', { ascending: false });

    if (filter !== 'all') query = query.eq('status', filter);
    if (sevFilter !== 'all') query = query.eq('severity', sevFilter);

    const { data } = await query;
    setAlerts(data ?? []);
    setLoading(false);
  }

  async function updateStatus(id: string, status: string) {
    const supabase = getSupabaseClient();
    await supabase.from('autopilot_alerts').update({
      status,
      ...(status === 'resolved' ? { resolved_at: new Date().toISOString() } : {}),
    }).eq('id', id);
    load();
  }

  useEffect(() => { load(); }, [filter, sevFilter]);

  const counts = { open: alerts.filter(a => a.status === 'open').length, critical: alerts.filter(a => a.severity === 'critical').length };

  return (
    <AppShell>
      <PageHeader
        title="Autopilot Alerts"
        subtitle="AI-detected risk conditions — review, acknowledge, or resolve"
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId as string}` }, { label: 'Autopilot Alerts' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <select className="form-select" style={{ height: 34, width: 'auto' }} value={sevFilter} onChange={e => setSevFilter(e.target.value)}>
              <option value="all">All Severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
            <select className="form-select" style={{ height: 34, width: 'auto' }} value={filter} onChange={e => setFilter(e.target.value)}>
              <option value="open">Open</option>
              <option value="acknowledged">Acknowledged</option>
              <option value="resolved">Resolved</option>
              <option value="dismissed">Dismissed</option>
              <option value="all">All</option>
            </select>
          </div>
        }
      />

      {/* Summary Strip */}
      <div className="stat-cards" style={{ marginBottom: 20 }}>
        {[
          { label: 'Open Alerts', value: alerts.filter(a => ['open','acknowledged'].includes(a.status)).length, color: 'var(--color-blue-700)' },
          { label: 'Critical', value: alerts.filter(a => a.severity === 'critical' && ['open','acknowledged'].includes(a.status)).length, color: 'var(--color-danger-600)' },
          { label: 'High', value: alerts.filter(a => a.severity === 'high' && ['open','acknowledged'].includes(a.status)).length, color: 'var(--color-warning-600)' },
          { label: 'Resolved', value: alerts.filter(a => a.status === 'resolved').length, color: 'var(--color-success-600)' },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ '--stat-color': s.color } as React.CSSProperties}>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value">{s.value}</div>
          </div>
        ))}
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 48, color: 'var(--text-muted)' }}>Loading alerts…</div>
      ) : alerts.length === 0 ? (
        <div className="card"><EmptyState icon="✓" title="No alerts match this filter" body="All clear, or adjust filters to see more." /></div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {alerts.map(alert => (
            <div key={alert.id} className="card" style={{ overflow: 'visible' }}>
              <div style={{ padding: '16px 20px', display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                <div className={`sev-dot sev-${alert.severity}`} style={{ marginTop: 6, width: 10, height: 10 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 4 }}>
                    <span style={{ fontWeight: 600, fontSize: 14 }}>{alert.title}</span>
                    <span className={`badge ${SEV_LABEL[alert.severity]}`}>{alert.severity}</span>
                    <span className="badge badge-gray">{RULE_LABEL[alert.rule_code] ?? alert.rule_code}</span>
                    <span className={`badge ${alert.status === 'open' ? 'badge-red' : alert.status === 'acknowledged' ? 'badge-yellow' : 'badge-green'}`}>{alert.status}</span>
                  </div>
                  <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 8 }}>{alert.summary}</p>
                  <div style={{ display: 'flex', gap: 16, fontSize: 11, color: 'var(--text-muted)' }}>
                    <span>First detected: {new Date(alert.first_detected_at).toLocaleDateString()}</span>
                    <span>Last seen: {new Date(alert.last_detected_at).toLocaleDateString()}</span>
                    <span>Entity: {alert.entity_type}</span>
                  </div>
                  {Object.keys(alert.metadata ?? {}).length > 0 && (
                    <div style={{ marginTop: 8, background: 'var(--color-stone-50)', borderRadius: 6, padding: '8px 12px', display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                      {Object.entries(alert.metadata).map(([k, v]) => (
                        <span key={k} style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                          <span style={{ fontWeight: 600 }}>{k.replace(/_/g,' ')}:</span> {String(v)}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                  {alert.status === 'open' && (
                    <button className="btn btn-secondary btn-sm" onClick={() => updateStatus(alert.id, 'acknowledged')}>Acknowledge</button>
                  )}
                  {['open','acknowledged'].includes(alert.status) && (
                    <button className="btn btn-primary btn-sm" onClick={() => updateStatus(alert.id, 'resolved')}>Resolve</button>
                  )}
                  {alert.status === 'open' && (
                    <button className="btn btn-ghost btn-sm" onClick={() => updateStatus(alert.id, 'dismissed')}>Dismiss</button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
