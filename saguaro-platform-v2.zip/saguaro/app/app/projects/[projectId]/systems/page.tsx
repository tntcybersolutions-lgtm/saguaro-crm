import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';

interface Props { params: { projectId: string } }

export default async function SystemsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: sys } = await supabase.from('project_systems').select('*').eq('project_id', params.projectId).single();

  const isEmpty = !sys;

  return (
    <AppShell>
      <PageHeader title="Systems / LV / Smart Building"
        subtitle="Networking, CCTV, access control, Wi-Fi, voice/PA, AV, and building automation"
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Systems' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm">Generate BOM</button>
            <button className="btn btn-secondary btn-sm">Cable Schedule</button>
            <button className="btn btn-secondary btn-sm">Commissioning Checklist</button>
            <button className="btn btn-primary btn-sm">{isEmpty ? '+ Configure Systems' : 'Edit'}</button>
          </div>
        }
      />

      {isEmpty ? (
        <div className="card">
          <div style={{ padding: 48, textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>⬡</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, marginBottom: 8 }}>No systems configured yet</div>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', maxWidth: 440, margin: '0 auto 20px' }}>
              Configure ISP, network infrastructure, Wi-Fi, CCTV, access control, voice/PA, AV, and smart building automation for this project.
            </p>
            <button className="btn btn-primary">Configure Systems</button>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Internet / ISP */}
          <div className="card">
            <div className="card-header"><span className="card-title">Internet / ISP</span></div>
            <div className="card-body">
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
                {[
                  ['ISP Type', sys.isp_type ?? '—'],
                  ['Provider', sys.isp_provider ?? '—'],
                  ['Download', sys.download_speed_mbps ? `${sys.download_speed_mbps} Mbps` : '—'],
                  ['Upload', sys.upload_speed_mbps ? `${sys.upload_speed_mbps} Mbps` : '—'],
                  ['SLA', sys.sla ?? '—'],
                  ['Failover', sys.failover_method ?? '—'],
                ].map(([label, value]) => (
                  <div key={label}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>{label}</div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{value}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Network Infrastructure */}
          <div className="card">
            <div className="card-header"><span className="card-title">Network Infrastructure</span></div>
            <div className="card-body">
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 16 }}>
                {[
                  ['Router Model', sys.router_model ?? '—'],
                  ['MDF Location', sys.mdf_location ?? '—'],
                  ['Port Count', sys.port_count ?? '—'],
                  ['Patch Panels', sys.patch_panels ?? '—'],
                  ['Rack Count', sys.rack_count ?? '—'],
                  ['Redundancy', sys.redundancy_config ?? '—'],
                ].map(([label, value]) => (
                  <div key={label}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>{label}</div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{String(value)}</div>
                  </div>
                ))}
              </div>

              {/* Switches */}
              {(sys.switch_config as any[])?.length > 0 && (
                <div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Switches</div>
                  <div className="table-wrap" style={{ border: '1px solid var(--border-color)' }}>
                    <table className="table">
                      <thead><tr><th>Location</th><th>Model</th><th>Ports</th><th>PoE Budget</th><th>VLANs</th></tr></thead>
                      <tbody>
                        {(sys.switch_config as any[]).map((sw: any, i: number) => (
                          <tr key={i}>
                            <td>{sw.location ?? '—'}</td>
                            <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{sw.model ?? '—'}</td>
                            <td>{sw.ports ?? '—'}</td>
                            <td>{sw.poe_budget ? `${sw.poe_budget}W` : '—'}</td>
                            <td style={{ fontSize: 12 }}>{Array.isArray(sw.vlans) ? sw.vlans.join(', ') : '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Wi-Fi */}
          {(sys.wifi_aps as any[])?.length > 0 && (
            <div className="card">
              <div className="card-header">
                <span className="card-title">Wi-Fi Access Points</span>
                <span className="badge badge-blue">{(sys.wifi_aps as any[]).length} APs</span>
              </div>
              <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
                <table className="table">
                  <thead><tr><th>Model</th><th>Location</th><th>Floor</th></tr></thead>
                  <tbody>
                    {(sys.wifi_aps as any[]).map((ap: any, i: number) => (
                      <tr key={i}>
                        <td style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 600 }}>{ap.model ?? '—'}</td>
                        <td>{ap.location ?? '—'}</td>
                        <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{ap.floor ?? '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* CCTV */}
          {(sys.cctv_cameras as any[])?.length > 0 && (
            <div className="card">
              <div className="card-header">
                <span className="card-title">CCTV / Cameras</span>
                <span className="badge badge-blue">{(sys.cctv_cameras as any[]).length} cameras</span>
              </div>
              <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
                <table className="table">
                  <thead><tr><th>Type</th><th>Location</th><th>Resolution</th><th>Retention</th><th>NVR Channel</th></tr></thead>
                  <tbody>
                    {(sys.cctv_cameras as any[]).map((cam: any, i: number) => (
                      <tr key={i}>
                        <td><span className="badge badge-gray">{cam.type ?? 'dome'}</span></td>
                        <td>{cam.location ?? '—'}</td>
                        <td style={{ fontSize: 12 }}>{cam.resolution ?? '—'}</td>
                        <td style={{ fontSize: 12 }}>{cam.retention_days ? `${cam.retention_days} days` : '—'}</td>
                        <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{cam.nvr_channel ?? '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Access Control */}
          {(sys.access_doors as any[])?.length > 0 && (
            <div className="card">
              <div className="card-header"><span className="card-title">Access Control Doors</span></div>
              <div className="card-body">
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                  {(sys.access_doors as any[]).map((door: any, i: number) => (
                    <div key={i} style={{ background: 'var(--color-stone-50)', border: '1px solid var(--border-color)', borderRadius: 8, padding: '10px 14px', fontSize: 13 }}>
                      <div style={{ fontWeight: 600 }}>{door.name ?? `Door ${i + 1}`}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{door.hardware ?? '—'}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Smart Building Automation */}
          {(sys.automation_rules as any[])?.length > 0 && (
            <div className="card">
              <div className="card-header"><span className="card-title">Smart Building Automation Rules</span></div>
              <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
                <table className="table">
                  <thead><tr><th>Rule Name</th><th>Trigger</th><th>Action</th><th>Systems Affected</th></tr></thead>
                  <tbody>
                    {(sys.automation_rules as any[]).map((rule: any, i: number) => (
                      <tr key={i}>
                        <td style={{ fontWeight: 500 }}>{rule.name ?? `Rule ${i + 1}`}</td>
                        <td style={{ fontSize: 12 }}>{rule.trigger ?? '—'}</td>
                        <td style={{ fontSize: 12 }}>{rule.action ?? '—'}</td>
                        <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{Array.isArray(rule.systems) ? rule.systems.join(', ') : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Cable Library */}
          {(sys.cable_library as any[])?.length > 0 && (
            <div className="card">
              <div className="card-header"><span className="card-title">Cable Library</span></div>
              <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
                <table className="table">
                  <thead><tr><th>Type</th><th>Spec</th><th>Qty Runs</th></tr></thead>
                  <tbody>
                    {(sys.cable_library as any[]).map((cable: any, i: number) => (
                      <tr key={i}>
                        <td style={{ fontWeight: 500 }}>{cable.type ?? '—'}</td>
                        <td style={{ fontSize: 12, fontFamily: 'monospace' }}>{cable.spec ?? '—'}</td>
                        <td style={{ fontSize: 12 }}>{cable.qty ?? '—'} {cable.runs ? `(${cable.runs} runs)` : ''}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {sys.design_notes && (
            <div className="card">
              <div className="card-header"><span className="card-title">Design Notes</span></div>
              <div className="card-body">
                <p style={{ fontSize: 13, lineHeight: 1.6, color: 'var(--text-secondary)', whiteSpace: 'pre-wrap' }}>{sys.design_notes}</p>
              </div>
            </div>
          )}
        </div>
      )}
    </AppShell>
  );
}
