import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function QualityPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const [checklistsRes, issuesRes] = await Promise.all([
    supabase.from('qc_checklists').select('*').eq('project_id', params.projectId).order('created_at', { ascending: false }),
    supabase.from('field_issues').select('*').eq('project_id', params.projectId).in('category', ['deficiency','ncr']).order('created_at', { ascending: false }),
  ]);

  const checklists = checklistsRes.data ?? [];
  const issues = issuesRes.data ?? [];
  const failed = checklists.filter(c => c.passed === false).length;
  const ncrs = issues.filter(i => i.category === 'ncr').length;
  const openDeficiencies = issues.filter(i => i.category === 'deficiency' && !['closed','resolved'].includes(i.status)).length;

  return (
    <AppShell>
      <PageHeader title="Quality"
        subtitle={`${checklists.length} checklists · ${ncrs} NCRs · ${openDeficiencies} open deficiencies`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Quality' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-ghost btn-sm">+ Deficiency</button>
            <button className="btn btn-danger btn-sm">+ NCR</button>
            <button className="btn btn-primary btn-sm">+ Checklist</button>
          </div>
        }
      />

      {ncrs > 0 && (
        <div className="alert alert-critical" style={{ marginBottom: 16 }}>
          <strong>{ncrs} Non-Conformance Report(s) open.</strong> Root cause analysis and corrective action required.
        </div>
      )}

      <div className="stat-cards" style={{ marginBottom: 20 }}>
        {[
          { label: 'Checklists Passed', value: checklists.filter(c => c.passed).length, color: 'var(--color-success-600)' },
          { label: 'Checklists Failed', value: failed, color: failed > 0 ? 'var(--color-danger-600)' : 'var(--color-success-600)' },
          { label: 'Open Deficiencies', value: openDeficiencies, color: openDeficiencies > 0 ? 'var(--color-warning-600)' : 'var(--color-success-600)' },
          { label: 'NCRs', value: ncrs, color: ncrs > 0 ? 'var(--color-critical-600)' : 'var(--color-success-600)' },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ '--stat-color': s.color } as React.CSSProperties}>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value">{s.value}</div>
          </div>
        ))}
      </div>

      {/* QC Checklists */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-header">
          <span className="card-title">QC Inspection Checklists</span>
          <button className="btn btn-primary btn-sm">+ New Checklist</button>
        </div>
        {checklists.length === 0 ? (
          <EmptyState icon="◈" title="No checklists yet" body="Create inspection checklists from templates (framing, drywall, electrical rough-in, etc.)." />
        ) : (
          <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
            <table className="table">
              <thead><tr><th>Template</th><th>Category</th><th>Completed By</th><th>Date</th><th>Result</th><th>Items</th></tr></thead>
              <tbody>
                {checklists.map(c => {
                  const items = (c.items as any[]) ?? [];
                  const passing = items.filter(i => i.result === 'pass').length;
                  return (
                    <tr key={c.id}>
                      <td style={{ fontWeight: 500 }}>{c.template_name}</td>
                      <td><span className="badge badge-gray">{c.category ?? '—'}</span></td>
                      <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>—</td>
                      <td style={{ fontSize: 12 }}>{c.completed_at ? new Date(c.completed_at).toLocaleDateString() : 'In progress'}</td>
                      <td>
                        {c.passed === true && <span className="badge badge-green">Passed</span>}
                        {c.passed === false && <span className="badge badge-red">Failed</span>}
                        {c.passed === null && <span className="badge badge-yellow">In Progress</span>}
                      </td>
                      <td style={{ fontSize: 12 }}>{passing}/{items.length} pass</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Deficiencies & NCRs */}
      <div className="card">
        <div className="card-header"><span className="card-title">Deficiencies & NCRs</span></div>
        {issues.length === 0 ? (
          <EmptyState icon="◫" title="No deficiencies or NCRs" body="Log deficiencies for punch-out or NCRs for non-conforming work requiring formal disposition." />
        ) : (
          <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
            <table className="table">
              <thead><tr><th>#</th><th>Type</th><th>Title</th><th>Severity</th><th>Status</th><th>Root Cause</th><th>Due</th></tr></thead>
              <tbody>
                {issues.map(i => (
                  <tr key={i.id} style={{ background: i.category === 'ncr' ? 'rgba(153,27,27,0.03)' : undefined }}>
                    <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{i.number}</td>
                    <td><span className={`badge badge-${i.category === 'ncr' ? 'critical' : 'yellow'}`}>{i.category?.toUpperCase()}</span></td>
                    <td style={{ fontWeight: 500 }}>{i.title}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                        <div className={`sev-dot sev-${i.severity ?? 'medium'}`} />
                        <span style={{ fontSize: 12 }}>{i.severity}</span>
                      </div>
                    </td>
                    <td><span className={`badge badge-${['closed','resolved'].includes(i.status) ? 'green' : 'yellow'}`}>{i.status}</span></td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)', maxWidth: 160 }}>{i.root_cause?.slice(0, 60) ?? '—'}</td>
                    <td style={{ fontSize: 12 }}>{i.due_date ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppShell>
  );
}
