import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const TYPE_BADGE: Record<string, string> = { oac:'blue', internal:'gray', safety:'red', kickoff:'clay', closeout:'green' };

export default async function MeetingsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: meetings } = await supabase.from('meetings').select('*').eq('project_id', params.projectId).order('scheduled_at', { ascending: false });

  return (
    <AppShell>
      <PageHeader title="Meetings"
        subtitle={`${(meetings ?? []).length} meetings · OAC, safety, internal`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Meetings' }]}
        actions={<button className="btn btn-primary btn-sm">+ Schedule Meeting</button>}
      />
      {(meetings ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="◷" title="No meetings" body="Schedule OAC meetings, safety meetings, and internal coordination meetings. Track minutes, decisions, and action items." /></div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {(meetings ?? []).map(m => {
            const actionItems = (m.action_items ?? []) as any[];
            const openActions = actionItems.filter(a => !a.completed).length;
            return (
              <div key={m.id} className="card">
                <div style={{ padding: '14px 20px', display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                  <div style={{ minWidth: 100, textAlign: 'center' }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>
                      {new Date(m.scheduled_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                      {new Date(m.scheduled_at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                    </div>
                    <span className={`badge badge-${TYPE_BADGE[m.meeting_type] ?? 'gray'}`} style={{ marginTop: 4, fontSize: 10 }}>{m.meeting_type?.toUpperCase()}</span>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 3 }}>{m.title}</div>
                    {m.location && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 4 }}>📍 {m.location}</div>}
                    {m.minutes && (
                      <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 8 }}>
                        {m.minutes.slice(0, 120)}{m.minutes.length > 120 ? '…' : ''}
                      </p>
                    )}
                    {openActions > 0 && (
                      <span className="badge badge-yellow">{openActions} open action items</span>
                    )}
                  </div>
                  <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                    {m.published_at
                      ? <button className="btn btn-ghost btn-sm">View Minutes</button>
                      : <button className="btn btn-primary btn-sm">Add Minutes</button>}
                    <button className="btn btn-ghost btn-sm">Export</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
