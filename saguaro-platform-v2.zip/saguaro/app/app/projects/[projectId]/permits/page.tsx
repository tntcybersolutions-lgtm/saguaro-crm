import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function PermitsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: permits } = await supabase.from('permits').select('*').eq('project_id', params.projectId).order('applied_date');

  const today = new Date();
  const expiring = (permits ?? []).filter(p => p.expiration_date && new Date(p.expiration_date) < new Date(today.getTime() + 30*86400000) && p.status === 'active').length;

  return (
    <AppShell>
      <PageHeader title="Permits"
        subtitle={`${(permits ?? []).length} permits · ${expiring} expiring within 30 days`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Permits' }]}
        actions={<button className="btn btn-primary btn-sm">+ Add Permit</button>}
      />
      {expiring > 0 && <div className="alert alert-warning" style={{ marginBottom: 16 }}><strong>{expiring} permit(s) expiring within 30 days.</strong> Review and renew as needed.</div>}
      {(permits ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="◑" title="No permits" body="Track building permits, inspections, and CO readiness." /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Type</th><th>Permit #</th><th>Issuing Authority</th><th>Status</th><th>Applied</th><th>Issued</th><th>Expires</th><th>Fee</th></tr></thead>
            <tbody>
              {(permits ?? []).map(p => {
                const isExpiring = p.expiration_date && new Date(p.expiration_date) < new Date(today.getTime() + 30*86400000);
                return (
                  <tr key={p.id}>
                    <td style={{ fontWeight: 500 }}>{p.permit_type}</td>
                    <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{p.permit_number ?? '—'}</td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{p.issuing_authority ?? '—'}</td>
                    <td><span className={`badge badge-${p.status === 'active' ? 'green' : p.status === 'approved' ? 'blue' : p.status === 'expired' ? 'red' : 'gray'}`}>{p.status}</span></td>
                    <td style={{ fontSize: 12 }}>{p.applied_date ?? '—'}</td>
                    <td style={{ fontSize: 12 }}>{p.issued_date ?? '—'}</td>
                    <td style={{ fontSize: 12, color: isExpiring ? 'var(--color-warning-600)' : undefined, fontWeight: isExpiring ? 600 : 400 }}>
                      {p.expiration_date ?? '—'}{isExpiring ? ' ⚠' : ''}
                    </td>
                    <td style={{ fontSize: 12 }}>{p.fee ? `$${Number(p.fee).toLocaleString()}` : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
