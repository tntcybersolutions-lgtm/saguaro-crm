import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function BidLevelingPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: packages } = await supabase
    .from('bid_packages')
    .select(`*, bid_submissions(*)`)
    .eq('project_id', params.projectId)
    .not('status', 'eq', 'draft')
    .order('number', { ascending: true });

  return (
    <AppShell>
      <PageHeader title="Bid Leveling" subtitle="Compare subcontractor quotes side-by-side and award contracts"
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Bid Leveling' }]}
      />

      {(packages ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="⊞" title="No bid packages to level" body="Bid packages with received quotes will appear here for comparison and award." /></div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {(packages ?? []).map((pkg: any) => {
            const subs = pkg.bid_submissions ?? [];
            const lowestBid = subs.length > 0 ? Math.min(...subs.map((s: any) => Number(s.amount))) : null;
            return (
              <div key={pkg.id} className="card">
                <div className="card-header">
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>BP-{String(pkg.number).padStart(3,'0')} — {pkg.title}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{pkg.trade ?? 'General'} · Due {pkg.due_date ? new Date(pkg.due_date).toLocaleDateString() : '—'}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span className={`badge badge-${pkg.status === 'awarded' ? 'green' : pkg.status === 'quotes_received' ? 'blue' : 'yellow'}`}>{pkg.status?.replace('_',' ')}</span>
                    {pkg.status !== 'awarded' && subs.length > 0 && (
                      <a href={`/app/projects/${params.projectId}/bid-leveling/${pkg.id}`} className="btn btn-primary btn-sm">Level Bids</a>
                    )}
                  </div>
                </div>
                {subs.length > 0 ? (
                  <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
                    <table className="table">
                      <thead><tr><th>Subcontractor</th><th>Amount</th><th>vs. Low Bid</th><th>Notes</th><th>Submitted</th><th>Action</th></tr></thead>
                      <tbody>
                        {subs.sort((a: any, b: any) => Number(a.amount) - Number(b.amount)).map((sub: any) => {
                          const diff = lowestBid !== null ? Number(sub.amount) - lowestBid : 0;
                          const isLow = diff === 0;
                          return (
                            <tr key={sub.id} style={{ background: isLow ? 'rgba(22,163,74,0.04)' : undefined }}>
                              <td style={{ fontWeight: isLow ? 600 : 400 }}>
                                {isLow && <span style={{ color: 'var(--color-success-600)', fontSize: 11, marginRight: 6 }}>★ LOW</span>}
                                Sub Company
                              </td>
                              <td style={{ fontWeight: 700, color: isLow ? 'var(--color-success-600)' : undefined }}>
                                ${Number(sub.amount).toLocaleString()}
                              </td>
                              <td style={{ fontSize: 12, color: diff > 0 ? 'var(--color-danger-600)' : 'var(--color-success-600)' }}>
                                {diff === 0 ? '—' : `+$${diff.toLocaleString()}`}
                              </td>
                              <td style={{ fontSize: 12, color: 'var(--text-muted)', maxWidth: 200 }}>{sub.notes ?? '—'}</td>
                              <td style={{ fontSize: 11, color: 'var(--text-muted)' }}>{sub.submitted_at ? new Date(sub.submitted_at).toLocaleDateString() : '—'}</td>
                              <td>
                                {pkg.status !== 'awarded' && (
                                  <button className="btn btn-primary btn-sm">Award</button>
                                )}
                                {pkg.awarded_to === sub.company_id && (
                                  <span className="badge badge-green">Awarded</span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div style={{ padding: '20px', textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>No quotes received yet.</div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
