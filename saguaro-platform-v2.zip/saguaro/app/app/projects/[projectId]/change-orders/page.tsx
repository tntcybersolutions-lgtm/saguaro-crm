import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const STATUS_BADGE: Record<string, string> = {
  draft:'gray', pending_internal:'yellow', pending_client:'blue',
  approved:'green', rejected:'red', void:'gray'
};

export default async function ChangeOrdersPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const [cosRes, pcosRes, crsRes] = await Promise.all([
    supabase.from('change_orders').select('*').eq('project_id', params.projectId).order('number'),
    supabase.from('pcos').select('*').eq('project_id', params.projectId).order('number'),
    supabase.from('change_requests').select('*').eq('project_id', params.projectId).order('number'),
  ]);

  const cos = cosRes.data ?? [];
  const pcos = pcosRes.data ?? [];
  const crs = crsRes.data ?? [];

  const approvedValue = cos.filter(c => c.status === 'approved').reduce((s, c) => s + Number(c.amount || 0), 0);
  const pendingValue = cos.filter(c => ['pending_internal','pending_client'].includes(c.status)).reduce((s, c) => s + Number(c.amount || 0), 0);

  return (
    <AppShell>
      <PageHeader title="Change Management"
        subtitle={`${cos.length} change orders · $${approvedValue.toLocaleString()} approved · $${pendingValue.toLocaleString()} pending`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Change Orders' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-ghost btn-sm">+ Change Request</button>
            <button className="btn btn-ghost btn-sm">+ PCO</button>
            <button className="btn btn-primary btn-sm">+ Change Order</button>
          </div>
        }
      />

      {/* Change Requests */}
      {crs.length > 0 && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header"><span className="card-title">Change Requests</span><span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{crs.filter(c => c.status === 'open').length} open</span></div>
          <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
            <table className="table">
              <thead><tr><th>#</th><th>Title</th><th>Source</th><th>Status</th></tr></thead>
              <tbody>
                {crs.map(cr => (
                  <tr key={cr.id}>
                    <td style={{ fontFamily: 'monospace', fontSize: 12 }}>CR-{String(cr.number).padStart(3,'0')}</td>
                    <td style={{ fontWeight: 500 }}>{cr.title}</td>
                    <td><span className="badge badge-gray">{cr.source ?? 'field'}</span></td>
                    <td><span className={`badge badge-${cr.status === 'open' ? 'yellow' : 'green'}`}>{cr.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* PCOs */}
      {pcos.length > 0 && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header"><span className="card-title">Potential Change Orders (PCOs)</span></div>
          <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
            <table className="table">
              <thead><tr><th>#</th><th>Title</th><th>Status</th><th>Labor</th><th>Material</th><th>Sub</th><th>Total</th><th>Schedule Impact</th></tr></thead>
              <tbody>
                {pcos.map(p => (
                  <tr key={p.id}>
                    <td style={{ fontFamily: 'monospace', fontSize: 12 }}>PCO-{String(p.number).padStart(3,'0')}</td>
                    <td style={{ fontWeight: 500 }}>{p.title}</td>
                    <td><span className="badge badge-yellow">{p.status}</span></td>
                    <td style={{ fontSize: 12 }}>${Number(p.labor_cost||0).toLocaleString()}</td>
                    <td style={{ fontSize: 12 }}>${Number(p.material_cost||0).toLocaleString()}</td>
                    <td style={{ fontSize: 12 }}>${Number(p.sub_cost||0).toLocaleString()}</td>
                    <td style={{ fontWeight: 600 }}>${Number(p.total_cost||0).toLocaleString()}</td>
                    <td style={{ fontSize: 12 }}>{p.schedule_impact_days > 0 ? `+${p.schedule_impact_days} days` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Change Orders */}
      <div className="card">
        <div className="card-header"><span className="card-title">Change Orders</span></div>
        {cos.length === 0 ? (
          <EmptyState icon="⊕" title="No change orders" body="Change orders are created from approved PCOs or directly." />
        ) : (
          <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
            <table className="table">
              <thead><tr><th>CO #</th><th>Title</th><th>Status</th><th>Amount</th><th>Time Ext</th><th>Client Signed</th><th>Actions</th></tr></thead>
              <tbody>
                {cos.map(co => (
                  <tr key={co.id}>
                    <td style={{ fontFamily: 'monospace', fontWeight: 700 }}>CO-{String(co.number).padStart(3,'0')}</td>
                    <td style={{ fontWeight: 500 }}>{co.title}</td>
                    <td><span className={`badge badge-${STATUS_BADGE[co.status] ?? 'gray'}`}>{co.status?.replace(/_/g,' ')}</span></td>
                    <td style={{ fontWeight: 700, color: Number(co.amount) > 0 ? 'var(--color-success-600)' : 'var(--color-danger-600)' }}>
                      {Number(co.amount) >= 0 ? '+' : ''}${Number(co.amount||0).toLocaleString()}
                    </td>
                    <td style={{ fontSize: 12 }}>{co.time_extension_days > 0 ? `+${co.time_extension_days}d` : '—'}</td>
                    <td>
                      {co.client_signed_at
                        ? <span className="badge badge-green">Signed {new Date(co.client_signed_at).toLocaleDateString()}</span>
                        : co.status === 'pending_client'
                          ? <span className="badge badge-yellow">Awaiting</span>
                          : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>—</span>}
                    </td>
                    <td>
                      {co.status === 'pending_internal' && <button className="btn btn-primary btn-sm">Approve</button>}
                      {co.status === 'pending_client' && <button className="btn btn-secondary btn-sm">Send Reminder</button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppShell>
  );
}
