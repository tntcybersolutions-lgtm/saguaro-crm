import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function PhotosPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: photos } = await supabase
    .from('photos')
    .select('*')
    .eq('project_id', params.projectId)
    .order('taken_at', { ascending: false })
    .limit(60);

  return (
    <AppShell>
      <PageHeader title="Photos"
        subtitle={`${(photos ?? []).length} photos`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Photos' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <select className="form-select" style={{ height: 34, width: 'auto' }}>
              <option>All Tags</option>
              <option>Progress</option>
              <option>Safety</option>
              <option>Damage</option>
              <option>Inspections</option>
            </select>
            <button className="btn btn-secondary btn-sm">Export ZIP</button>
            <button className="btn btn-primary btn-sm">+ Upload Photos</button>
          </div>
        }
      />

      {(photos ?? []).length === 0 ? (
        <div className="card">
          <EmptyState icon="⬜" title="No photos yet" body="Upload progress photos, annotate them, and share with clients." action={<button className="btn btn-primary">+ Upload Photos</button>} />
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 12 }}>
          {(photos ?? []).map(photo => (
            <div key={photo.id} style={{ background: 'white', border: '1px solid var(--border-color)', borderRadius: 10, overflow: 'hidden', cursor: 'pointer' }}>
              <div style={{ height: 160, background: 'var(--color-stone-100)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40, color: 'var(--color-stone-300)' }}>
                {photo.signed_url
                  ? <img src={photo.signed_url} alt={photo.caption ?? photo.file_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : '📷'}
              </div>
              <div style={{ padding: '10px 12px' }}>
                <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 3 }} className="truncate">{photo.caption ?? photo.file_name}</div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                  {photo.tags?.slice(0, 2).map((tag: string) => <span key={tag} className="badge badge-gray" style={{ fontSize: 10 }}>{tag}</span>)}
                  <span style={{ fontSize: 11, color: 'var(--text-muted)', marginLeft: 'auto' }}>
                    {photo.taken_at ? new Date(photo.taken_at).toLocaleDateString() : ''}
                  </span>
                </div>
                <div style={{ marginTop: 6, display: 'flex', gap: 4 }}>
                  <span className={`badge badge-${photo.visibility === 'internal' ? 'gray' : photo.visibility === 'customer' ? 'blue' : 'green'}`} style={{ fontSize: 10 }}>
                    {photo.visibility}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
