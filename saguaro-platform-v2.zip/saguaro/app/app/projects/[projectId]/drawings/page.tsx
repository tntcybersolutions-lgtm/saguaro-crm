import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function DrawingsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: drawings } = await supabase
    .from('documents')
    .select('*')
    .eq('project_id', params.projectId)
    .eq('doc_type', 'drawing')
    .eq('is_current_version', true)
    .order('sheet_number', { ascending: true });

  const currentSet = (drawings ?? []).filter(d => d.is_current_set);
  const disciplines = [...new Set((drawings ?? []).map(d => d.discipline).filter(Boolean))];

  return (
    <AppShell>
      <PageHeader title="Drawings & Plans"
        subtitle={`${(drawings ?? []).length} sheets · ${currentSet.length} in current set · ${disciplines.length} disciplines`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Drawings' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <select className="form-select" style={{ height: 34, width: 'auto' }}>
              <option>All Disciplines</option>
              {disciplines.map(d => <option key={d}>{d}</option>)}
            </select>
            <button className="btn btn-secondary btn-sm">🔒 Lock Current Set</button>
            <button className="btn btn-primary btn-sm">+ Upload Plans</button>
          </div>
        }
      />

      {(drawings ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="◫" title="No drawings uploaded" body="Upload plan PDFs and organize them into the current set. Lock the current set to prevent accidental edits." action={<button className="btn btn-primary">+ Upload Plans</button>} /></div>
      ) : (
        <>
          {disciplines.map(disc => {
            const sheets = (drawings ?? []).filter(d => d.discipline === disc);
            return (
              <div key={disc} className="card" style={{ marginBottom: 16 }}>
                <div className="card-header">
                  <span className="card-title" style={{ textTransform: 'capitalize' }}>{disc}</span>
                  <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{sheets.length} sheets</span>
                </div>
                <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
                  <table className="table">
                    <thead><tr><th>Sheet #</th><th>Title</th><th>Rev</th><th>Current Set</th><th>Version</th><th>Actions</th></tr></thead>
                    <tbody>
                      {sheets.map(s => (
                        <tr key={s.id}>
                          <td style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 13 }}>{s.sheet_number ?? '—'}</td>
                          <td style={{ fontWeight: 500 }}>{s.sheet_title ?? s.file_name}</td>
                          <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{s.revision ?? '0'}</td>
                          <td>{s.is_current_set ? <span className="badge badge-green">✓ Current</span> : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>Superseded</span>}</td>
                          <td style={{ fontFamily: 'monospace', fontSize: 12 }}>v{s.version}</td>
                          <td>
                            <div style={{ display: 'flex', gap: 4 }}>
                              <button className="btn btn-primary btn-sm">View</button>
                              <button className="btn btn-ghost btn-sm">↓</button>
                              <button className="btn btn-ghost btn-sm">Rev ↑</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
          {disciplines.length === 0 && (
            <div className="table-wrap">
              <table className="table">
                <thead><tr><th>Sheet #</th><th>Title</th><th>Rev</th><th>Current Set</th><th>Actions</th></tr></thead>
                <tbody>
                  {(drawings ?? []).map(s => (
                    <tr key={s.id}>
                      <td style={{ fontFamily: 'monospace', fontWeight: 700 }}>{s.sheet_number ?? '—'}</td>
                      <td>{s.sheet_title ?? s.file_name}</td>
                      <td>{s.revision ?? '0'}</td>
                      <td>{s.is_current_set ? <span className="badge badge-green">✓</span> : '—'}</td>
                      <td><button className="btn btn-primary btn-sm">View</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </AppShell>
  );
}
