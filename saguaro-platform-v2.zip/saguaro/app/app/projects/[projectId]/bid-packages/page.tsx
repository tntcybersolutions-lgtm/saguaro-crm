import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const STATUS_BADGE: Record<string, string> = {
  draft:'gray', invitations_sent:'blue', quotes_received:'yellow', leveling:'clay', awarded:'green', void:'gray'
};

export default async function BidPackagesPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: packages } = await supabase
    .from('bid_packages')
    .select('*, bid_submissions(id, amount, company_id)')
    .eq('project_id', params.projectId)
    .order('number', { ascending: true });

  return (
    <AppShell>
      <PageHeader title="Bid Packages"
        subtitle={`${(packages ?? []).length} packages · ${(packages ?? []).filter(p => p.status === 'awarded').length} awarded`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Bid Packages' }]}
        actions={<button className="btn btn-primary btn-sm">+ New Bid Package</button>}
      />

      {(packages ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="⊞" title="No bid packages" body="Create bid packages to invite subcontractors, collect quotes, and award work." /></div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {(packages ?? []).map((pkg: any) => {
            const subs = pkg.bid_submissions ?? [];
            const lowestBid = subs.length > 0 ? Math.min(...subs.map((s: any) => Number(s.amount))) : null;
            return (
              <div key={pkg.id} className="card">
                <div style={{ padding: '16px 20px', display: 'flex', gap: 16, alignItems: 'center' }}>
                  <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', minWidth: 60 }}>
                    BP-{String(pkg.number).padStart(3,'0')}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{pkg.title}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                      {pkg.trade ?? 'General'}{pkg.due_date ? ` · Due ${new Date(pkg.due_date).toLocaleDateString()}` : ''}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Quotes</div>
                      <div style={{ fontWeight: 700 }}>{subs.length}</div>
                    </div>
                    {lowestBid && (
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Low Bid</div>
                        <div style={{ fontWeight: 700, color: 'var(--color-success-600)' }}>${lowestBid.toLocaleString()}</div>
                      </div>
                    )}
                    {pkg.awarded_amount && (
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Awarded</div>
                        <div style={{ fontWeight: 700 }}>${Number(pkg.awarded_amount).toLocaleString()}</div>
                      </div>
                    )}
                    <span className={`badge badge-${STATUS_BADGE[pkg.status] ?? 'gray'}`} style={{ fontSize: 12 }}>{pkg.status?.replace(/_/g,' ')}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {pkg.status === 'draft' && <button className="btn btn-secondary btn-sm">Send Invites</button>}
                    {pkg.status === 'quotes_received' && (
                      <a href={`/app/projects/${params.projectId}/bid-leveling`} className="btn btn-primary btn-sm">Level Bids →</a>
                    )}
                    {pkg.status === 'awarded' && <span className="badge badge-green">Awarded ✓</span>}
                    <button className="btn btn-ghost btn-sm">View</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
