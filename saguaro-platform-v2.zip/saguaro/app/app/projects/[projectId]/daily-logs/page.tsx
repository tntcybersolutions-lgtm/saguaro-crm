import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

export default async function DailyLogsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: logs } = await supabase
    .from('daily_logs')
    .select('*')
    .eq('project_id', params.projectId)
    .order('log_date', { ascending: false });

  const today = new Date().toISOString().split('T')[0];
  const hasToday = (logs ?? []).some(l => l.log_date === today);

  return (
    <AppShell>
      <PageHeader title="Daily Logs"
        subtitle={`${(logs ?? []).length} entries · ${hasToday ? 'Today submitted ✓' : '⚠ No log for today yet'}`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Daily Logs' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm">Export</button>
            <button className="btn btn-primary btn-sm">+ New Log</button>
          </div>
        }
      />

      {!hasToday && (
        <div className="alert alert-warning" style={{ marginBottom: 16 }}>
          <strong>No daily log submitted today.</strong> Autopilot will flag this after 7pm.
        </div>
      )}

      {(logs ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="▦" title="No daily logs yet" body="Create daily logs to track weather, manpower, work performed, and site activity." action={<button className="btn btn-primary">+ Create Daily Log</button>} /></div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {(logs ?? []).map(log => (
            <div key={log.id} className="card">
              <div style={{ padding: '14px 20px', display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                <div style={{ minWidth: 90 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>
                    {new Date(log.log_date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                  </div>
                  <span className={`badge badge-${log.is_submitted ? 'green' : 'yellow'}`} style={{ marginTop: 4 }}>
                    {log.is_submitted ? 'Submitted' : 'Draft'}
                  </span>
                </div>
                <div style={{ flex: 1, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>Weather</div>
                    <div style={{ fontSize: 13 }}>{log.weather_conditions ?? '—'}
                      {log.temp_high && <span style={{ color: 'var(--text-muted)', fontSize: 11, marginLeft: 6 }}>{log.temp_low}°–{log.temp_high}°F</span>}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>Manpower</div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{log.manpower_count ?? 0} workers</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>Delays</div>
                    <div style={{ fontSize: 13, color: log.delays ? 'var(--color-warning-600)' : 'var(--text-muted)' }}>{log.delays ?? 'None'}</div>
                  </div>
                </div>
                {log.work_performed && (
                  <div style={{ maxWidth: 260, fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5, borderLeft: '2px solid var(--border-color)', paddingLeft: 12 }}>
                    {log.work_performed.slice(0, 140)}{log.work_performed.length > 140 ? '…' : ''}
                  </div>
                )}
                <a href={`/app/projects/${params.projectId}/daily-logs/${log.id}`} className="btn btn-ghost btn-sm" style={{ flexShrink: 0 }}>View →</a>
              </div>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
