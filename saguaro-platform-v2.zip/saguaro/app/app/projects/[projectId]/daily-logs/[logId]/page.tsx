import { createServerSupabase } from '../../../../../../lib/serverAuth';
import AppShell from '../../../../../../components/AppShell';
import { notFound } from 'next/navigation';

interface Props { params: { projectId: string; logId: string } }

export default async function DailyLogDetailPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: log } = await supabase.from('daily_logs').select('*').eq('id', params.logId).single();
  if (!log) notFound();

  const laborByTrade = (log.labor_by_trade as any[]) ?? [];
  const visitors = (log.visitors as any[]) ?? [];
  const deliveries = (log.deliveries as any[]) ?? [];

  return (
    <AppShell>
      <div style={{ maxWidth: 840 }}>
        <div style={{ marginBottom: 20 }}>
          <a href={`/app/projects/${params.projectId}/daily-logs`} style={{ fontSize: 12, color: 'var(--text-muted)' }}>← Back to Daily Logs</a>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.4rem' }}>
              Daily Log — {new Date(log.log_date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </h1>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <span className={`badge badge-${log.is_submitted ? 'green' : 'yellow'}`}>{log.is_submitted ? 'Submitted' : 'Draft'}</span>
            <button className="btn btn-secondary btn-sm">↓ Export PDF</button>
            {!log.is_submitted && <button className="btn btn-primary btn-sm">Submit Log</button>}
          </div>
        </div>

        <div className="grid-2" style={{ marginBottom: 16 }}>
          {/* Weather */}
          <div className="card">
            <div className="card-header"><span className="card-title">Weather Conditions</span></div>
            <div className="card-body">
              <div className="grid-2">
                {[
                  ['Conditions', log.weather_conditions ?? '—'],
                  ['Temp Range', log.temp_high ? `${log.temp_low}°–${log.temp_high}°F` : '—'],
                  ['Wind', log.wind_speed ?? '—'],
                  ['Precipitation', log.precipitation ?? 'None'],
                ].map(([k, v]) => (
                  <div key={k}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: 2 }}>{k}</div>
                    <div style={{ fontSize: 13 }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Manpower Summary */}
          <div className="card">
            <div className="card-header"><span className="card-title">Manpower</span></div>
            <div className="card-body">
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '2rem', marginBottom: 8 }}>{log.manpower_count ?? 0}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Total workers on site</div>
              {laborByTrade.length > 0 && (
                <div style={{ marginTop: 12 }}>
                  {laborByTrade.map((lt: any, i: number) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, padding: '3px 0', borderBottom: '1px solid var(--border-color)' }}>
                      <span>{lt.trade} — {lt.company}</span>
                      <span style={{ fontWeight: 600 }}>{lt.headcount} workers · {lt.hours}h</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Work Performed */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header"><span className="card-title">Work Performed</span></div>
          <div className="card-body">
            <p style={{ fontSize: 13, lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{log.work_performed ?? 'No description entered.'}</p>
          </div>
        </div>

        <div className="grid-2" style={{ marginBottom: 16 }}>
          {/* Delays */}
          <div className="card">
            <div className="card-header"><span className="card-title">Delays</span></div>
            <div className="card-body">
              {log.delays ? (
                <>
                  <span className="badge badge-yellow" style={{ marginBottom: 8 }}>{log.delay_type ?? 'Delay'}</span>
                  <p style={{ fontSize: 13, lineHeight: 1.6 }}>{log.delays}</p>
                </>
              ) : <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No delays reported.</p>}
            </div>
          </div>

          {/* Safety Notes */}
          <div className="card">
            <div className="card-header"><span className="card-title">Safety Notes</span></div>
            <div className="card-body">
              <p style={{ fontSize: 13, lineHeight: 1.6, color: log.safety_notes ? 'var(--text-primary)' : 'var(--text-muted)' }}>
                {log.safety_notes ?? 'No safety notes.'}
              </p>
            </div>
          </div>
        </div>

        {/* Visitors & Deliveries */}
        {(visitors.length > 0 || deliveries.length > 0) && (
          <div className="grid-2">
            {visitors.length > 0 && (
              <div className="card">
                <div className="card-header"><span className="card-title">Visitors</span></div>
                <div className="card-body">
                  {visitors.map((v: any, i: number) => (
                    <div key={i} style={{ fontSize: 13, padding: '4px 0', borderBottom: '1px solid var(--border-color)' }}>
                      {v.name} — {v.company ?? v.purpose ?? ''}
                    </div>
                  ))}
                </div>
              </div>
            )}
            {deliveries.length > 0 && (
              <div className="card">
                <div className="card-header"><span className="card-title">Deliveries</span></div>
                <div className="card-body">
                  {deliveries.map((d: any, i: number) => (
                    <div key={i} style={{ fontSize: 13, padding: '4px 0', borderBottom: '1px solid var(--border-color)' }}>
                      {d.item ?? d.vendor} {d.qty ? `— ${d.qty}` : ''}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </AppShell>
  );
}
