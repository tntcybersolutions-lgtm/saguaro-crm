import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const DOC_TYPE_ICON: Record<string, string> = { drawing:'◫', spec:'▣', contract:'⬡', permit:'◑', submittal:'◨', rfi:'◳', photo:'⬜', other:'▦' };

export default async function DocumentsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: docs } = await supabase
    .from('documents')
    .select('*')
    .eq('project_id', params.projectId)
    .eq('is_current_version', true)
    .order('created_at', { ascending: false });

  const byType = (docs ?? []).reduce((acc: Record<string, number>, d) => {
    acc[d.doc_type ?? 'other'] = (acc[d.doc_type ?? 'other'] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <AppShell>
      <PageHeader title="Documents"
        subtitle={`${(docs ?? []).length} documents · ${Object.keys(byType).length} categories`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Documents' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <select className="form-select" style={{ height: 34, width: 'auto' }}>
              <option>All Types</option>
              <option>Drawings</option>
              <option>Specs</option>
              <option>Contracts</option>
              <option>Permits</option>
              <option>Submittals</option>
            </select>
            <select className="form-select" style={{ height: 34, width: 'auto' }}>
              <option>All Visibility</option>
              <option>Internal</option>
              <option>Customer</option>
              <option>Trade</option>
            </select>
            <button className="btn btn-primary btn-sm">+ Upload</button>
          </div>
        }
      />

      {(docs ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="▣" title="No documents yet" body="Upload drawings, specs, contracts, permits, and other project documents." action={<button className="btn btn-primary">+ Upload Document</button>} /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>File</th><th>Type</th><th>Discipline</th><th>Ver</th><th>Visibility</th><th>Current Set</th><th>Uploaded</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {(docs ?? []).map(doc => (
                <tr key={doc.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 18, flexShrink: 0 }}>{DOC_TYPE_ICON[doc.doc_type ?? 'other']}</span>
                      <div>
                        <div style={{ fontWeight: 500, fontSize: 13 }}>{doc.sheet_title ?? doc.file_name}</div>
                        {doc.sheet_number && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{doc.sheet_number}</div>}
                      </div>
                    </div>
                  </td>
                  <td><span className="badge badge-gray">{doc.doc_type ?? 'other'}</span></td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{doc.discipline ?? '—'}</td>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>v{doc.version}</td>
                  <td>
                    <span className={`badge badge-${doc.visibility === 'customer' ? 'blue' : doc.visibility === 'trade' ? 'clay' : 'gray'}`}>
                      {doc.visibility}
                    </span>
                  </td>
                  <td>
                    {doc.is_current_set
                      ? <span className="badge badge-green">✓ Current</span>
                      : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>—</span>}
                  </td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                    {doc.created_at ? new Date(doc.created_at).toLocaleDateString() : '—'}
                  </td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-ghost btn-sm">↓ Download</button>
                      <button className="btn btn-ghost btn-sm">Share</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
