import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const STATUS_BADGE: Record<string, string> = { pending:'gray', ordered:'blue', in_transit:'yellow', received:'green', damaged:'critical' };

export default async function ProcurementPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: items } = await supabase
    .from('procurement_items')
    .select('*')
    .eq('project_id', params.projectId)
    .order('needed_by_date', { ascending: true });

  const longLead = (items ?? []).filter(i => i.is_long_lead);
  const atRisk = (items ?? []).filter(i => i.risk_flag);
  const damaged = (items ?? []).filter(i => i.status === 'damaged');

  return (
    <AppShell>
      <PageHeader title="Procurement & Long-Lead"
        subtitle={`${(items ?? []).length} items · ${longLead.length} long-lead · ${atRisk.length} at risk`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Procurement' }]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm">Export Long-Lead Report</button>
            <button className="btn btn-primary btn-sm">+ Add Item</button>
          </div>
        }
      />

      {damaged.length > 0 && (
        <div className="alert alert-danger" style={{ marginBottom: 16 }}>
          <strong>{damaged.length} damaged delivery{damaged.length > 1 ? 's' : ''} require damage claim packets.</strong>
        </div>
      )}

      {(items ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="⬦" title="No procurement items" body="Track materials, equipment, and long-lead items with delivery dates and risk flags." /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>Item</th><th>Status</th><th>Vendor</th><th>Needed By</th><th>Lead Time</th><th>Expected Delivery</th><th>Qty</th><th>Flags</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {(items ?? []).map(item => {
                const today = new Date();
                const delivery = item.expected_delivery_date ? new Date(item.expected_delivery_date) : null;
                const needed = item.needed_by_date ? new Date(item.needed_by_date) : null;
                const isLate = delivery && needed && delivery > needed;
                return (
                  <tr key={item.id} style={{ background: item.risk_flag ? 'rgba(220,38,38,0.03)' : undefined }}>
                    <td style={{ fontWeight: 500, maxWidth: 220 }}>{item.item_description}</td>
                    <td><span className={`badge badge-${STATUS_BADGE[item.status] ?? 'gray'}`}>{item.status}</span></td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{item.po_number ? `PO# ${item.po_number}` : '—'}</td>
                    <td style={{ fontSize: 12, fontWeight: isLate ? 600 : 400, color: isLate ? 'var(--color-danger-600)' : undefined }}>{item.needed_by_date ?? '—'}</td>
                    <td style={{ fontSize: 12 }}>{item.lead_time_days ? `${item.lead_time_days}d` : '—'}</td>
                    <td style={{ fontSize: 12, color: isLate ? 'var(--color-danger-600)' : undefined }}>{item.expected_delivery_date ?? '—'}</td>
                    <td style={{ fontSize: 12 }}>{item.quantity ?? '—'} {item.unit}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                        {item.is_long_lead && <span className="badge badge-yellow">Long Lead</span>}
                        {item.risk_flag && <span className="badge badge-critical">At Risk</span>}
                        {item.damage_noted && <span className="badge badge-red">Damaged</span>}
                      </div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 4 }}>
                        {item.status === 'in_transit' && <button className="btn btn-primary btn-sm">Mark Received</button>}
                        {item.damage_noted && <button className="btn btn-danger btn-sm">Claim Packet</button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
