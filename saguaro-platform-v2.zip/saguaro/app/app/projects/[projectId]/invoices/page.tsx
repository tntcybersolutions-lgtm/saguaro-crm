import { createServerSupabase } from '../../../../../lib/serverAuth';
import AppShell from '../../../../../components/AppShell';
import PageHeader from '../../../../../components/PageHeader';
import EmptyState from '../../../../../components/EmptyState';

interface Props { params: { projectId: string } }

const STATUS_BADGE: Record<string, string> = { draft:'gray', pending:'yellow', approved:'blue', paid:'green', void:'gray', cancelled:'gray' };

export default async function InvoicesPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: invoices } = await supabase.from('invoices').select('*').eq('project_id', params.projectId).order('created_at', { ascending: false });

  const totalPending = (invoices ?? []).filter(i => i.status === 'pending').reduce((s, i) => s + Number(i.amount || 0), 0);
  const totalPaid = (invoices ?? []).filter(i => i.status === 'paid').reduce((s, i) => s + Number(i.amount || 0), 0);

  return (
    <AppShell>
      <PageHeader title="Invoices" subtitle={`$${totalPending.toLocaleString()} pending approval · $${totalPaid.toLocaleString()} paid`}
        breadcrumb={[{ label: 'Projects', href: '/app/projects' }, { label: 'Project', href: `/app/projects/${params.projectId}` }, { label: 'Invoices' }]}
        actions={<button className="btn btn-primary btn-sm">+ New Invoice</button>}
      />
      {(invoices ?? []).length === 0 ? (
        <div className="card"><EmptyState icon="◉" title="No invoices yet" body="Track sub and vendor invoices, approvals, and payments." /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Invoice #</th><th>Type</th><th>Status</th><th>Amount</th><th>Retainage</th><th>Net Due</th><th>Due Date</th><th>Lien Waiver</th><th>Actions</th></tr></thead>
            <tbody>
              {(invoices ?? []).map(i => (
                <tr key={i.id}>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{i.invoice_number}</td>
                  <td><span className="badge badge-gray">{i.type}</span></td>
                  <td><span className={`badge badge-${STATUS_BADGE[i.status] ?? 'gray'}`}>{i.status}</span></td>
                  <td style={{ fontWeight: 600 }}>${Number(i.amount || 0).toLocaleString()}</td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{i.retainage_pct ?? 0}%</td>
                  <td style={{ fontWeight: 500 }}>${Number(i.net_due || 0).toLocaleString()}</td>
                  <td style={{ fontSize: 12 }}>{i.due_date ?? '—'}</td>
                  <td>
                    {i.lien_waiver_required ? (
                      i.lien_waiver_received ? <span className="badge badge-green">Received</span> : <span className="badge badge-red">Required</span>
                    ) : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>N/A</span>}
                  </td>
                  <td>
                    {i.status === 'pending' && (
                      <div style={{ display: 'flex', gap: 4 }}>
                        <button className="btn btn-primary btn-sm">Approve</button>
                        <button className="btn btn-ghost btn-sm">Reject</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
