import { createServerSupabase } from '../../../../../../lib/serverAuth';
import AppShell from '../../../../../../components/AppShell';
import { notFound } from 'next/navigation';

interface Props { params: { projectId: string; invoiceId: string } }

export default async function InvoiceDetailPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: inv } = await supabase.from('invoices').select('*').eq('id', params.invoiceId).single();
  if (!inv) notFound();

  return (
    <AppShell>
      <div style={{ maxWidth: 760 }}>
        <div style={{ marginBottom: 20 }}>
          <a href={`/app/projects/${params.projectId}/invoices`} style={{ fontSize: 12, color: 'var(--text-muted)' }}>← Back to Invoices</a>
        </div>
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-body">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24 }}>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Invoice · {inv.type?.toUpperCase()}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.4rem' }}>{inv.invoice_number}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Amount Due</div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.6rem' }}>${Number(inv.net_due ?? inv.amount).toLocaleString()}</div>
              </div>
            </div>
            <div className="grid-2" style={{ marginBottom: 20 }}>
              {[
                ['Status', <span className={`badge badge-${inv.status === 'paid' ? 'green' : inv.status === 'approved' ? 'blue' : inv.status === 'pending' ? 'yellow' : 'gray'}`}>{inv.status}</span>],
                ['Invoice Date', inv.invoice_date ?? '—'],
                ['Due Date', inv.due_date ?? '—'],
                ['Period', inv.period_start ? `${inv.period_start} – ${inv.period_end ?? '?'}` : '—'],
                ['Gross Amount', `$${Number(inv.amount).toLocaleString()}`],
                ['Retainage', `${inv.retainage_pct ?? 0}% ($${Number(inv.retainage_held ?? 0).toLocaleString()})`],
              ].map(([k, v]) => (
                <div key={k as string}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3 }}>{k}</div>
                  <div style={{ fontSize: 13 }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ padding: '12px 16px', background: inv.lien_waiver_received ? 'rgba(22,163,74,0.06)' : 'rgba(220,38,38,0.04)', borderRadius: 8, border: `1px solid ${inv.lien_waiver_received ? 'rgba(22,163,74,0.2)' : 'rgba(220,38,38,0.2)'}`, fontSize: 13 }}>
              <strong>Lien Waiver:</strong> {inv.lien_waiver_required ? (inv.lien_waiver_received ? '✓ Received' : '⚠ Required — not yet received. Payment blocked until received.') : 'Not required'}
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary">↓ Export PDF</button>
          {inv.status === 'pending' && <><button className="btn btn-primary">Approve Invoice</button><button className="btn btn-ghost">Reject</button></>}
          {inv.status === 'approved' && <button className="btn btn-primary">Mark Paid</button>}
        </div>
      </div>
    </AppShell>
  );
}
