import { createServerSupabase } from '../../../lib/serverAuth';
import AppShell from '../../../components/AppShell';
import PageHeader from '../../../components/PageHeader';
import EmptyState from '../../../components/EmptyState';

export default async function ProjectsPage() {
  const supabase = await createServerSupabase();
  const { data: projects } = await supabase
    .from('projects')
    .select('*')
    .order('created_at', { ascending: false });

  return (
    <AppShell>
      <PageHeader
        title="Portfolio"
        subtitle="All projects across the organization"
        actions={
          <>
            <select className="form-select" style={{ width: 'auto', height: 34 }}>
              <option>All Statuses</option>
              <option>Active</option>
              <option>Precon</option>
              <option>Closeout</option>
              <option>Complete</option>
            </select>
            <button className="btn btn-primary btn-sm">+ New Project</button>
          </>
        }
      />

      {(projects ?? []).length === 0 ? (
        <div className="card">
          <EmptyState icon="⬡" title="No projects yet" body="Create your first project to get started." action={<button className="btn btn-primary">+ Create Project</button>} />
        </div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Project #</th>
                <th>Name</th>
                <th>Status</th>
                <th>Type</th>
                <th>Contract Value</th>
                <th>Start</th>
                <th>Finish Target</th>
                <th>Health</th>
                <th>Portfolio</th>
              </tr>
            </thead>
            <tbody>
              {(projects ?? []).map(p => (
                <tr key={p.id}>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'monospace' }}>{p.project_number}</td>
                  <td>
                    <a href={`/app/projects/${p.id}`} style={{ fontWeight: 600, color: 'var(--color-blue-700)' }}>{p.name}</a>
                    {p.site_city && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{p.site_city}, {p.site_state}</div>}
                  </td>
                  <td><span className={`badge badge-${p.status === 'active' ? 'green' : p.status === 'precon' ? 'blue' : p.status === 'closeout' ? 'yellow' : 'gray'}`}>{p.status}</span></td>
                  <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{p.type ?? '—'}</td>
                  <td style={{ fontWeight: 500 }}>{p.contract_value ? `$${Number(p.contract_value).toLocaleString()}` : '—'}</td>
                  <td style={{ fontSize: 12 }}>{p.start_date ?? '—'}</td>
                  <td style={{ fontSize: 12 }}>{p.target_finish_date ?? '—'}</td>
                  <td>
                    {p.health_score !== null ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <div style={{ width: 48, height: 5, background: 'var(--border-color)', borderRadius: 3 }}>
                          <div style={{ width: `${p.health_score}%`, height: '100%', background: p.health_score >= 80 ? 'var(--color-success-600)' : p.health_score >= 60 ? 'var(--color-warning-600)' : 'var(--color-danger-600)', borderRadius: 3 }} />
                        </div>
                        <span style={{ fontSize: 11 }}>{p.health_score}</span>
                      </div>
                    ) : '—'}
                  </td>
                  <td>
                    <div style={{ width: 14, height: 14, borderRadius: 3, background: p.publish_to_portfolio ? 'var(--color-success-600)' : 'var(--border-color)' }} title={p.publish_to_portfolio ? 'Published' : 'Not published'} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
