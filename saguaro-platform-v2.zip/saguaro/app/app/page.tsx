import { createServerSupabase } from '../../lib/serverAuth';
import AppShell from '../../components/AppShell';
import PageHeader from '../../components/PageHeader';

export default async function DashboardPage() {
  const supabase = await createServerSupabase();
  const { data: { session } } = await supabase.auth.getSession();

  const [projectsRes, alertsRes] = await Promise.all([
    supabase.from('projects').select('id, name, status, health_score, contract_value, client_id').limit(20),
    supabase.from('autopilot_alerts').select('severity, status').in('status', ['open','acknowledged']),
  ]);

  const projects = projectsRes.data ?? [];
  const alerts = alertsRes.data ?? [];

  const activeProjects = projects.filter(p => p.status === 'active').length;
  const atRisk = projects.filter(p => p.health_score !== null && p.health_score < 60).length;
  const criticalAlerts = alerts.filter(a => a.severity === 'critical').length;
  const openAlerts = alerts.length;

  const totalValue = projects.reduce((sum, p) => sum + (p.contract_value ?? 0), 0);

  return (
    <AppShell>
      <PageHeader
        title="Executive Dashboard"
        subtitle="Portfolio overview and action items"
        actions={
          <>
            <button className="btn btn-secondary btn-sm">Export PDF</button>
            <button className="btn btn-primary btn-sm">+ New Project</button>
          </>
        }
      />

      {/* KPI Strip */}
      <div className="stat-cards">
        <div className="stat-card" style={{ '--stat-color': 'var(--color-blue-700)' } as React.CSSProperties}>
          <div className="stat-label">Active Projects</div>
          <div className="stat-value">{activeProjects}</div>
          <div className="stat-sub">{projects.length} total in portfolio</div>
        </div>
        <div className="stat-card" style={{ '--stat-color': 'var(--color-clay-700)' } as React.CSSProperties}>
          <div className="stat-label">Portfolio Value</div>
          <div className="stat-value">${(totalValue / 1_000_000).toFixed(1)}M</div>
          <div className="stat-sub">Contract value</div>
        </div>
        <div className="stat-card" style={{ '--stat-color': criticalAlerts > 0 ? 'var(--color-danger-600)' : 'var(--color-success-600)' } as React.CSSProperties}>
          <div className="stat-label">Autopilot Alerts</div>
          <div className="stat-value">{openAlerts}</div>
          <div className="stat-sub">{criticalAlerts} critical</div>
        </div>
        <div className="stat-card" style={{ '--stat-color': atRisk > 0 ? 'var(--color-warning-600)' : 'var(--color-success-600)' } as React.CSSProperties}>
          <div className="stat-label">At-Risk Projects</div>
          <div className="stat-value">{atRisk}</div>
          <div className="stat-sub">Health score &lt; 60</div>
        </div>
      </div>

      <div className="grid-2">
        {/* Projects Table */}
        <div className="card" style={{ gridColumn: '1 / -1' }}>
          <div className="card-header">
            <span className="card-title">Active Portfolio</span>
            <a href="/app/projects" className="btn btn-ghost btn-sm">View all →</a>
          </div>
          <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
            <table className="table">
              <thead>
                <tr>
                  <th>Project</th>
                  <th>Status</th>
                  <th>Contract Value</th>
                  <th>Health</th>
                </tr>
              </thead>
              <tbody>
                {projects.slice(0, 8).map(p => (
                  <tr key={p.id}>
                    <td style={{ fontWeight: 500 }}>{p.name}</td>
                    <td>
                      <span className={`badge badge-${p.status === 'active' ? 'green' : p.status === 'precon' ? 'blue' : 'gray'}`}>
                        {p.status}
                      </span>
                    </td>
                    <td>{p.contract_value ? `$${p.contract_value.toLocaleString()}` : '—'}</td>
                    <td>
                      {p.health_score !== null ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <div style={{ width: 60, height: 6, background: 'var(--border-color)', borderRadius: 3 }}>
                            <div style={{
                              width: `${p.health_score}%`,
                              height: '100%',
                              background: p.health_score >= 80 ? 'var(--color-success-600)' : p.health_score >= 60 ? 'var(--color-warning-600)' : 'var(--color-danger-600)',
                              borderRadius: 3
                            }} />
                          </div>
                          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{p.health_score}</span>
                        </div>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
                {projects.length === 0 && (
                  <tr><td colSpan={4} style={{ textAlign: 'center', padding: '32px', color: 'var(--text-muted)' }}>No projects yet. Create your first project.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
