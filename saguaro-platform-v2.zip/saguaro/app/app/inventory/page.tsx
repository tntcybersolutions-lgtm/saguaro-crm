import AppShell from '../../../components/AppShell';
import PageHeader from '../../../components/PageHeader';
import { createServerSupabase } from '../../../lib/serverAuth';
import EmptyState from '../../../components/EmptyState';

export default async function InventoryPage() {
  const supabase = await createServerSupabase();
  const [catalogRes, stockRes] = await Promise.all([
    supabase.from('inventory_catalog').select('*').order('sku').limit(50),
    supabase.from('inventory_stock').select('*, inventory_catalog(sku, description), inventory_locations(name, type)'),
  ]);

  const catalog = catalogRes.data ?? [];
  const stock = stockRes.data ?? [];

  const lowStock = stock.filter(s => Number(s.quantity_available) <= 0 || Number(s.quantity_on_hand) <= (s as any).inventory_catalog?.reorder_point).length;

  return (
    <AppShell>
      <PageHeader title="Inventory" subtitle={`${catalog.length} SKUs · ${lowStock} items below reorder point`}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm">Import CSV</button>
            <button className="btn btn-secondary btn-sm">Export</button>
            <button className="btn btn-primary btn-sm">+ Add Item</button>
          </div>
        }
      />
      {catalog.length === 0 ? (
        <div className="card"><EmptyState icon="▣" title="No inventory items" body="Import your catalog via CSV or add items manually." action={<button className="btn btn-primary">Import CSV</button>} /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>SKU</th><th>Description</th><th>Category</th><th>Unit</th><th>Unit Cost</th><th>Reorder Point</th><th>Status</th></tr></thead>
            <tbody>
              {catalog.map(item => {
                const itemStock = stock.filter(s => s.item_id === item.id);
                const totalOnHand = itemStock.reduce((sum, s) => sum + Number(s.quantity_on_hand || 0), 0);
                const belowReorder = totalOnHand <= (item.reorder_point ?? 0);
                return (
                  <tr key={item.id}>
                    <td style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 600 }}>{item.sku}</td>
                    <td style={{ fontWeight: 500 }}>{item.description}</td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{item.category ?? '—'}</td>
                    <td style={{ fontSize: 12 }}>{item.unit}</td>
                    <td style={{ fontSize: 13 }}>{item.unit_cost ? `$${Number(item.unit_cost).toFixed(2)}` : '—'}</td>
                    <td style={{ fontSize: 12 }}>{item.reorder_point ?? 0} {item.unit}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontSize: 12, fontWeight: 500 }}>{totalOnHand} {item.unit}</span>
                        {belowReorder && <span className="badge badge-red">Low Stock</span>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
