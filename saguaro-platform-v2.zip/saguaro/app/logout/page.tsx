import { createServerSupabase } from '../../lib/serverAuth';
import { redirect } from 'next/navigation';

export default async function LogoutPage() {
  const supabase = await createServerSupabase();
  await supabase.auth.signOut();
  redirect('/login');
}
