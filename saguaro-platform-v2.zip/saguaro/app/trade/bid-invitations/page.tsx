import { createServerSupabase } from '../../../lib/serverAuth';
import { redirect } from 'next/navigation';

export default async function TradeBidInvitationsPage() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=trade');

  const { data: invitations } = await supabase
    .from('bid_invitations')
    .select('*, bid_packages(*, projects(name,project_number,site_city,site_state))')
    .eq('contact_email', user.email)
    .order('created_at', { ascending: false });

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: '#1e2d3d', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', gap: 14, position: 'sticky', top: 0, zIndex: 40 }}>
        <a href="/trade/dashboard" style={{ color: 'rgba(255,255,255,0.6)', fontSize: 18, textDecoration: 'none' }}>←</a>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: 'white' }}>Bid Invitations</div>
      </header>
      <main style={{ maxWidth: 860, margin: '0 auto', padding: '28px 24px' }}>
        {(invitations ?? []).length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 60, textAlign: 'center', border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>◳</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 8 }}>No invitations yet</div>
            <p style={{ fontSize: 13, color: '#6b7280' }}>Bid invitations will appear here when you're added to a bid package.</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {(invitations ?? []).map((inv: any) => {
              const pkg = inv.bid_packages ?? {};
              const proj = pkg.projects ?? {};
              const isOpen = ['invited','viewed'].includes(inv.status);
              const isPast = pkg.due_date && new Date(pkg.due_date) < new Date();
              return (
                <div key={inv.id} style={{ background: 'white', borderRadius: 14, border: `1px solid ${isOpen ? '#dbeafe' : '#e5e7eb'}`, overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
                  <div style={{ background: isOpen ? '#f0f7ff' : '#f9fafb', padding: '14px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>{pkg.title}</div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>{proj.name} · {proj.site_city}, {proj.site_state}</div>
                    </div>
                    <span style={{ background: isOpen ? '#dbeafe' : inv.status === 'submitted' ? '#dcfce7' : '#f3f4f6', color: isOpen ? '#1e4d8c' : inv.status === 'submitted' ? '#16a34a' : '#6b7280', padding: '3px 10px', borderRadius: 6, fontSize: 12, fontWeight: 700, textTransform: 'capitalize' }}>{inv.status}</span>
                  </div>
                  <div style={{ padding: '14px 20px', display: 'flex', gap: 24, alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', marginBottom: 2 }}>Trade</div>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{pkg.trade ?? '—'}</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', marginBottom: 2 }}>Due Date</div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: isPast && isOpen ? '#dc2626' : '#111827' }}>{pkg.due_date ?? '—'}{isPast && isOpen ? ' (PAST DUE)' : ''}</div>
                    </div>
                    {inv.status === 'submitted' && (
                      <div>
                        <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', marginBottom: 2 }}>Your Bid</div>
                        <div style={{ fontSize: 13, fontWeight: 700, color: '#16a34a' }}>Submitted ✓</div>
                      </div>
                    )}
                    <div style={{ marginLeft: 'auto' }}>
                      {isOpen && <a href={`/trade/bid-invitations/${inv.id}`} style={{ padding: '9px 18px', background: '#1e4d8c', color: 'white', borderRadius: 8, fontSize: 13, fontWeight: 700, textDecoration: 'none' }}>Submit Quote →</a>}
                      {inv.status === 'submitted' && <a href={`/trade/bid-invitations/${inv.id}`} style={{ padding: '9px 18px', background: '#f3f4f6', border: '1px solid #e5e7eb', color: '#374151', borderRadius: 8, fontSize: 13, fontWeight: 600, textDecoration: 'none' }}>View Submission</a>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
