'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getSupabaseClient } from '../../../../lib/supabaseClient';

export default function SubmitBidPage() {
  const params = useParams();
  const router = useRouter();
  const invitationId = params.invitationId as string;
  const [invitation, setInvitation] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    amount: '', labor: '', material: '', subcontract: '', equipment: '', overhead: '', profit: '',
    schedule_days: '', exclusions: '', qualifications: '', bond_required: '', bond_rate: '',
    valid_until: '',
  });

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  useEffect(() => {
    const supabase = getSupabaseClient();
    supabase.from('bid_invitations')
      .select('*, bid_packages(*, projects(name,project_number,site_address,site_city,site_state))')
      .eq('id', invitationId)
      .single()
      .then(({ data }) => {
        setInvitation(data);
        setLoading(false);
        // Mark as viewed
        if (data?.status === 'invited') supabase.from('bid_invitations').update({ status: 'viewed', viewed_at: new Date().toISOString() }).eq('id', invitationId).then(() => {});
      });
  }, [invitationId]);

  const handleSubmit = async () => {
    if (!form.amount) { setError('Base bid amount is required.'); return; }
    setSubmitting(true); setError('');
    const supabase = getSupabaseClient();
    const { error: dbErr } = await supabase.from('bid_submissions').insert({
      bid_package_id: invitation?.bid_package_id,
      invitation_id: invitationId,
      amount: Number(form.amount.replace(/,/g, '')),
      labor_cost: form.labor ? Number(form.labor.replace(/,/g,'')) : null,
      material_cost: form.material ? Number(form.material.replace(/,/g,'')) : null,
      sub_cost: form.subcontract ? Number(form.subcontract.replace(/,/g,'')) : null,
      equipment_cost: form.equipment ? Number(form.equipment.replace(/,/g,'')) : null,
      overhead_pct: form.overhead ? Number(form.overhead) : null,
      profit_pct: form.profit ? Number(form.profit) : null,
      schedule_days: form.schedule_days ? Number(form.schedule_days) : null,
      exclusions: form.exclusions || null,
      qualifications: form.qualifications || null,
      valid_until: form.valid_until || null,
      submitted_at: new Date().toISOString(),
    });
    if (!dbErr) await supabase.from('bid_invitations').update({ status: 'submitted', submitted_at: new Date().toISOString() }).eq('id', invitationId);
    setSubmitting(false);
    if (dbErr) { setError(dbErr.message); return; }
    setSubmitted(true);
  };

  if (loading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>Loading…</div>;
  if (!invitation) return <div style={{ padding: 40, textAlign: 'center' }}>Invitation not found.</div>;

  const pkg = invitation.bid_packages ?? {};
  const proj = pkg.projects ?? {};

  if (submitted) return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#f8f8f7', gap: 12 }}>
      <div style={{ fontSize: 52 }}>✅</div>
      <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22 }}>Quote Submitted!</div>
      <div style={{ fontSize: 14, color: '#6b7280' }}>{pkg.title} — ${Number(form.amount.replace(/,/g,'')).toLocaleString()}</div>
      <a href="/trade/dashboard" style={{ marginTop: 12, padding: '12px 28px', background: '#1e4d8c', color: 'white', borderRadius: 10, fontWeight: 700, textDecoration: 'none' }}>← Back to Dashboard</a>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: '#1e2d3d', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', gap: 14, position: 'sticky', top: 0, zIndex: 40 }}>
        <a href="/trade/bid-invitations" style={{ color: 'rgba(255,255,255,0.6)', textDecoration: 'none', fontSize: 18 }}>←</a>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: 'white' }}>Submit Quote</div>
      </header>

      <main style={{ maxWidth: 720, margin: '0 auto', padding: '28px 24px' }}>
        {/* Project info */}
        <div style={{ background: 'white', borderRadius: 14, border: '1px solid #e5e7eb', padding: '18px 22px', marginBottom: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Bid Package</div>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 20, marginBottom: 4 }}>{pkg.title}</div>
          <div style={{ fontSize: 13, color: '#374151' }}>{proj.name} · {proj.site_city}, {proj.site_state}</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginTop: 16 }}>
            {[['Trade', pkg.trade ?? '—'], ['Due Date', pkg.due_date ?? '—'], ['Project #', proj.project_number ?? '—']].map(([k, v]) => (
              <div key={k}><div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', marginBottom: 2 }}>{k}</div><div style={{ fontSize: 13, fontWeight: 600 }}>{v}</div></div>
            ))}
          </div>
          {pkg.scope_of_work && (
            <div style={{ marginTop: 14, padding: '12px 14px', background: '#f9fafb', borderRadius: 8 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', marginBottom: 4 }}>SCOPE OF WORK</div>
              <div style={{ fontSize: 13, lineHeight: 1.6 }}>{pkg.scope_of_work}</div>
            </div>
          )}
        </div>

        {error && <div style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: '#991b1b', marginBottom: 16 }}>{error}</div>}

        {/* Bid form */}
        <div style={{ background: 'white', borderRadius: 14, border: '1px solid #e5e7eb', padding: '20px 22px', marginBottom: 14 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15, marginBottom: 16 }}>Base Bid</div>
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Total Bid Amount <span style={{ color: '#ef4444' }}>*</span></label>
            <div style={{ position: 'relative' }}>
              <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontWeight: 700, color: '#6b7280' }}>$</span>
              <input className="form-input" type="text" value={form.amount} onChange={e => set('amount', e.target.value)} placeholder="0.00" style={{ paddingLeft: 24, width: '100%', fontSize: 20, fontFamily: 'Syne, sans-serif', fontWeight: 700 }} />
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 10 }}>
            {[['labor','Labor'],['material','Material'],['subcontract','Subcontract'],['equipment','Equipment']].map(([k,l]) => (
              <div key={k}>
                <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>{l}</label>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af', fontSize: 13 }}>$</span>
                  <input className="form-input" type="text" value={(form as any)[k]} onChange={e => set(k, e.target.value)} placeholder="0" style={{ paddingLeft: 22, width: '100%' }} />
                </div>
              </div>
            ))}
            {[['overhead','Overhead %'],['profit','Profit %']].map(([k,l]) => (
              <div key={k}>
                <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>{l}</label>
                <input className="form-input" type="number" value={(form as any)[k]} onChange={e => set(k, e.target.value)} placeholder="0" style={{ width: '100%' }} />
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: 'white', borderRadius: 14, border: '1px solid #e5e7eb', padding: '20px 22px', marginBottom: 14 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15, marginBottom: 14 }}>Schedule & Qualifications</div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>Days to Complete (from NTP)</label>
            <input className="form-input" type="number" value={form.schedule_days} onChange={e => set('schedule_days', e.target.value)} placeholder="0" style={{ width: 160 }} />
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>Quote Valid Until</label>
            <input type="date" className="form-input" value={form.valid_until} onChange={e => set('valid_until', e.target.value)} style={{ width: 200 }} />
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>Exclusions</label>
            <textarea className="form-textarea" rows={3} value={form.exclusions} onChange={e => set('exclusions', e.target.value)} placeholder="List anything excluded from this bid…" style={{ width: '100%', resize: 'vertical' }} />
          </div>
          <div>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>Qualifications & Clarifications</label>
            <textarea className="form-textarea" rows={3} value={form.qualifications} onChange={e => set('qualifications', e.target.value)} placeholder="Any assumptions, qualifications, or clarifications…" style={{ width: '100%', resize: 'vertical' }} />
          </div>
        </div>

        <button onClick={handleSubmit} disabled={submitting} style={{ width: '100%', padding: '16px', background: submitting ? '#6b7280' : '#1e4d8c', color: 'white', border: 'none', borderRadius: 12, fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, cursor: submitting ? 'not-allowed' : 'pointer' }}>
          {submitting ? 'Submitting…' : '✓ Submit Quote'}
        </button>
      </main>
    </div>
  );
}
