import { createServerSupabase } from '../../../lib/serverAuth';
import { redirect } from 'next/navigation';

export default async function TradePayAppsPage() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=trade');

  const { data: invoices } = await supabase
    .from('invoices')
    .select('*, projects(name, project_number)')
    .eq('submitted_by_email', user.email)
    .order('created_at', { ascending: false });

  const totalApproved = (invoices ?? []).filter(i => i.status === 'approved' || i.status === 'paid').reduce((s, i) => s + Number(i.amount || 0), 0);
  const totalPaid = (invoices ?? []).filter(i => i.status === 'paid').reduce((s, i) => s + Number(i.net_due || i.amount || 0), 0);
  const retainageHeld = (invoices ?? []).reduce((s, i) => s + Number(i.retainage_held || 0), 0);

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: '#1e2d3d', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', gap: 14, position: 'sticky', top: 0, zIndex: 40 }}>
        <a href="/trade/dashboard" style={{ color: 'rgba(255,255,255,0.6)', textDecoration: 'none', fontSize: 18 }}>←</a>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: 'white' }}>Pay Applications</div>
      </header>
      <main style={{ maxWidth: 860, margin: '0 auto', padding: '28px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 24 }}>
          {[
            { label: 'Total Billed', value: `$${(invoices ?? []).reduce((s, i) => s + Number(i.amount || 0), 0).toLocaleString()}` },
            { label: 'Total Paid', value: `$${totalPaid.toLocaleString()}` },
            { label: 'Retainage Held', value: `$${retainageHeld.toLocaleString()}` },
          ].map(s => (
            <div key={s.label} style={{ background: 'white', borderRadius: 12, padding: '16px 18px', border: '1px solid #e5e7eb' }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22 }}>{s.value}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>Payment Applications</div>
          <button style={{ padding: '9px 18px', background: '#1e4d8c', color: 'white', border: 'none', borderRadius: 8, fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>+ Submit Pay App</button>
        </div>

        {(invoices ?? []).length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 60, textAlign: 'center', border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 36, marginBottom: 12 }}>▦</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 8 }}>No pay applications yet</div>
            <p style={{ fontSize: 13, color: '#6b7280' }}>Submit pay applications for work completed on your projects.</p>
          </div>
        ) : (
          <div style={{ background: 'white', borderRadius: 12, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
                  {['Invoice #','Project','Period','Amount','Retainage','Net Due','Status','Lien Waiver'].map(h => (
                    <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(invoices ?? []).map((inv: any) => (
                  <tr key={inv.id} style={{ borderBottom: '1px solid #f3f4f6' }}>
                    <td style={{ padding: '12px 16px', fontFamily: 'monospace', fontSize: 12, fontWeight: 600 }}>{inv.invoice_number}</td>
                    <td style={{ padding: '12px 16px', fontSize: 13 }}>{inv.projects?.name ?? '—'}</td>
                    <td style={{ padding: '12px 16px', fontSize: 12, color: '#6b7280' }}>{inv.period_start ? `${inv.period_start}–${inv.period_end ?? '?'}` : '—'}</td>
                    <td style={{ padding: '12px 16px', fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14 }}>${Number(inv.amount || 0).toLocaleString()}</td>
                    <td style={{ padding: '12px 16px', fontSize: 12, color: '#d97706' }}>${Number(inv.retainage_held || 0).toLocaleString()}</td>
                    <td style={{ padding: '12px 16px', fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>${Number(inv.net_due || inv.amount || 0).toLocaleString()}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ background: inv.status === 'paid' ? '#dcfce7' : inv.status === 'approved' ? '#dbeafe' : inv.status === 'pending' ? '#fef3c7' : '#f3f4f6', color: inv.status === 'paid' ? '#16a34a' : inv.status === 'approved' ? '#1e4d8c' : inv.status === 'pending' ? '#d97706' : '#6b7280', padding: '2px 8px', borderRadius: 5, fontSize: 11, fontWeight: 600, textTransform: 'capitalize' }}>
                        {inv.status}
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      {inv.lien_waiver_required ? (
                        inv.lien_waiver_received
                          ? <span style={{ fontSize: 11, color: '#16a34a', fontWeight: 600 }}>✓ Submitted</span>
                          : <button style={{ padding: '4px 10px', background: '#fef3c7', border: '1px solid #fcd34d', borderRadius: 5, fontSize: 11, fontWeight: 600, color: '#d97706', cursor: 'pointer' }}>↑ Upload</button>
                      ) : <span style={{ fontSize: 11, color: '#9ca3af' }}>N/A</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}
