import { createServerSupabase } from '../../../lib/serverAuth';
import { redirect } from 'next/navigation';

export default async function TradeDashboardPage() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=trade');

  const { data: profile } = await supabase.from('users').select('*,tenants(name)').eq('auth_user_id', user.id).single();

  // Get bid invitations for this user/company
  const { data: invitations } = await supabase
    .from('bid_invitations')
    .select('*, bid_packages(title, due_date, trade, project_id, projects(name, project_number))')
    .eq('contact_email', user.email)
    .order('created_at', { ascending: false });

  // Get compliance status for this vendor
  const { data: compliance } = await supabase
    .from('vendor_compliance')
    .select('*')
    .eq('contact_email', user.email)
    .single();

  const openInvites = (invitations ?? []).filter(i => i.status === 'invited' || i.status === 'viewed');
  const submittedBids = (invitations ?? []).filter(i => i.status === 'submitted');

  const coiExpired = compliance?.coi_expiration && new Date(compliance.coi_expiration) < new Date();
  const w9Missing = !compliance?.w9_received;
  const complianceOk = !coiExpired && !w9Missing && compliance?.coi_received;

  const NAV = [
    { label: 'Dashboard', href: '/trade/dashboard', icon: '⬡' },
    { label: 'Bid Invitations', href: '/trade/bid-invitations', icon: '◳', badge: openInvites.length },
    { label: 'Pay Applications', href: '/trade/pay-apps', icon: '▦' },
    { label: 'Compliance Docs', href: '/trade/compliance', icon: '◑', alert: !complianceOk },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: '#1e2d3d', padding: '0 32px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 40 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 18, color: 'white' }}>
            {(profile as any)?.tenants?.name ?? 'Saguaro'}
          </div>
          <span style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.4)', background: 'rgba(255,255,255,0.08)', padding: '3px 8px', borderRadius: 6, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Subcontractor Portal</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)' }}>{user.email}</div>
          <a href="/logout" style={{ padding: '7px 14px', background: 'rgba(255,255,255,0.1)', borderRadius: 7, fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.8)', textDecoration: 'none' }}>Sign Out</a>
        </div>
      </header>

      {/* Sub-nav */}
      <div style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', display: 'flex', gap: 0, overflowX: 'auto' }}>
        {NAV.map(n => (
          <a key={n.label} href={n.href} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '13px 16px', fontSize: 13, fontWeight: 600, color: n.href === '/trade/dashboard' ? '#1e4d8c' : '#6b7280', textDecoration: 'none', borderBottom: n.href === '/trade/dashboard' ? '2px solid #1e4d8c' : '2px solid transparent', whiteSpace: 'nowrap' }}>
            {n.icon} {n.label}
            {n.badge ? <span style={{ background: '#dc2626', color: 'white', borderRadius: 10, padding: '1px 6px', fontSize: 10, fontWeight: 700 }}>{n.badge}</span> : null}
            {n.alert && <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#f59e0b', display: 'inline-block' }} />}
          </a>
        ))}
      </div>

      <main style={{ maxWidth: 960, margin: '0 auto', padding: '28px 24px' }}>
        <h1 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '1.4rem', marginBottom: 6 }}>
          Welcome back, {user.email?.split('@')[0]}
        </h1>

        {/* Compliance Alert */}
        {!complianceOk && (
          <div style={{ background: '#fef3c7', border: '1px solid #fcd34d', borderRadius: 10, padding: '14px 18px', marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <strong style={{ fontSize: 14 }}>⚠ Compliance documents need attention</strong>
              <div style={{ fontSize: 12, color: '#92400e', marginTop: 2 }}>
                {coiExpired && 'COI is expired. '}
                {w9Missing && 'W-9 not on file. '}
                Payment may be held until resolved.
              </div>
            </div>
            <a href="/trade/compliance" style={{ padding: '8px 16px', background: '#d97706', color: 'white', borderRadius: 8, fontSize: 12, fontWeight: 700, textDecoration: 'none' }}>Update Docs</a>
          </div>
        )}

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 24 }}>
          {[
            { label: 'Open Invitations', value: openInvites.length, color: openInvites.length > 0 ? '#1e4d8c' : '#374151' },
            { label: 'Bids Submitted', value: submittedBids.length, color: '#16a34a' },
            { label: 'COI Status', value: coiExpired ? 'Expired ⚠' : complianceOk ? 'Valid ✓' : 'Missing', color: coiExpired ? '#dc2626' : complianceOk ? '#16a34a' : '#d97706' },
            { label: 'W-9 on File', value: w9Missing ? 'Missing' : 'On File ✓', color: w9Missing ? '#d97706' : '#16a34a' },
          ].map(s => (
            <div key={s.label} style={{ background: 'white', borderRadius: 12, padding: '16px 18px', border: '1px solid #e5e7eb' }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 20, color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Open Invitations */}
        {openInvites.length > 0 && (
          <div style={{ background: 'white', borderRadius: 14, border: '1px solid #e5e7eb', marginBottom: 16, overflow: 'hidden' }}>
            <div style={{ padding: '16px 20px', borderBottom: '1px solid #f3f4f6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>Open Bid Invitations</div>
              <a href="/trade/bid-invitations" style={{ fontSize: 12, color: '#1e4d8c', fontWeight: 600, textDecoration: 'none' }}>View all →</a>
            </div>
            {openInvites.map((inv: any) => (
              <div key={inv.id} style={{ padding: '14px 20px', borderBottom: '1px solid #f9fafb', display: 'flex', alignItems: 'center', gap: 16 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{inv.bid_packages?.title ?? '—'}</div>
                  <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>{inv.bid_packages?.projects?.name} · {inv.bid_packages?.trade}</div>
                </div>
                <div style={{ textAlign: 'right', marginRight: 12 }}>
                  <div style={{ fontSize: 11, color: '#6b7280' }}>Due</div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{inv.bid_packages?.due_date ?? '—'}</div>
                </div>
                <a href={`/trade/bid-invitations/${inv.id}`} style={{ padding: '8px 16px', background: '#1e4d8c', color: 'white', borderRadius: 8, fontSize: 12, fontWeight: 700, textDecoration: 'none' }}>Submit Quote</a>
              </div>
            ))}
          </div>
        )}

        {openInvites.length === 0 && (
          <div style={{ background: 'white', borderRadius: 14, padding: 48, textAlign: 'center', border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 36, marginBottom: 12 }}>◳</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15, marginBottom: 8 }}>No open bid invitations</div>
            <p style={{ fontSize: 13, color: '#6b7280' }}>You'll be notified by email when you're invited to bid on a project.</p>
          </div>
        )}
      </main>
    </div>
  );
}
