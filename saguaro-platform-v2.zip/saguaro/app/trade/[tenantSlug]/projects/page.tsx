import { createServerSupabase } from '../../../../lib/serverAuth';
import { redirect } from 'next/navigation';

interface Props { params: { tenantSlug: string } }

export default async function TradeProjectsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/trade/${params.tenantSlug}/login`);

  const { data: profile } = await supabase.from('users').select('*').eq('id', user.id).single();
  if (profile?.portal_type !== 'trade') redirect(`/trade/${params.tenantSlug}/login`);

  const { data: memberships } = await supabase.from('project_members').select('project_id').eq('user_id', user.id);
  const projectIds = (memberships ?? []).map(m => m.project_id);
  const { data: projects } = projectIds.length > 0
    ? await supabase.from('projects').select('*').in('id', projectIds)
    : { data: [] };

  return (
    <div style={{ minHeight: '100vh', background: '#f8f7f5' }}>
      <header style={{ background: '#7c2d12', color: 'white', padding: '0 24px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.2rem' }}>⬡ Trade Portal</div>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <span style={{ fontSize: 13, opacity: 0.8 }}>{user.email}</span>
          <a href="/logout" style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>Sign out</a>
        </div>
      </header>

      <main style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px' }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.5rem', marginBottom: 24, color: '#7c2d12' }}>My Assigned Projects</h1>
        {(projects ?? []).length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 48, textAlign: 'center', color: '#6b7280' }}>
            <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 8 }}>No projects assigned</div>
            <p style={{ fontSize: 13 }}>Contact the general contractor to get project access.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
            {(projects ?? []).map(proj => (
              <a key={proj.id} href={`/trade/${params.tenantSlug}/projects/${proj.id}`} style={{ textDecoration: 'none' }}>
                <div style={{ background: 'white', borderRadius: 14, padding: 24, border: '1px solid #e5e7eb', cursor: 'pointer' }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', marginBottom: 4 }}>{proj.project_number}</div>
                  <div style={{ fontWeight: 700, fontSize: 16, color: '#7c2d12', marginBottom: 6 }}>{proj.name}</div>
                  <div style={{ fontSize: 13, color: '#6b7280' }}>{proj.address ?? '—'}</div>
                  <div style={{ marginTop: 12 }}>
                    <span style={{ background: '#fef3c7', color: '#92400e', fontSize: 12, fontWeight: 600, padding: '2px 8px', borderRadius: 4 }}>View work →</span>
                  </div>
                </div>
              </a>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
