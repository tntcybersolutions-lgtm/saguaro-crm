import { createServerSupabase } from '../../../../../lib/serverAuth';
import { redirect, notFound } from 'next/navigation';

interface Props { params: { tenantSlug: string; projectId: string } }

export default async function TradeProjectPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/trade/${params.tenantSlug}/login`);

  const { data: profile } = await supabase.from('users').select('*').eq('id', user.id).single();
  if (profile?.portal_type !== 'trade') redirect(`/trade/${params.tenantSlug}/login`);

  const { data: membership } = await supabase.from('project_members').select('*').eq('user_id', user.id).eq('project_id', params.projectId).single();
  if (!membership) notFound();

  const { data: project } = await supabase.from('projects').select('*').eq('id', params.projectId).single();
  if (!project) notFound();

  // Trade-visible data
  const [scheduleRes, docsRes, submittalsRes, rfisRes] = await Promise.all([
    supabase.from('schedule_tasks').select('*').eq('project_id', params.projectId).not('status', 'eq', 'complete').order('planned_start').limit(10),
    supabase.from('documents').select('*').eq('project_id', params.projectId).in('visibility', ['trade','customer']).eq('is_current_version', true).order('created_at', { ascending: false }).limit(10),
    supabase.from('submittals').select('*').eq('project_id', params.projectId).not('status', 'in', '("approved","rejected")').order('number').limit(8),
    supabase.from('rfis').select('*').eq('project_id', params.projectId).not('status', 'eq', 'closed').order('number', { ascending: false }).limit(8),
  ]);

  return (
    <div style={{ minHeight: '100vh', background: '#f8f7f5' }}>
      <header style={{ background: '#7c2d12', color: 'white', padding: '0 24px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <a href={`/trade/${params.tenantSlug}/projects`} style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13 }}>← Projects</a>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.1rem' }}>{project.name}</div>
        </div>
        <a href="/logout" style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>Sign out</a>
      </header>

      <main style={{ maxWidth: 960, margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
          {/* Schedule */}
          <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#7c2d12' }}>◷ Active Schedule Tasks</div>
            {(scheduleRes.data ?? []).length === 0 ? <p style={{ fontSize: 13, color: '#9ca3af' }}>No active tasks.</p> : (scheduleRes.data ?? []).map(t => (
              <div key={t.id} style={{ padding: '8px 0', borderBottom: '1px solid #f3f4f6' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{t.name}</div>
                    <div style={{ fontSize: 11, color: '#9ca3af' }}>{t.planned_start} → {t.planned_finish ?? '—'}</div>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#2563b0' }}>{t.percent_complete ?? 0}%</div>
                </div>
              </div>
            ))}
          </div>

          {/* Submittals */}
          <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#7c2d12' }}>◨ Open Submittals</div>
            {(submittalsRes.data ?? []).length === 0 ? <p style={{ fontSize: 13, color: '#9ca3af' }}>No open submittals.</p> : (submittalsRes.data ?? []).map(s => (
              <div key={s.id} style={{ padding: '8px 0', borderBottom: '1px solid #f3f4f6', display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{s.number}: {s.title}</div>
                  <div style={{ fontSize: 11, color: '#9ca3af' }}>{s.spec_section ?? '—'}</div>
                </div>
                <span style={{ background: '#fef3c7', color: '#ca8a04', fontSize: 11, fontWeight: 600, padding: '2px 6px', borderRadius: 4, whiteSpace: 'nowrap', height: 'fit-content' }}>{s.status?.replace(/_/g,' ')}</span>
              </div>
            ))}
          </div>

          {/* Open RFIs */}
          <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#7c2d12' }}>? Open RFIs</div>
            {(rfisRes.data ?? []).length === 0 ? <p style={{ fontSize: 13, color: '#9ca3af' }}>No open RFIs.</p> : (rfisRes.data ?? []).map(r => (
              <div key={r.id} style={{ padding: '8px 0', borderBottom: '1px solid #f3f4f6' }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>RFI-{String(r.number).padStart(3,'0')}: {r.subject}</div>
                <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>{r.status?.replace(/_/g,' ')} · Due {r.response_due_date ?? r.due_date ?? '—'}</div>
              </div>
            ))}
          </div>

          {/* Documents */}
          <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#7c2d12' }}>📄 Current Drawings & Docs</div>
            {(docsRes.data ?? []).length === 0 ? <p style={{ fontSize: 13, color: '#9ca3af' }}>No documents shared.</p> : (docsRes.data ?? []).map(doc => (
              <div key={doc.id} style={{ padding: '8px 0', borderBottom: '1px solid #f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 13 }}>{doc.sheet_title ?? doc.file_name}</div>
                  {doc.sheet_number && <div style={{ fontSize: 11, color: '#9ca3af' }}>{doc.sheet_number} · Rev {doc.revision ?? 0}</div>}
                </div>
                <button style={{ background: 'none', border: 'none', color: '#7c2d12', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>↓</button>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
