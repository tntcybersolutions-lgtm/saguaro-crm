'use client';
import { useState, useEffect, useRef } from 'react';
import { getSupabaseClient } from '../../../lib/supabaseClient';

export default function TradeCompliancePage() {
  const [compliance, setCompliance] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState<Record<string, boolean>>({});
  const [success, setSuccess] = useState('');
  const coiRef = useRef<HTMLInputElement>(null);
  const w9Ref = useRef<HTMLInputElement>(null);
  const taxRef = useRef<HTMLInputElement>(null);

  const supabase = getSupabaseClient();

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) return;
      supabase.from('vendor_compliance').select('*').eq('contact_email', user.email).single()
        .then(({ data }) => { setCompliance(data); setLoading(false); });
    });
  }, []);

  const uploadDoc = async (type: 'coi' | 'w9' | 'tax_cert', files: FileList | null) => {
    if (!files || !files[0]) return;
    setUploading(p => ({ ...p, [type]: true }));
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const ext = files[0].name.split('.').pop();
    const path = `compliance/${user.id}/${type}-${Date.now()}.${ext}`;
    await supabase.storage.from('compliance').upload(path, files[0], { upsert: true });
    const { data: urlData } = supabase.storage.from('compliance').getPublicUrl(path);
    const update: Record<string, any> = {};
    if (type === 'coi') { update.coi_received = true; update.coi_document_url = urlData?.publicUrl; }
    if (type === 'w9') { update.w9_received = true; update.w9_document_url = urlData?.publicUrl; }
    if (type === 'tax_cert') { update.tax_cert_received = true; update.tax_cert_url = urlData?.publicUrl; }
    update.contact_email = user.email;
    await supabase.from('vendor_compliance').upsert(update, { onConflict: 'contact_email' });
    const { data } = await supabase.from('vendor_compliance').select('*').eq('contact_email', user.email).single();
    setCompliance(data);
    setSuccess(`${type.toUpperCase()} uploaded successfully.`);
    setUploading(p => ({ ...p, [type]: false }));
    setTimeout(() => setSuccess(''), 4000);
  };

  if (loading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>Loading…</div>;

  const docs = [
    { key: 'coi', label: 'Certificate of Insurance (COI)', desc: 'General liability and workers comp. Must name GC as additional insured.', received: compliance?.coi_received, expiry: compliance?.coi_expiration, ref: coiRef, accept: '.pdf,.jpg,.png' },
    { key: 'w9', label: 'W-9 / Tax ID', desc: 'Required for payment processing. Must match company legal name.', received: compliance?.w9_received, expiry: null, ref: w9Ref, accept: '.pdf' },
    { key: 'tax_cert', label: 'Tax Exemption Certificate', desc: 'If applicable to your company type.', received: compliance?.tax_cert_received, expiry: null, ref: taxRef, accept: '.pdf' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: '#1e2d3d', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', gap: 14, position: 'sticky', top: 0, zIndex: 40 }}>
        <a href="/trade/dashboard" style={{ color: 'rgba(255,255,255,0.6)', textDecoration: 'none', fontSize: 18 }}>←</a>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: 'white' }}>Compliance Documents</div>
      </header>
      <main style={{ maxWidth: 700, margin: '0 auto', padding: '28px 24px' }}>
        <p style={{ fontSize: 14, color: '#6b7280', marginBottom: 24 }}>Keep your compliance documents current to avoid payment holds. Expired or missing documents will trigger Autopilot alerts on your projects.</p>

        {success && <div style={{ background: '#dcfce7', border: '1px solid #86efac', borderRadius: 10, padding: '12px 16px', fontSize: 13, color: '#15803d', marginBottom: 16, fontWeight: 600 }}>{success}</div>}

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {docs.map(doc => {
            const isExpired = doc.expiry && new Date(doc.expiry) < new Date();
            const expiringSoon = doc.expiry && !isExpired && new Date(doc.expiry) < new Date(Date.now() + 30*86400000);
            return (
              <div key={doc.key} style={{ background: 'white', borderRadius: 14, border: `1px solid ${!doc.received ? '#fcd34d' : isExpired ? '#fca5a5' : '#e5e7eb'}`, padding: '20px 22px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                  <div>
                    <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{doc.label}</div>
                    <p style={{ fontSize: 12, color: '#6b7280', margin: 0 }}>{doc.desc}</p>
                  </div>
                  <div style={{ marginLeft: 16, flexShrink: 0 }}>
                    {!doc.received && <span style={{ background: '#fef3c7', color: '#d97706', padding: '3px 10px', borderRadius: 6, fontSize: 12, fontWeight: 700 }}>Missing</span>}
                    {doc.received && !isExpired && !expiringSoon && <span style={{ background: '#dcfce7', color: '#16a34a', padding: '3px 10px', borderRadius: 6, fontSize: 12, fontWeight: 700 }}>✓ On File</span>}
                    {doc.received && expiringSoon && <span style={{ background: '#fef3c7', color: '#d97706', padding: '3px 10px', borderRadius: 6, fontSize: 12, fontWeight: 700 }}>Expiring Soon</span>}
                    {doc.received && isExpired && <span style={{ background: '#fee2e2', color: '#dc2626', padding: '3px 10px', borderRadius: 6, fontSize: 12, fontWeight: 700 }}>Expired</span>}
                  </div>
                </div>
                {doc.expiry && (
                  <div style={{ fontSize: 12, color: isExpired ? '#dc2626' : '#6b7280', marginBottom: 12 }}>
                    Expiration: <strong>{doc.expiry}</strong>
                  </div>
                )}
                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    onClick={() => doc.ref.current?.click()}
                    disabled={uploading[doc.key]}
                    style={{ padding: '9px 18px', background: doc.received ? '#f3f4f6' : '#1e4d8c', color: doc.received ? '#374151' : 'white', border: doc.received ? '1px solid #e5e7eb' : 'none', borderRadius: 8, fontSize: 13, fontWeight: 700, cursor: uploading[doc.key] ? 'not-allowed' : 'pointer' }}
                  >
                    {uploading[doc.key] ? 'Uploading…' : doc.received ? '↑ Replace' : '↑ Upload'}
                  </button>
                  <input ref={doc.ref} type="file" accept={doc.accept} style={{ display: 'none' }} onChange={e => uploadDoc(doc.key as any, e.target.files)} />
                  {doc.key === 'coi' && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <label style={{ fontSize: 11, color: '#6b7280', fontWeight: 600 }}>Exp Date</label>
                      <input type="date" className="form-input" style={{ height: 36, width: 150, fontSize: 12 }} defaultValue={compliance?.coi_expiration ?? ''} onBlur={async e => {
                        const { data: { user } } = await supabase.auth.getUser();
                        if (user) await supabase.from('vendor_compliance').upsert({ contact_email: user.email, coi_expiration: e.target.value }, { onConflict: 'contact_email' });
                      }} />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
