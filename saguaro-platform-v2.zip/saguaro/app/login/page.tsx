'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { getSupabaseClient } from '../../lib/supabaseClient';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();
  const searchParams = useSearchParams();

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    const supabase = getSupabaseClient();
    const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password });

    if (authError) {
      setError(authError.message);
      setLoading(false);
      return;
    }

    if (data.session) {
      const { data: user } = await supabase
        .from('users')
        .select('portal, is_master, tenant_id')
        .eq('id', data.session.user.id)
        .single();

      const redirect = searchParams.get('redirect');
      if (redirect) { router.push(redirect); return; }

      if (user?.is_master || user?.portal === 'internal') {
        router.push('/app');
      } else if (user?.portal === 'customer') {
        router.push('/client');
      } else if (user?.portal === 'trade') {
        router.push('/trade');
      } else {
        router.push('/app');
      }
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-sidebar)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ width: '100%', maxWidth: 400 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ width: 52, height: 52, background: 'linear-gradient(135deg, var(--color-clay-700), var(--color-blue-700))', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', fontSize: 24, fontWeight: 800, color: 'white', fontFamily: 'var(--font-display)' }}>S</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 800, color: 'white', letterSpacing: '0.05em' }}>SAGUARO</div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 4, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Construction Intelligence Platform</div>
        </div>

        <div className="card" style={{ padding: 32 }}>
          <h2 style={{ marginBottom: 24, textAlign: 'center' }}>Sign In</h2>
          
          {error && <div className="alert alert-danger" style={{ marginBottom: 16 }}>{error}</div>}
          
          {searchParams.get('error') === 'unauthorized' && (
            <div className="alert alert-warning" style={{ marginBottom: 16 }}>You do not have access to that portal.</div>
          )}

          <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input
                type="email"
                className="form-input"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@company.com"
                required
                autoFocus
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                type="password"
                className="form-input"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
            <button type="submit" className="btn btn-primary" style={{ marginTop: 8, justifyContent: 'center', padding: '10px 0' }} disabled={loading}>
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>

          <div style={{ marginTop: 20, textAlign: 'center', fontSize: 12, color: 'var(--text-muted)' }}>
            <a href="/request-access">Request Portal Access</a>
          </div>
        </div>
      </div>
    </div>
  );
}
