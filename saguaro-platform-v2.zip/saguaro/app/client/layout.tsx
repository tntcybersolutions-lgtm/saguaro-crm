import type { ReactNode } from 'react';
import '../globals.css';

export default function ClientLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: 'var(--font-sans)', background: '#f8f8f7' }}>
        {children}
      </body>
    </html>
  );
}
