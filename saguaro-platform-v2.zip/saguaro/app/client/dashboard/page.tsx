import { createServerSupabase } from '../../../lib/serverAuth';
import { redirect } from 'next/navigation';

export default async function ClientDashboardPage() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=client');

  const { data: profile } = await supabase.from('users').select('*,tenants(name,logo_url)').eq('auth_user_id', user.id).single();
  const { data: projectMembers } = await supabase
    .from('project_members')
    .select('project_id, role, projects(id,name,status,project_number,site_city,site_state,contract_value,completion_pct)')
    .eq('user_id', profile?.id);

  const projects = (projectMembers ?? []).map((pm: any) => pm.projects).filter(Boolean);

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      {/* Top Nav */}
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 40 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 18, color: '#1e4d8c' }}>
            {(profile as any)?.tenants?.name ?? 'Saguaro'}
          </div>
          <span style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', background: '#f3f4f6', padding: '3px 8px', borderRadius: 6, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Client Portal</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ fontSize: 13, color: '#374151', fontWeight: 500 }}>{user.email}</div>
          <a href="/logout" style={{ padding: '7px 14px', background: '#f3f4f6', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#374151', textDecoration: 'none' }}>Sign Out</a>
        </div>
      </header>

      <main style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px' }}>
        <h1 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '1.5rem', marginBottom: 6 }}>
          Welcome back, {user.email?.split('@')[0]}
        </h1>
        <p style={{ fontSize: 14, color: '#6b7280', marginBottom: 28 }}>Your active projects at a glance.</p>

        {projects.length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 60, textAlign: 'center', border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>⬡</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 8 }}>No projects yet</div>
            <p style={{ fontSize: 13, color: '#6b7280' }}>Your project team will add you once your project is set up.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 14 }}>
            {projects.map((proj: any) => (
              <a key={proj.id} href={`/client/projects/${proj.id}`} style={{ textDecoration: 'none', display: 'block', background: 'white', borderRadius: 14, border: '1px solid #e5e7eb', overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.05)', transition: 'box-shadow 0.2s' }}>
                <div style={{ background: '#1e4d8c', padding: '16px 20px' }}>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', fontWeight: 600, marginBottom: 3 }}>{proj.project_number}</div>
                  <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, color: 'white' }}>{proj.name}</div>
                  {proj.site_city && <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', marginTop: 4 }}>📍 {proj.site_city}, {proj.site_state}</div>}
                </div>
                <div style={{ padding: '14px 20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div>
                      <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', marginBottom: 2 }}>Contract Value</div>
                      <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>
                        {proj.contract_value ? `$${Number(proj.contract_value).toLocaleString()}` : '—'}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', marginBottom: 2 }}>Progress</div>
                      <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>{proj.completion_pct ?? 0}%</div>
                    </div>
                  </div>
                  <div style={{ height: 6, background: '#f3f4f6', borderRadius: 3, marginBottom: 10 }}>
                    <div style={{ width: `${proj.completion_pct ?? 0}%`, height: '100%', background: '#1e4d8c', borderRadius: 3 }} />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ background: proj.status === 'active' ? '#dcfce7' : '#f3f4f6', color: proj.status === 'active' ? '#16a34a' : '#6b7280', padding: '2px 8px', borderRadius: 5, fontSize: 11, fontWeight: 600, textTransform: 'capitalize' }}>{proj.status}</span>
                    <span style={{ fontSize: 12, color: '#1e4d8c', fontWeight: 600 }}>View Project →</span>
                  </div>
                </div>
              </a>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
