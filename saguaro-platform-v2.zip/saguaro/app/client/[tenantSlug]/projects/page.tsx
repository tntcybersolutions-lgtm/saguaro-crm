import { createServerSupabase } from '../../../../lib/serverAuth';
import { redirect } from 'next/navigation';

interface Props { params: { tenantSlug: string } }

export default async function ClientProjectsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/client/${params.tenantSlug}/login`);

  const { data: profile } = await supabase.from('users').select('*').eq('id', user.id).single();
  if (profile?.portal_type !== 'customer') redirect(`/client/${params.tenantSlug}/login`);

  const { data: memberships } = await supabase.from('project_members').select('project_id').eq('user_id', user.id);
  const projectIds = (memberships ?? []).map(m => m.project_id);

  const { data: projects } = projectIds.length > 0
    ? await supabase.from('projects').select('*').in('id', projectIds).order('created_at')
    : { data: [] };

  return (
    <div style={{ minHeight: '100vh', background: '#f8f7f5' }}>
      {/* Client Portal Header */}
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 24px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.2rem', color: '#1e3a5f', letterSpacing: '-0.02em' }}>⬡ Saguaro Client Portal</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ fontSize: 13, color: '#6b7280' }}>{user.email}</span>
          <a href="/logout" style={{ fontSize: 13, color: '#dc2626' }}>Sign out</a>
        </div>
      </header>

      <main style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px' }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.6rem', marginBottom: 24, color: '#1e3a5f' }}>Your Projects</h1>

        {(projects ?? []).length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 48, textAlign: 'center', color: '#6b7280' }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>⬡</div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>No projects assigned yet</div>
            <p style={{ fontSize: 13, marginTop: 6 }}>Contact your project manager if you should have access to a project.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
            {(projects ?? []).map(proj => (
              <a key={proj.id} href={`/client/${params.tenantSlug}/projects/${proj.id}`} style={{ textDecoration: 'none' }}>
                <div style={{ background: 'white', borderRadius: 14, padding: 24, border: '1px solid #e5e7eb', transition: 'box-shadow 0.15s', cursor: 'pointer' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 11, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>{proj.project_number}</div>
                  <div style={{ fontWeight: 700, fontSize: 16, color: '#1e3a5f', marginBottom: 8 }}>{proj.name}</div>
                  <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 16 }}>{proj.address ?? 'Address not set'}</div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ background: proj.status === 'active' ? '#dcfce7' : '#f3f4f6', color: proj.status === 'active' ? '#16a34a' : '#6b7280', fontSize: 12, fontWeight: 600, padding: '3px 10px', borderRadius: 20, textTransform: 'capitalize' }}>{proj.status}</span>
                    <span style={{ fontSize: 12, color: '#9ca3af' }}>View →</span>
                  </div>
                </div>
              </a>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
