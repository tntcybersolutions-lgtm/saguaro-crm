import { createServerSupabase } from '../../../../../lib/serverAuth';
import { redirect, notFound } from 'next/navigation';

interface Props { params: { tenantSlug: string; projectId: string } }

export default async function ClientProjectPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/client/${params.tenantSlug}/login`);

  const { data: profile } = await supabase.from('users').select('*').eq('id', user.id).single();
  if (profile?.portal_type !== 'customer') redirect(`/client/${params.tenantSlug}/login`);

  // Verify access
  const { data: membership } = await supabase.from('project_members').select('*').eq('user_id', user.id).eq('project_id', params.projectId).single();
  if (!membership) notFound();

  const { data: project } = await supabase.from('projects').select('*').eq('id', params.projectId).single();
  if (!project) notFound();

  // Customer-visible data only
  const [invoicesRes, rfisRes, cosRes, photosRes, docsRes] = await Promise.all([
    supabase.from('invoices').select('*').eq('project_id', params.projectId).in('visibility', ['customer', 'all']).order('created_at', { ascending: false }).limit(5),
    supabase.from('rfis').select('*').eq('project_id', params.projectId).eq('visibility', 'customer').order('created_at', { ascending: false }).limit(5),
    supabase.from('change_orders').select('*').eq('project_id', params.projectId).in('status', ['approved', 'pending_client']).order('number'),
    supabase.from('photos').select('*').eq('project_id', params.projectId).in('visibility', ['customer', 'public']).order('taken_at', { ascending: false }).limit(8),
    supabase.from('documents').select('*').eq('project_id', params.projectId).in('visibility', ['customer', 'trade']).eq('is_current_version', true).order('created_at', { ascending: false }).limit(10),
  ]);

  return (
    <div style={{ minHeight: '100vh', background: '#f8f7f5' }}>
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 24px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <a href={`/client/${params.tenantSlug}/projects`} style={{ fontSize: 13, color: '#6b7280' }}>← My Projects</a>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.1rem', color: '#1e3a5f' }}>{project.name}</div>
        </div>
        <a href="/logout" style={{ fontSize: 13, color: '#dc2626' }}>Sign out</a>
      </header>

      <main style={{ maxWidth: 960, margin: '0 auto', padding: '32px 24px' }}>
        {/* Project Overview */}
        <div style={{ background: 'white', borderRadius: 14, padding: 28, marginBottom: 24, borderLeft: '4px solid #1e3a5f' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.4rem', color: '#1e3a5f', marginBottom: 6 }}>{project.name}</div>
          <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 16 }}>{project.project_number} · {project.address ?? 'Address not set'}</div>
          <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap' }}>
            {[
              ['Status', project.status],
              ['Type', project.contract_type ?? '—'],
              ['Planned Start', project.planned_start ?? '—'],
              ['Planned Completion', project.planned_completion ?? '—'],
            ].map(([k, v]) => (
              <div key={k}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>{k}</div>
                <div style={{ fontSize: 14, fontWeight: 600, textTransform: 'capitalize' }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
          {/* Recent Invoices */}
          <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#1e3a5f' }}>💰 Recent Invoices</div>
            {(invoicesRes.data ?? []).length === 0 ? <p style={{ fontSize: 13, color: '#9ca3af' }}>No invoices yet.</p> : (invoicesRes.data ?? []).map(inv => (
              <div key={inv.id} style={{ padding: '10px 0', borderBottom: '1px solid #f3f4f6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{inv.invoice_number}</div>
                  <div style={{ fontSize: 11, color: '#9ca3af' }}>{inv.invoice_date}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>${Number(inv.amount).toLocaleString()}</div>
                  <span style={{ background: inv.status === 'paid' ? '#dcfce7' : '#fef3c7', color: inv.status === 'paid' ? '#16a34a' : '#ca8a04', fontSize: 11, fontWeight: 600, padding: '1px 6px', borderRadius: 4 }}>{inv.status}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Change Orders */}
          <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#1e3a5f' }}>📋 Change Orders</div>
            {(cosRes.data ?? []).length === 0 ? <p style={{ fontSize: 13, color: '#9ca3af' }}>No change orders.</p> : (cosRes.data ?? []).map(co => (
              <div key={co.id} style={{ padding: '10px 0', borderBottom: '1px solid #f3f4f6', display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>CO-{String(co.number).padStart(3,'0')}: {co.title}</div>
                  <span style={{ background: co.status === 'approved' ? '#dcfce7' : '#fef3c7', color: co.status === 'approved' ? '#16a34a' : '#ca8a04', fontSize: 11, fontWeight: 600, padding: '1px 6px', borderRadius: 4 }}>{co.status?.replace(/_/g,' ')}</span>
                </div>
                <div style={{ fontWeight: 700, color: Number(co.amount) >= 0 ? '#16a34a' : '#dc2626' }}>
                  {Number(co.amount) >= 0 ? '+' : ''}${Number(co.amount||0).toLocaleString()}
                </div>
              </div>
            ))}
          </div>

          {/* Documents */}
          <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#1e3a5f' }}>📄 Documents</div>
            {(docsRes.data ?? []).length === 0 ? <p style={{ fontSize: 13, color: '#9ca3af' }}>No documents shared.</p> : (docsRes.data ?? []).map(doc => (
              <div key={doc.id} style={{ padding: '8px 0', borderBottom: '1px solid #f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ fontSize: 13 }}>{doc.sheet_title ?? doc.file_name}</div>
                <button style={{ background: 'none', border: 'none', color: '#2563b0', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>↓</button>
              </div>
            ))}
          </div>

          {/* Photos */}
          {(photosRes.data ?? []).length > 0 && (
            <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#1e3a5f' }}>📷 Progress Photos</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
                {(photosRes.data ?? []).slice(0,8).map(p => (
                  <div key={p.id} style={{ aspectRatio: '1', background: '#f3f4f6', borderRadius: 8, overflow: 'hidden' }}>
                    {p.signed_url && <img src={p.signed_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
