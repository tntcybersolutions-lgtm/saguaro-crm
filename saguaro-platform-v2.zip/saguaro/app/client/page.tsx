import { createServerSupabase } from '../../lib/serverAuth';
import { redirect } from 'next/navigation';

export default async function ClientPortalRoot() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=client');
  redirect('/client/dashboard');
}
