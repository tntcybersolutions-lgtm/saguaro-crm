import { createServerSupabase } from '../../../../../lib/serverAuth';
import { redirect, notFound } from 'next/navigation';

interface Props { params: { projectId: string } }

export default async function ClientInvoicesPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=client');

  const { data: project } = await supabase.from('projects').select('id,name,project_number').eq('id', params.projectId).single();
  if (!project) notFound();

  const { data: invoices } = await supabase.from('invoices').select('*').eq('project_id', params.projectId).eq('type', 'owner').order('created_at', { ascending: false });

  const totalBilled = (invoices ?? []).reduce((s, i) => s + Number(i.amount || 0), 0);
  const totalPaid = (invoices ?? []).filter(i => i.status === 'paid').reduce((s, i) => s + Number(i.net_due || i.amount || 0), 0);

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', gap: 12, position: 'sticky', top: 0, zIndex: 40 }}>
        <a href={`/client/projects/${params.projectId}`} style={{ fontSize: 12, color: '#6b7280', textDecoration: 'none', fontWeight: 500 }}>← {project.name}</a>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>Invoices</div>
      </header>
      <main style={{ maxWidth: 860, margin: '0 auto', padding: '28px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Total Billed', value: `$${totalBilled.toLocaleString()}` },
            { label: 'Total Paid', value: `$${totalPaid.toLocaleString()}` },
            { label: 'Outstanding', value: `$${(totalBilled - totalPaid).toLocaleString()}` },
          ].map(s => (
            <div key={s.label} style={{ background: 'white', borderRadius: 12, padding: '16px 18px', border: '1px solid #e5e7eb' }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22 }}>{s.value}</div>
            </div>
          ))}
        </div>
        <div style={{ background: 'white', borderRadius: 12, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
                {['Invoice #','Date','Due','Amount','Status','Actions'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(invoices ?? []).length === 0 ? (
                <tr><td colSpan={6} style={{ padding: 40, textAlign: 'center', color: '#6b7280', fontSize: 14 }}>No invoices yet.</td></tr>
              ) : (invoices ?? []).map(inv => (
                <tr key={inv.id} style={{ borderBottom: '1px solid #f3f4f6' }}>
                  <td style={{ padding: '12px 16px', fontFamily: 'monospace', fontSize: 12, fontWeight: 600 }}>{inv.invoice_number}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13 }}>{inv.invoice_date ?? '—'}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13 }}>{inv.due_date ?? '—'}</td>
                  <td style={{ padding: '12px 16px', fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14 }}>${Number(inv.amount || 0).toLocaleString()}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ background: inv.status === 'paid' ? '#dcfce7' : inv.status === 'approved' ? '#dbeafe' : '#fef3c7', color: inv.status === 'paid' ? '#16a34a' : inv.status === 'approved' ? '#1e4d8c' : '#d97706', padding: '2px 8px', borderRadius: 5, fontSize: 11, fontWeight: 600, textTransform: 'capitalize' }}>
                      {inv.status}
                    </span>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <button style={{ padding: '5px 10px', background: '#f3f4f6', border: '1px solid #e5e7eb', borderRadius: 6, fontSize: 12, cursor: 'pointer' }}>↓ PDF</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
