import { createServerSupabase } from '../../../../../lib/serverAuth';
import { redirect, notFound } from 'next/navigation';

interface Props { params: { projectId: string } }

export default async function ClientPhotosPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=client');

  const { data: project } = await supabase.from('projects').select('id,name').eq('id', params.projectId).single();
  if (!project) notFound();

  const { data: photos } = await supabase.from('photos').select('*').eq('project_id', params.projectId).in('visibility', ['customer','public']).order('taken_at', { ascending: false });

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', gap: 12, position: 'sticky', top: 0, zIndex: 40 }}>
        <a href={`/client/projects/${params.projectId}`} style={{ fontSize: 12, color: '#6b7280', textDecoration: 'none', fontWeight: 500 }}>← {project.name}</a>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>Progress Photos</div>
        <span style={{ fontSize: 12, color: '#6b7280', background: '#f3f4f6', padding: '2px 7px', borderRadius: 5 }}>{(photos ?? []).length}</span>
      </header>
      <main style={{ maxWidth: 960, margin: '0 auto', padding: '28px 24px' }}>
        {(photos ?? []).length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 60, textAlign: 'center', border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📷</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 8 }}>No photos shared yet</div>
            <p style={{ fontSize: 13, color: '#6b7280' }}>Progress photos will appear here as your team uploads them.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 12 }}>
            {(photos ?? []).map(p => (
              <div key={p.id} style={{ background: 'white', borderRadius: 12, overflow: 'hidden', border: '1px solid #e5e7eb', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
                <div style={{ height: 160, background: '#f3f4f6', overflow: 'hidden' }}>
                  {p.signed_url
                    ? <img src={p.signed_url} alt={p.caption ?? ''} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36, color: '#d1d5db' }}>📷</div>}
                </div>
                <div style={{ padding: '10px 12px' }}>
                  {p.caption && <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 3 }}>{p.caption}</div>}
                  <div style={{ fontSize: 11, color: '#6b7280' }}>{p.taken_at ? new Date(p.taken_at).toLocaleDateString() : ''}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
