import { createServerSupabase } from '../../../../../lib/serverAuth';
import { redirect, notFound } from 'next/navigation';

interface Props { params: { projectId: string } }

export default async function ClientCOPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=client');

  const { data: project } = await supabase.from('projects').select('id,name,project_number').eq('id', params.projectId).single();
  if (!project) notFound();

  const { data: cos } = await supabase.from('change_orders').select('*').eq('project_id', params.projectId).order('number');
  const pending = (cos ?? []).filter(c => c.status === 'pending_client');
  const approved = (cos ?? []).filter(c => c.status === 'approved');

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 40 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <a href={`/client/projects/${params.projectId}`} style={{ fontSize: 12, color: '#6b7280', textDecoration: 'none', fontWeight: 500 }}>← {project.name}</a>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>Change Orders</div>
        </div>
      </header>
      <main style={{ maxWidth: 860, margin: '0 auto', padding: '28px 24px' }}>
        {pending.length > 0 && (
          <div style={{ background: '#fef3c7', border: '1px solid #fcd34d', borderRadius: 12, padding: '18px 20px', marginBottom: 20 }}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15, marginBottom: 4 }}>
              ⚠ {pending.length} Change Order{pending.length > 1 ? 's' : ''} Awaiting Your Approval
            </div>
            <p style={{ fontSize: 13, color: '#92400e' }}>Please review and approve or reject. Work on these items cannot proceed without your authorization.</p>
          </div>
        )}

        {pending.map(co => (
          <div key={co.id} style={{ background: 'white', borderRadius: 14, border: '2px solid #fcd34d', padding: 20, marginBottom: 14, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 2 }}>CO-{String(co.number).padStart(3,'0')}</div>
                <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16 }}>{co.title}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22, color: Number(co.amount) > 0 ? '#16a34a' : '#dc2626' }}>
                  {Number(co.amount) > 0 ? '+' : ''}${Number(co.amount || 0).toLocaleString()}
                </div>
                {co.time_extension_days > 0 && <div style={{ fontSize: 12, color: '#6b7280' }}>+{co.time_extension_days} calendar days</div>}
              </div>
            </div>
            {co.description && <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.6, marginBottom: 12, padding: '10px 14px', background: '#f9fafb', borderRadius: 8 }}>{co.description}</p>}
            <div style={{ display: 'flex', gap: 8 }}>
              <button style={{ flex: 1, padding: '12px', background: '#1e4d8c', color: 'white', border: 'none', borderRadius: 10, fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>
                ✓ Approve & Sign
              </button>
              <button style={{ padding: '12px 16px', background: '#f3f4f6', border: '1px solid #e5e7eb', borderRadius: 10, fontWeight: 600, fontSize: 13, color: '#374151', cursor: 'pointer' }}>
                Request Revision
              </button>
            </div>
          </div>
        ))}

        {approved.length > 0 && (
          <>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10, marginTop: pending.length > 0 ? 20 : 0 }}>Approved Change Orders</div>
            {approved.map(co => (
              <div key={co.id} style={{ background: 'white', borderRadius: 12, border: '1px solid #e5e7eb', padding: '14px 18px', marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 2 }}>CO-{String(co.number).padStart(3,'0')}</div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{co.title}</div>
                  {co.client_signed_at && <div style={{ fontSize: 11, color: '#16a34a', marginTop: 2 }}>✓ Signed {new Date(co.client_signed_at).toLocaleDateString()}</div>}
                </div>
                <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 18, color: '#16a34a' }}>
                  +${Number(co.amount || 0).toLocaleString()}
                </div>
              </div>
            ))}
          </>
        )}

        {(cos ?? []).length === 0 && (
          <div style={{ background: 'white', borderRadius: 14, padding: 60, textAlign: 'center', border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>⊕</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 8 }}>No Change Orders</div>
            <p style={{ fontSize: 13, color: '#6b7280' }}>Any contract changes will appear here for your review and approval.</p>
          </div>
        )}
      </main>
    </div>
  );
}
