import { createServerSupabase } from '../../../../../lib/serverAuth';
import { redirect, notFound } from 'next/navigation';

interface Props { params: { projectId: string } }

export default async function ClientDocumentsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=client');

  const { data: project } = await supabase.from('projects').select('id,name,project_number').eq('id', params.projectId).single();
  if (!project) notFound();

  const { data: docs } = await supabase.from('documents').select('*').eq('project_id', params.projectId).in('visibility', ['customer','public']).eq('is_current_version', true).order('created_at', { ascending: false });

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', gap: 12, position: 'sticky', top: 0, zIndex: 40 }}>
        <a href={`/client/projects/${params.projectId}`} style={{ fontSize: 12, color: '#6b7280', textDecoration: 'none', fontWeight: 500 }}>← {project.name}</a>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>Documents</div>
      </header>
      <main style={{ maxWidth: 860, margin: '0 auto', padding: '28px 24px' }}>
        {(docs ?? []).length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 60, textAlign: 'center', border: '1px solid #e5e7eb' }}>
            <div style={{ fontSize: 36, marginBottom: 12 }}>▣</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 8 }}>No documents shared yet</div>
            <p style={{ fontSize: 13, color: '#6b7280' }}>Your project team will share drawings, specs, and contracts here.</p>
          </div>
        ) : (
          <div style={{ background: 'white', borderRadius: 12, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
            {(docs ?? []).map((doc, i) => (
              <div key={doc.id} style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 14, borderBottom: i < (docs ?? []).length - 1 ? '1px solid #f3f4f6' : 'none' }}>
                <div style={{ fontSize: 24, color: '#9ca3af' }}>▣</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{doc.sheet_title ?? doc.file_name}</div>
                  <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>{doc.doc_type} · v{doc.version} · {doc.created_at ? new Date(doc.created_at).toLocaleDateString() : ''}</div>
                </div>
                <button style={{ padding: '7px 14px', background: '#1e4d8c', color: 'white', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>↓ Download</button>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
