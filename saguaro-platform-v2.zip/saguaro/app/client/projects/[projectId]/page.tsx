import { createServerSupabase } from '../../../../lib/serverAuth';
import { redirect, notFound } from 'next/navigation';

interface Props { params: { projectId: string } }

function ClientShell({ projectName, projectNumber, children }: { projectName: string; projectNumber: string; children: React.ReactNode }) {
  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 40 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <a href="/client/dashboard" style={{ fontSize: 12, color: '#6b7280', textDecoration: 'none', fontWeight: 500 }}>← My Projects</a>
          <div style={{ width: 1, height: 18, background: '#e5e7eb' }} />
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15, color: '#111827' }}>{projectName}</div>
          <span style={{ fontSize: 11, color: '#6b7280', background: '#f3f4f6', padding: '2px 7px', borderRadius: 5 }}>{projectNumber}</span>
        </div>
        <a href="/logout" style={{ padding: '6px 12px', background: '#f3f4f6', borderRadius: 6, fontSize: 12, fontWeight: 500, color: '#374151', textDecoration: 'none' }}>Sign Out</a>
      </header>
      {children}
    </div>
  );
}

export default async function ClientProjectPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=client');

  const { data: project } = await supabase
    .from('projects')
    .select('*')
    .eq('id', params.projectId)
    .single();
  if (!project) notFound();

  const [cosRes, invoicesRes, docsRes, photosRes, openRFIsRes, schedRes] = await Promise.all([
    supabase.from('change_orders').select('id,number,title,status,amount,client_signed_at').eq('project_id', params.projectId).order('number'),
    supabase.from('invoices').select('id,invoice_number,amount,status,due_date,type').eq('project_id', params.projectId).eq('type', 'owner').order('created_at', { ascending: false }).limit(10),
    supabase.from('documents').select('id,file_name,sheet_title,doc_type,visibility,created_at,version').eq('project_id', params.projectId).in('visibility', ['customer','public']).eq('is_current_version', true).order('created_at', { ascending: false }),
    supabase.from('photos').select('id,caption,signed_url,tags,taken_at').eq('project_id', params.projectId).in('visibility', ['customer','public']).order('taken_at', { ascending: false }).limit(12),
    supabase.from('rfis').select('id,number,subject,status').eq('project_id', params.projectId).not('status', 'in', '("answered","closed")').limit(5),
    supabase.from('schedule_tasks').select('id,name,status,percent_complete,planned_finish,is_milestone').eq('project_id', params.projectId).eq('is_milestone', true).order('planned_finish'),
  ]);

  const cos = cosRes.data ?? [];
  const invoices = invoicesRes.data ?? [];
  const docs = docsRes.data ?? [];
  const photos = photosRes.data ?? [];
  const openRFIs = openRFIsRes.data ?? [];
  const milestones = schedRes.data ?? [];

  const pendingCOs = cos.filter(c => c.status === 'pending_client');
  const approvedCOValue = cos.filter(c => c.status === 'approved').reduce((s, c) => s + Number(c.amount || 0), 0);
  const pendingInvoices = invoices.filter(i => i.status === 'approved');

  const NAV = [
    { label: 'Overview', href: `/client/projects/${params.projectId}`, icon: '⬡' },
    { label: 'Change Orders', href: `/client/projects/${params.projectId}/change-orders`, icon: '⊕', badge: pendingCOs.length },
    { label: 'Invoices', href: `/client/projects/${params.projectId}/invoices`, icon: '▦', badge: pendingInvoices.length },
    { label: 'Documents', href: `/client/projects/${params.projectId}/documents`, icon: '▣' },
    { label: 'Photos', href: `/client/projects/${params.projectId}/photos`, icon: '⬜' },
    { label: 'Schedule', href: `/client/projects/${params.projectId}/schedule`, icon: '◷' },
  ];

  return (
    <ClientShell projectName={project.name} projectNumber={project.project_number}>
      {/* Tab nav */}
      <div style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', display: 'flex', gap: 0, overflowX: 'auto' }}>
        {NAV.map(n => (
          <a key={n.label} href={n.href} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '14px 16px', fontSize: 13, fontWeight: 600, color: n.href === `/client/projects/${params.projectId}` ? '#1e4d8c' : '#6b7280', textDecoration: 'none', borderBottom: n.href === `/client/projects/${params.projectId}` ? '2px solid #1e4d8c' : '2px solid transparent', whiteSpace: 'nowrap' }}>
            {n.icon} {n.label}
            {n.badge ? <span style={{ background: '#dc2626', color: 'white', borderRadius: 10, padding: '1px 6px', fontSize: 10, fontWeight: 700 }}>{n.badge}</span> : null}
          </a>
        ))}
      </div>

      <main style={{ maxWidth: 960, margin: '0 auto', padding: '28px 24px' }}>
        {/* Alerts */}
        {pendingCOs.length > 0 && (
          <div style={{ background: '#fef3c7', border: '1px solid #fcd34d', borderRadius: 10, padding: '14px 18px', marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <strong style={{ fontSize: 14 }}>⚠ {pendingCOs.length} Change Order(s) require your approval.</strong>
              <div style={{ fontSize: 12, color: '#92400e', marginTop: 2 }}>Please review and sign to proceed with work.</div>
            </div>
            <a href={`/client/projects/${params.projectId}/change-orders`} style={{ padding: '8px 16px', background: '#d97706', color: 'white', borderRadius: 8, fontSize: 12, fontWeight: 700, textDecoration: 'none' }}>Review Now</a>
          </div>
        )}

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Contract Value', value: `$${Number(project.contract_value || 0).toLocaleString()}` },
            { label: 'Approved COs', value: `+$${approvedCOValue.toLocaleString()}` },
            { label: 'Completion', value: `${project.completion_pct ?? 0}%` },
            { label: 'Open RFIs', value: openRFIs.length },
          ].map(s => (
            <div key={s.label} style={{ background: 'white', borderRadius: 12, padding: '16px 18px', border: '1px solid #e5e7eb' }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22 }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Progress */}
        <div style={{ background: 'white', borderRadius: 12, padding: 20, border: '1px solid #e5e7eb', marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>Overall Progress</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 20 }}>{project.completion_pct ?? 0}%</div>
          </div>
          <div style={{ height: 12, background: '#f3f4f6', borderRadius: 6 }}>
            <div style={{ width: `${project.completion_pct ?? 0}%`, height: '100%', background: '#1e4d8c', borderRadius: 6, transition: 'width 0.5s' }} />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {/* Milestones */}
          <div style={{ background: 'white', borderRadius: 12, padding: 18, border: '1px solid #e5e7eb' }}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Key Milestones</div>
            {milestones.length === 0 ? (
              <p style={{ fontSize: 13, color: '#6b7280' }}>No milestones set yet.</p>
            ) : milestones.map(m => (
              <div key={m.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #f3f4f6', fontSize: 13 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: m.status === 'complete' ? '#16a34a' : '#1e4d8c', flexShrink: 0 }} />
                  {m.name}
                </div>
                <div style={{ fontSize: 12, color: '#6b7280' }}>{m.planned_finish}</div>
              </div>
            ))}
          </div>

          {/* Recent Photos */}
          <div style={{ background: 'white', borderRadius: 12, padding: 18, border: '1px solid #e5e7eb' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14 }}>Recent Photos</div>
              <a href={`/client/projects/${params.projectId}/photos`} style={{ fontSize: 12, color: '#1e4d8c', fontWeight: 600, textDecoration: 'none' }}>View all →</a>
            </div>
            {photos.length === 0 ? (
              <p style={{ fontSize: 13, color: '#6b7280' }}>No photos shared yet.</p>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6 }}>
                {photos.slice(0, 6).map(p => (
                  <div key={p.id} style={{ aspectRatio: '1', borderRadius: 8, background: '#f3f4f6', overflow: 'hidden' }}>
                    {p.signed_url
                      ? <img src={p.signed_url} alt={p.caption ?? ''} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, color: '#d1d5db' }}>📷</div>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </ClientShell>
  );
}
