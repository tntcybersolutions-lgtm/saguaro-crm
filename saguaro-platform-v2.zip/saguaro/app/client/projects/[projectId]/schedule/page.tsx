import { createServerSupabase } from '../../../../../lib/serverAuth';
import { redirect, notFound } from 'next/navigation';

interface Props { params: { projectId: string } }

export default async function ClientSchedulePage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?portal=client');

  const { data: project } = await supabase.from('projects').select('id,name,completion_pct,planned_start_date,planned_completion_date').eq('id', params.projectId).single();
  if (!project) notFound();

  const { data: tasks } = await supabase.from('schedule_tasks').select('*').eq('project_id', params.projectId).eq('is_milestone', true).order('planned_finish');
  const { data: phases } = await supabase.from('schedule_tasks').select('phase,status,percent_complete').eq('project_id', params.projectId);

  // Summarize by phase
  const phaseMap: Record<string, { total: number; done: number; pct: number[] }> = {};
  (phases ?? []).forEach(t => {
    const p = t.phase ?? 'General';
    if (!phaseMap[p]) phaseMap[p] = { total: 0, done: 0, pct: [] };
    phaseMap[p].total++;
    if (t.status === 'complete') phaseMap[p].done++;
    if (t.percent_complete) phaseMap[p].pct.push(t.percent_complete);
  });

  return (
    <div style={{ minHeight: '100vh', background: '#f8f8f7' }}>
      <header style={{ background: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 32px', height: 60, display: 'flex', alignItems: 'center', gap: 12, position: 'sticky', top: 0, zIndex: 40 }}>
        <a href={`/client/projects/${params.projectId}`} style={{ fontSize: 12, color: '#6b7280', textDecoration: 'none', fontWeight: 500 }}>← {project.name}</a>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 15 }}>Schedule</div>
      </header>
      <main style={{ maxWidth: 860, margin: '0 auto', padding: '28px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Project Start', value: project.planned_start_date ?? '—' },
            { label: 'Completion Target', value: project.planned_completion_date ?? '—' },
            { label: 'Overall Progress', value: `${project.completion_pct ?? 0}%` },
          ].map(s => (
            <div key={s.label} style={{ background: 'white', borderRadius: 12, padding: '16px 18px', border: '1px solid #e5e7eb' }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 20 }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Phase summary */}
        {Object.keys(phaseMap).length > 0 && (
          <div style={{ background: 'white', borderRadius: 12, border: '1px solid #e5e7eb', padding: '18px 20px', marginBottom: 16 }}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14, marginBottom: 14 }}>Phase Progress</div>
            {Object.entries(phaseMap).map(([phase, data]) => {
              const avg = data.pct.length > 0 ? Math.round(data.pct.reduce((s, p) => s + p, 0) / data.pct.length) : Math.round((data.done / data.total) * 100);
              return (
                <div key={phase} style={{ marginBottom: 12 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
                    <span style={{ fontWeight: 600 }}>{phase}</span>
                    <span style={{ color: '#6b7280', fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>{avg}%</span>
                  </div>
                  <div style={{ height: 8, background: '#f3f4f6', borderRadius: 4 }}>
                    <div style={{ width: `${avg}%`, height: '100%', background: '#1e4d8c', borderRadius: 4 }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Milestones */}
        <div style={{ background: 'white', borderRadius: 12, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid #f3f4f6', fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14 }}>Key Milestones</div>
          {(tasks ?? []).length === 0 ? (
            <div style={{ padding: 40, textAlign: 'center', color: '#6b7280', fontSize: 14 }}>No milestones set.</div>
          ) : (tasks ?? []).map(m => (
            <div key={m.id} style={{ padding: '12px 20px', display: 'flex', alignItems: 'center', gap: 14, borderBottom: '1px solid #f9fafb' }}>
              <div style={{ width: 12, height: 12, borderRadius: '50%', background: m.status === 'complete' ? '#16a34a' : m.status === 'in_progress' ? '#1e4d8c' : '#d1d5db', flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{m.name}</div>
                <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>{m.phase ?? '—'}</div>
              </div>
              <div style={{ fontSize: 13, color: '#374151' }}>{m.planned_finish ?? '—'}</div>
              <span style={{ background: m.status === 'complete' ? '#dcfce7' : m.status === 'in_progress' ? '#dbeafe' : '#f3f4f6', color: m.status === 'complete' ? '#16a34a' : m.status === 'in_progress' ? '#1e4d8c' : '#6b7280', padding: '2px 8px', borderRadius: 5, fontSize: 11, fontWeight: 600, textTransform: 'capitalize' }}>{m.status?.replace(/_/g,' ')}</span>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
