import { createServerSupabase } from '../../../lib/serverAuth';

interface Props { params: { projectId: string } }

export default async function MobileInspectionsPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: inspections } = await supabase
    .from('inspections')
    .select('*')
    .eq('project_id', params.projectId)
    .is('completed_date', null)
    .order('scheduled_date', { ascending: true })
    .limit(15);

  const RESULT_COLORS: Record<string, string> = { passed: '#16a34a', failed: '#dc2626', partial: '#ca8a04', cancelled: '#6b7280' };

  return (
    <div style={{ minHeight: '100vh', background: '#f5f5f4' }}>
      <div style={{ background: '#1e4d8c', color: 'white', padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => window.history.back()} style={{ background: 'none', border: 'none', color: 'white', fontSize: 22, cursor: 'pointer', padding: 0 }}>←</button>
        <div>
          <div style={{ fontWeight: 700, fontSize: 17 }}>Inspections</div>
          <div style={{ fontSize: 12, opacity: 0.85 }}>Upcoming & pending</div>
        </div>
      </div>

      <div style={{ padding: 16 }}>
        {(inspections ?? []).length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 32, textAlign: 'center', color: '#6b7280' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>✓</div>
            <div style={{ fontWeight: 600 }}>No pending inspections</div>
          </div>
        ) : (inspections ?? []).map(insp => (
          <div key={insp.id} style={{ background: 'white', borderRadius: 12, padding: '14px 16px', marginBottom: 10 }}>
            <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 4 }}>{insp.inspection_type}</div>
            <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>{insp.agency ?? '—'}</div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>📅 {insp.scheduled_date ?? 'Not scheduled'}</div>
              {insp.result
                ? <span style={{ background: RESULT_COLORS[insp.result] + '20', color: RESULT_COLORS[insp.result], fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 20 }}>{insp.result}</span>
                : <span style={{ background: '#fef3c7', color: '#ca8a04', fontSize: 12, fontWeight: 700, padding: '3px 10px', borderRadius: 20 }}>Scheduled</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
