'use client';
import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getSupabaseClient } from '../../../../lib/supabaseClient';

const WEATHER_OPTIONS = ['clear','partly_cloudy','overcast','rain','heavy_rain','wind','fog','snow'];

export default function MobileDailyLogPage() {
  const params = useParams();
  const router = useRouter();
  const projectId = params.projectId as string;
  const today = new Date().toISOString().split('T')[0];

  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    weather_conditions: 'clear',
    temp_low: '',
    temp_high: '',
    manpower_count: '',
    work_performed: '',
    delays: '',
    safety_notes: '',
  });

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (isDraft: boolean) => {
    if (!form.work_performed.trim()) { setError('Work performed is required.'); return; }
    setSaving(true);
    setError('');
    const supabase = getSupabaseClient();
    const { error: dbErr } = await supabase.from('daily_logs').upsert({
      project_id: projectId,
      log_date: today,
      weather_conditions: form.weather_conditions,
      temp_low: form.temp_low ? Number(form.temp_low) : null,
      temp_high: form.temp_high ? Number(form.temp_high) : null,
      manpower_count: form.manpower_count ? Number(form.manpower_count) : 0,
      work_performed: form.work_performed,
      delays: form.delays || null,
      safety_notes: form.safety_notes || null,
      is_submitted: !isDraft,
    }, { onConflict: 'project_id,log_date' });
    setSaving(false);
    if (dbErr) { setError(dbErr.message); return; }
    setSaved(true);
    if (!isDraft) setTimeout(() => router.push(`/mobile/${projectId}`), 1200);
  };

  if (saved) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#f4f4f5', gap: 12 }}>
        <div style={{ fontSize: 48 }}>✅</div>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 18 }}>Log Submitted!</div>
        <div style={{ fontSize: 13, color: '#6b7280' }}>Daily log for {today} has been recorded.</div>
        <a href={`/mobile/${projectId}`} style={{ marginTop: 8, padding: '12px 24px', background: '#1e4d8c', color: 'white', borderRadius: 10, fontWeight: 700, textDecoration: 'none' }}>← Back to Hub</a>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f4f4f5', paddingBottom: 100, maxWidth: 480, margin: '0 auto' }}>
      <div style={{ background: '#1e4d8c', padding: '16px 20px', position: 'sticky', top: 0, zIndex: 50 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <a href={`/mobile/${projectId}`} style={{ color: 'rgba(255,255,255,0.6)', fontSize: 20, textDecoration: 'none' }}>←</a>
          <div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 17, color: 'white' }}>Daily Log</div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>{new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}</div>
          </div>
        </div>
      </div>
      <div style={{ padding: 20 }}>
        {error && <div style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: '#991b1b', marginBottom: 12 }}>{error}</div>}

        {/* Weather */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 14, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>☁ Weather</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 6, marginBottom: 10 }}>
            {WEATHER_OPTIONS.map(w => (
              <button key={w} onClick={() => set('weather_conditions', w)}
                style={{ padding: '8px 4px', borderRadius: 8, border: `2px solid ${form.weather_conditions === w ? '#1e4d8c' : '#e5e7eb'}`, background: form.weather_conditions === w ? '#dbeafe' : 'white', fontSize: 10, fontWeight: 600, color: form.weather_conditions === w ? '#1e4d8c' : '#6b7280', cursor: 'pointer', textTransform: 'capitalize' }}>
                {w.replace(/_/g,' ')}
              </button>
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <div><label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>Low °F</label><input className="form-input" type="number" value={form.temp_low} onChange={e => set('temp_low', e.target.value)} placeholder="55" style={{ width: '100%' }} /></div>
            <div><label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>High °F</label><input className="form-input" type="number" value={form.temp_high} onChange={e => set('temp_high', e.target.value)} placeholder="78" style={{ width: '100%' }} /></div>
          </div>
        </div>

        {/* Manpower */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 14, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>👷 Manpower</div>
          <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 4 }}>Total Workers On Site</label>
          <input className="form-input" type="number" value={form.manpower_count} onChange={e => set('manpower_count', e.target.value)} placeholder="0" style={{ width: '100%', fontSize: 24, textAlign: 'center', fontWeight: 700, height: 52 }} />
        </div>

        {/* Work Performed */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 14, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>🔨 Work Performed <span style={{ color: '#ef4444', fontSize: 11 }}>*required</span></div>
          <textarea className="form-textarea" rows={5} value={form.work_performed} onChange={e => set('work_performed', e.target.value)} placeholder="Describe work completed today…" style={{ width: '100%', resize: 'vertical' }} />
        </div>

        {/* Delays */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 14, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>⚠ Delays (optional)</div>
          <textarea className="form-textarea" rows={3} value={form.delays} onChange={e => set('delays', e.target.value)} placeholder="Any delays, weather holds, material shortages…" style={{ width: '100%', resize: 'vertical' }} />
        </div>

        {/* Safety */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 14, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>🦺 Safety Notes (optional)</div>
          <textarea className="form-textarea" rows={3} value={form.safety_notes} onChange={e => set('safety_notes', e.target.value)} placeholder="Safety observations, near misses, incidents…" style={{ width: '100%', resize: 'vertical' }} />
        </div>
      </div>

      <div style={{ position: 'fixed', bottom: 0, left: '50%', transform: 'translateX(-50%)', width: '100%', maxWidth: 480, background: 'white', borderTop: '1px solid #e5e7eb', padding: '12px 20px', display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 8 }}>
        <button onClick={() => handleSubmit(true)} disabled={saving} style={{ padding: '12px', background: '#f3f4f6', border: '1px solid #e5e7eb', borderRadius: 10, fontWeight: 600, fontSize: 14, cursor: 'pointer' }}>
          Save Draft
        </button>
        <button onClick={() => handleSubmit(false)} disabled={saving} style={{ padding: '12px', background: saving ? '#6b7280' : '#1e4d8c', color: 'white', border: 'none', borderRadius: 10, fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14, cursor: saving ? 'not-allowed' : 'pointer' }}>
          {saving ? 'Saving…' : 'Submit Log ✓'}
        </button>
      </div>
    </div>
  );
}
