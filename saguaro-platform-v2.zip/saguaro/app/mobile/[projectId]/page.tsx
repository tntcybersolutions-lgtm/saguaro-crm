import { createServerSupabase } from '../../../lib/serverAuth';
import { notFound } from 'next/navigation';

interface Props { params: { projectId: string } }

const MOBILE_ACTIONS = [
  { label: 'Daily Log', href: 'daily-logs', icon: '▦', color: '#1e4d8c' },
  { label: 'Photos', href: 'photos', icon: '⬜', color: '#2563b0' },
  { label: 'Field Issue', href: 'field-issues', icon: '⚑', color: '#c9663c' },
  { label: 'Schedule', href: 'schedule', icon: '◷', color: '#16a34a' },
  { label: 'Inspection', href: 'inspections', icon: '✓', color: '#7c3aed' },
  { label: 'RFI', href: '../../rfis', icon: '◳', color: '#0284c7' },
];

export default async function MobileProjectPage({ params }: Props) {
  const supabase = await createServerSupabase();
  const { data: project } = await supabase.from('projects').select('*').eq('id', params.projectId).single();
  if (!project) notFound();

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-base)', paddingBottom: 80, maxWidth: 480, margin: '0 auto' }}>
      {/* Mobile Header */}
      <div style={{ background: 'var(--bg-sidebar)', padding: '16px 20px', position: 'sticky', top: 0, zIndex: 50 }}>
        <div style={{ fontSize: 10, fontWeight: 600, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{project.project_number}</div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'white', marginTop: 2 }}>{project.name}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
          <span className={`badge badge-${project.status === 'active' ? 'green' : 'blue'}`}>{project.status}</span>
          {project.site_city && <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>📍 {project.site_city}</span>}
        </div>
      </div>

      <div style={{ padding: '20px' }}>
        <div style={{ marginBottom: 16, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Quick Actions</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          {MOBILE_ACTIONS.map(action => (
            <a
              key={action.label}
              href={`/mobile/${params.projectId}/${action.href}`}
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '20px 12px', background: 'white', borderRadius: 12, border: '1px solid var(--border-color)', textDecoration: 'none', gap: 8, boxShadow: 'var(--shadow-sm)' }}
            >
              <span style={{ fontSize: 28 }}>{action.icon}</span>
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-primary)', textAlign: 'center', lineHeight: 1.2 }}>{action.label}</span>
            </a>
          ))}
        </div>
      </div>

      {/* Bottom Nav */}
      <div style={{ position: 'fixed', bottom: 0, left: '50%', transform: 'translateX(-50%)', width: '100%', maxWidth: 480, background: 'white', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-around', padding: '8px 0', zIndex: 100 }}>
        {[['Home','◈',`/mobile/${params.projectId}`], ['Projects','⬡','/app/projects'], ['Inbox','🔔','/app/notifications'], ['Profile','◎','/app/profile']].map(([label, icon, href]) => (
          <a key={label} href={href as string} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, padding: '4px 16px', textDecoration: 'none' }}>
            <span style={{ fontSize: 20 }}>{icon}</span>
            <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 500 }}>{label}</span>
          </a>
        ))}
      </div>
    </div>
  );
}
