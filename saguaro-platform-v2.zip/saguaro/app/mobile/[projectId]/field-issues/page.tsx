'use client';
import { useState } from 'react';

interface Props { params: { projectId: string } }

export default function MobileFieldIssuePage({ params }: Props) {
  const [form, setForm] = useState({ title: '', category: 'deficiency', severity: 'medium', location: '', description: '' });
  const [saving, setSaving] = useState(false);

  async function submit() {
    setSaving(true);
    await fetch(`/api/projects/${params.projectId}/field-issues`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
    });
    setSaving(false);
    window.location.href = `/mobile/${params.projectId}`;
  }

  const CATEGORIES = ['deficiency','safety','rfi','observation','ncr'];
  const SEVERITIES = [
    { id: 'low', label: 'Low', color: '#16a34a', dot: '#22c55e' },
    { id: 'medium', label: 'Medium', color: '#ca8a04', dot: '#eab308' },
    { id: 'high', label: 'High', color: '#ea580c', dot: '#f97316' },
    { id: 'critical', label: 'Critical', color: '#991b1b', dot: '#ef4444' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#f5f5f4', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#c9663c', color: 'white', padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => window.history.back()} style={{ background: 'none', border: 'none', color: 'white', fontSize: 22, cursor: 'pointer', padding: 0 }}>←</button>
        <div style={{ fontWeight: 700, fontSize: 17 }}>Log Field Issue</div>
      </div>

      <div style={{ flex: 1, padding: 16, maxWidth: 540, margin: '0 auto', width: '100%', boxSizing: 'border-box' }}>
        <div style={{ background: 'white', borderRadius: 14, padding: 20, marginBottom: 12 }}>
          <label style={{ display: 'block', fontWeight: 600, fontSize: 14, marginBottom: 6 }}>Issue Title *</label>
          <input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="Concrete wall spalling, Grid B-4" style={{ width: '100%', padding: '12px', border: '1.5px solid #d1d5db', borderRadius: 10, fontSize: 16, boxSizing: 'border-box' }} />
        </div>

        <div style={{ background: 'white', borderRadius: 14, padding: 20, marginBottom: 12 }}>
          <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 10 }}>Category</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {CATEGORIES.map(c => (
              <button key={c} onClick={() => setForm(p => ({ ...p, category: c }))} style={{ padding: '8px 14px', borderRadius: 20, border: `2px solid ${form.category === c ? '#c9663c' : '#d1d5db'}`, background: form.category === c ? '#c9663c' : 'white', color: form.category === c ? 'white' : '#374151', fontSize: 14, cursor: 'pointer', textTransform: 'capitalize' }}>{c}</button>
            ))}
          </div>
        </div>

        <div style={{ background: 'white', borderRadius: 14, padding: 20, marginBottom: 12 }}>
          <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 10 }}>Severity</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
            {SEVERITIES.map(s => (
              <button key={s.id} onClick={() => setForm(p => ({ ...p, severity: s.id }))} style={{ padding: '12px', borderRadius: 10, border: `2px solid ${form.severity === s.id ? s.color : '#d1d5db'}`, background: form.severity === s.id ? s.color + '15' : 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: s.dot }} />
                <span style={{ fontWeight: 600, fontSize: 14, color: form.severity === s.id ? s.color : '#374151' }}>{s.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div style={{ background: 'white', borderRadius: 14, padding: 20, marginBottom: 12 }}>
          <label style={{ display: 'block', fontWeight: 600, fontSize: 14, marginBottom: 6 }}>Location / Room</label>
          <input value={form.location} onChange={e => setForm(p => ({ ...p, location: e.target.value }))} placeholder="Level 2, Grid B-4, East stairwell…" style={{ width: '100%', padding: '12px', border: '1.5px solid #d1d5db', borderRadius: 10, fontSize: 15, boxSizing: 'border-box' }} />
        </div>

        <div style={{ background: 'white', borderRadius: 14, padding: 20 }}>
          <label style={{ display: 'block', fontWeight: 600, fontSize: 14, marginBottom: 6 }}>Description</label>
          <textarea rows={4} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="Describe the issue in detail…" style={{ width: '100%', padding: '12px', border: '1.5px solid #d1d5db', borderRadius: 10, fontSize: 15, fontFamily: 'inherit', boxSizing: 'border-box' }} />
        </div>
      </div>

      <div style={{ padding: '12px 20px', background: 'white', boxShadow: '0 -2px 8px rgba(0,0,0,0.08)' }}>
        <button onClick={submit} disabled={!form.title || saving} style={{ width: '100%', padding: '14px', border: 'none', borderRadius: 12, fontSize: 16, fontWeight: 700, background: form.title ? '#c9663c' : '#d1d5db', color: 'white', cursor: form.title ? 'pointer' : 'default' }}>
          {saving ? 'Saving…' : 'Log Issue'}
        </button>
      </div>
    </div>
  );
}
