'use client';
import { useState, useRef } from 'react';

interface Props { params: { projectId: string } }

export default function MobilePhotosPage({ params }: Props) {
  const [photos, setPhotos] = useState<Array<{ url: string; caption: string; tag: string }>>([]);
  const [caption, setCaption] = useState('');
  const [tag, setTag] = useState('Progress');
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const TAGS = ['Progress', 'Safety', 'Damage', 'Inspection', 'Material', 'Punchlist'];

  function handleFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    files.forEach(f => {
      const url = URL.createObjectURL(f);
      setPhotos(p => [...p, { url, caption, tag }]);
    });
  }

  async function uploadAll() {
    setUploading(true);
    await new Promise(r => setTimeout(r, 1200)); // TODO: real upload
    setUploading(false);
    alert(`${photos.length} photo(s) uploaded!`);
    window.location.href = `/mobile/${params.projectId}`;
  }

  return (
    <div style={{ minHeight: '100vh', background: '#111827', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#1e4d8c', color: 'white', padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => window.history.back()} style={{ background: 'none', border: 'none', color: 'white', fontSize: 22, cursor: 'pointer', padding: 0 }}>←</button>
        <div style={{ fontWeight: 700, fontSize: 17 }}>Upload Photos</div>
      </div>

      {/* Camera / File picker */}
      <div style={{ flex: 1, padding: 16 }}>
        {photos.length === 0 ? (
          <div style={{ background: '#1f2937', borderRadius: 16, padding: 40, textAlign: 'center', border: '2px dashed #374151', cursor: 'pointer' }} onClick={() => inputRef.current?.click()}>
            <div style={{ fontSize: 64, marginBottom: 12 }}>📷</div>
            <div style={{ color: 'white', fontWeight: 700, fontSize: 16, marginBottom: 6 }}>Tap to add photos</div>
            <div style={{ color: '#9ca3af', fontSize: 13 }}>Camera or gallery</div>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
            {photos.map((p, i) => (
              <div key={i} style={{ position: 'relative', borderRadius: 10, overflow: 'hidden', background: '#1f2937', aspectRatio: '1' }}>
                <img src={p.url} alt={p.caption} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'rgba(0,0,0,0.7)', padding: '6px 8px' }}>
                  <div style={{ color: 'white', fontSize: 11 }}>{p.tag}</div>
                </div>
                <button onClick={() => setPhotos(photos.filter((_, j) => j !== i))} style={{ position: 'absolute', top: 6, right: 6, background: 'rgba(0,0,0,0.6)', border: 'none', color: 'white', borderRadius: '50%', width: 24, height: 24, cursor: 'pointer', fontSize: 12 }}>✕</button>
              </div>
            ))}
            <div style={{ background: '#1f2937', borderRadius: 10, aspectRatio: '1', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', border: '2px dashed #374151' }} onClick={() => inputRef.current?.click()}>
              <div style={{ color: '#9ca3af', fontSize: 28 }}>+</div>
            </div>
          </div>
        )}

        <input ref={inputRef} type="file" accept="image/*" multiple capture="environment" onChange={handleFiles} style={{ display: 'none' }} />

        {/* Tag & Caption */}
        <div style={{ marginTop: 16, background: '#1f2937', borderRadius: 12, padding: 16 }}>
          <div style={{ color: 'white', fontWeight: 600, fontSize: 14, marginBottom: 10 }}>Tag</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
            {TAGS.map(t => (
              <button key={t} onClick={() => setTag(t)} style={{ padding: '6px 14px', borderRadius: 20, border: `1.5px solid ${tag === t ? '#3b82f6' : '#374151'}`, background: tag === t ? '#1d4ed8' : 'transparent', color: 'white', fontSize: 13, cursor: 'pointer' }}>{t}</button>
            ))}
          </div>
          <div style={{ color: 'white', fontWeight: 600, fontSize: 14, marginBottom: 8 }}>Caption (optional)</div>
          <input value={caption} onChange={e => setCaption(e.target.value)} placeholder="East wall framing progress…" style={{ width: '100%', padding: '10px 12px', background: '#374151', border: 'none', borderRadius: 8, color: 'white', fontSize: 14, boxSizing: 'border-box' }} />
        </div>
      </div>

      <div style={{ padding: '12px 20px', background: '#1f2937' }}>
        <button onClick={uploadAll} disabled={photos.length === 0 || uploading} style={{ width: '100%', padding: '14px', border: 'none', borderRadius: 12, fontSize: 16, fontWeight: 700, background: photos.length > 0 ? '#1e4d8c' : '#374151', color: 'white', cursor: photos.length > 0 ? 'pointer' : 'default' }}>
          {uploading ? 'Uploading…' : photos.length > 0 ? `↑ Upload ${photos.length} Photo${photos.length > 1 ? 's' : ''}` : 'Select Photos First'}
        </button>
      </div>
    </div>
  );
}
