import { createServerSupabase } from '../../../lib/serverAuth';

interface Props { params: { projectId: string } }

export default async function MobileSchedulePage({ params }: Props) {
  const supabase = await createServerSupabase();
  const today = new Date().toISOString().split('T')[0];
  const { data: tasks } = await supabase
    .from('schedule_tasks')
    .select('*')
    .eq('project_id', params.projectId)
    .not('status', 'eq', 'complete')
    .order('planned_start', { ascending: true })
    .limit(20);

  const STATUS_COLORS: Record<string, string> = { not_started: '#6b7280', in_progress: '#2563b0', delayed: '#dc2626', at_risk: '#ea580c', complete: '#16a34a' };

  return (
    <div style={{ minHeight: '100vh', background: '#f5f5f4' }}>
      <div style={{ background: '#16a34a', color: 'white', padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => window.history.back()} style={{ background: 'none', border: 'none', color: 'white', fontSize: 22, cursor: 'pointer', padding: 0 }}>←</button>
        <div>
          <div style={{ fontWeight: 700, fontSize: 17 }}>Schedule</div>
          <div style={{ fontSize: 12, opacity: 0.85 }}>Active & upcoming tasks</div>
        </div>
      </div>

      <div style={{ padding: 16 }}>
        {(tasks ?? []).length === 0 ? (
          <div style={{ background: 'white', borderRadius: 14, padding: 32, textAlign: 'center', color: '#6b7280' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>◷</div>
            <div style={{ fontWeight: 600 }}>No active tasks</div>
          </div>
        ) : (tasks ?? []).map(task => {
          const isStartingToday = task.planned_start === today;
          const color = STATUS_COLORS[task.status ?? 'not_started'];
          return (
            <div key={task.id} style={{ background: 'white', borderRadius: 12, padding: '14px 16px', marginBottom: 10, borderLeft: `4px solid ${color}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
                <div style={{ fontWeight: 600, fontSize: 15, flex: 1, paddingRight: 8 }}>{task.name}</div>
                {task.is_critical_path && <span style={{ background: '#fef2f2', color: '#dc2626', fontSize: 10, fontWeight: 700, padding: '2px 6px', borderRadius: 4 }}>CP</span>}
              </div>
              <div style={{ display: 'flex', gap: 12, marginBottom: 8 }}>
                <span style={{ fontSize: 12, color: '#6b7280' }}>{task.phase ?? 'Phase'}</span>
                {task.trade && <span style={{ fontSize: 12, color: '#6b7280' }}>· {task.trade}</span>}
                {isStartingToday && <span style={{ background: '#dcfce7', color: '#16a34a', fontSize: 11, fontWeight: 600, padding: '1px 6px', borderRadius: 4 }}>Starts today</span>}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ flex: 1, height: 6, background: '#f3f4f6', borderRadius: 3, marginRight: 10 }}>
                  <div style={{ width: `${task.percent_complete ?? 0}%`, height: '100%', background: color, borderRadius: 3 }} />
                </div>
                <span style={{ fontSize: 12, fontWeight: 600, color, minWidth: 36 }}>{task.percent_complete ?? 0}%</span>
              </div>
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 6 }}>
                {task.planned_start} → {task.planned_finish ?? '—'}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
