'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getSupabaseClient } from '../../../lib/supabaseClient';

export default function LogoutPage({ params }: { params: { tenantSlug: string } }) {
  const router = useRouter();
  const { tenantSlug } = params;

  useEffect(() => {
    async function signOut() {
      const supabase = getSupabaseClient();
      await supabase.auth.signOut();
      router.push(`/${tenantSlug}/login`);
    }
    signOut();
  }, []);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--sag-void)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--sag-text-dim)',
      fontSize: 14,
    }}>
      Signing out...
    </div>
  );
}
