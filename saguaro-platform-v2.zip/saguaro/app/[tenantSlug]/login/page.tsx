'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { getSupabaseClient } from '../../../lib/supabaseClient';

export default function LoginPage({ params }: { params: { tenantSlug: string } }) {
  const { tenantSlug } = params;
  const router = useRouter();
  const searchParams = useSearchParams();
  const next = searchParams.get('next') ?? `/${tenantSlug}/app`;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleLogin() {
    setLoading(true);
    setError('');
    const supabase = getSupabaseClient();
    const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
    if (authError) {
      setError('Invalid email or password');
      setLoading(false);
      return;
    }
    router.push(next);
  }

  return (
    <div className="login-wrap">
      <div className="login-card">
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 800, letterSpacing: -0.5 }}>
            SAGUARO
          </div>
          <div style={{ fontSize: 11, color: 'var(--sag-text-dim)', letterSpacing: 2, textTransform: 'uppercase', marginTop: 4 }}>
            Construction Intelligence Platform
          </div>
          <div style={{
            marginTop: 16,
            background: 'var(--sag-raised)',
            border: '1px solid var(--sag-border)',
            borderRadius: 6,
            padding: '6px 12px',
            fontSize: 12,
            color: 'var(--sag-text-dim)',
            display: 'inline-block',
          }}>
            {tenantSlug}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@company.com"
              onKeyDown={e => e.key === 'Enter' && handleLogin()}
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              onKeyDown={e => e.key === 'Enter' && handleLogin()}
            />
          </div>

          {error && (
            <div style={{
              background: 'rgba(217,64,64,0.1)',
              border: '1px solid var(--sag-red)',
              borderRadius: 6,
              padding: '8px 12px',
              fontSize: 13,
              color: '#FF6B6B',
            }}>
              {error}
            </div>
          )}

          <button
            className="btn btn-primary"
            onClick={handleLogin}
            disabled={loading || !email || !password}
            style={{ justifyContent: 'center', marginTop: 4 }}
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>

          <div style={{ textAlign: 'center', marginTop: 8 }}>
            <a href={`/${tenantSlug}/request-access`} style={{ fontSize: 12, color: 'var(--sag-text-dim)' }}>
              Need access? Request here →
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
