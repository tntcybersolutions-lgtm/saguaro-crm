import { AppShell } from '../../../../components/AppShell';
import { PageHeader } from '../../../../components/PageHeader';
import { requireAuth } from '../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../lib/supabaseAdmin';

export default async function CompliancePage({ params }: { params: { tenantSlug: string } }) {
  const { tenantSlug } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin.from('tenants').select('id,name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;

  const now = new Date().toISOString();
  const in30 = new Date(Date.now() + 30 * 86400000).toISOString();

  const [
    { data: vendors },
    { data: employees },
  ] = await Promise.all([
    supabaseAdmin.from('subcontractor_companies').select('*').eq('tenant_id', tenant.id),
    supabaseAdmin.from('tenant_memberships').select('id, user_id, role').eq('tenant_id', tenant.id).eq('is_active', true),
  ]);

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <PageHeader
        title="Compliance"
        subtitle="Vendor and employee compliance tracking — COIs, W-9s, certs, and gates"
        actions={<button className="btn btn-secondary">Export Compliance Packet</button>}
      />

      {/* Summary KPIs */}
      <div className="kpi-grid mb-6">
        {[
          { label: 'Active Vendors',    value: vendors?.length ?? 0,  accent: 'var(--sag-blue-light)' },
          { label: 'COI Expiring 30d',  value: 0,                     accent: 'var(--sag-yellow)' },
          { label: 'Missing W-9',       value: 0,                     accent: 'var(--sag-red)' },
          { label: 'Prequal Expired',   value: 0,                     accent: 'var(--sag-clay-light)' },
        ].map(k => (
          <div key={k.label} className="kpi-card" style={{ '--accent': k.accent } as React.CSSProperties}>
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Vendor Compliance */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Vendor / Sub Compliance</div>
            <a href={`/${tenantSlug}/app/compliance/vendors`} className="btn btn-ghost btn-sm">View All</a>
          </div>
          {(!vendors || vendors.length === 0) ? (
            <div style={{ color: 'var(--sag-text-dim)', fontSize: 13, padding: '16px 0' }}>
              No vendors in system yet. Add subcontractors to track their compliance.
            </div>
          ) : (
            <div className="table-wrap" style={{ border: 'none' }}>
              <table>
                <thead><tr><th>Company</th><th>COI</th><th>W-9</th><th>Prequal</th><th>Gate</th></tr></thead>
                <tbody>
                  {vendors.slice(0, 8).map((v: any) => (
                    <tr key={v.id}>
                      <td><span style={{ fontWeight: 500 }}>{v.name ?? v.company_name}</span></td>
                      <td>
                        <span className={`badge ${v.coi_expiry && new Date(v.coi_expiry) > new Date() ? 'badge-green' : 'badge-red'}`}>
                          {v.coi_expiry ? new Date(v.coi_expiry).toLocaleDateString() : 'Missing'}
                        </span>
                      </td>
                      <td><span className={`badge ${v.w9_on_file ? 'badge-green' : 'badge-red'}`}>{v.w9_on_file ? '✓' : 'Missing'}</span></td>
                      <td><span className={`badge ${v.prequal_status === 'approved' ? 'badge-green' : 'badge-muted'}`}>{v.prequal_status ?? '—'}</span></td>
                      <td>
                        <span className={`badge ${v.is_blocked ? 'badge-red' : 'badge-green'}`}>
                          {v.is_blocked ? 'Blocked' : 'Active'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Employee Compliance */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Employee Compliance</div>
          </div>
          <div style={{ color: 'var(--sag-text-dim)', fontSize: 13 }}>
            <p style={{ marginBottom: 12 }}>Track training certs, licensing, and safety cards for your internal team.</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { label: 'OSHA 10/30 certs',  status: 'ok' },
                { label: 'First Aid/CPR',      status: 'ok' },
                { label: 'Driver licenses',    status: 'ok' },
                { label: 'Contractor licenses',status: 'ok' },
              ].map(item => (
                <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>{item.label}</span>
                  <span className={`badge ${item.status === 'ok' ? 'badge-green' : 'badge-yellow'}`}>
                    {item.status === 'ok' ? 'All Current' : 'Review'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
