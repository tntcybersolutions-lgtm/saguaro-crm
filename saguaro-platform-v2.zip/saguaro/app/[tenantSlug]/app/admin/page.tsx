import { AppShell } from '../../../../../components/AppShell';
import { PageHeader } from '../../../../../components/PageHeader';
import { requireAuth } from '../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../lib/supabaseAdmin';

export default async function AdminPage({ params }: { params: { tenantSlug: string } }) {
  const { tenantSlug } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin.from('tenants').select('id,name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;

  const { data: members } = await supabaseAdmin
    .from('tenant_memberships')
    .select('id, role, is_active, created_at, user_id')
    .eq('tenant_id', tenant.id)
    .order('created_at', { ascending: false });

  const { data: invites } = await supabaseAdmin
    .from('tenant_invites')
    .select('id, email, role, expires_at, accepted_at, created_at')
    .eq('tenant_id', tenant.id)
    .is('accepted_at', null)
    .gt('expires_at', new Date().toISOString())
    .order('created_at', { ascending: false });

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <PageHeader
        title="Admin"
        subtitle="Manage users, roles, and workspace settings"
        actions={
          <a href={`/${tenantSlug}/app/admin/invites`} className="btn btn-primary">+ Invite User</a>
        }
      />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Members */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Team Members ({members?.length ?? 0})</div>
            <a href={`/${tenantSlug}/app/admin/invites`} className="btn btn-ghost btn-sm">Invite</a>
          </div>
          <div className="table-wrap" style={{ border: 'none' }}>
            <table>
              <thead><tr><th>User ID</th><th>Role</th><th>Status</th><th>Since</th></tr></thead>
              <tbody>
                {(members ?? []).map((m: any) => (
                  <tr key={m.id}>
                    <td><span className="text-dim text-xs">{m.user_id?.slice(0,8)}...</span></td>
                    <td>
                      <span className={`badge ${m.role === 'robert' ? 'badge-critical' : m.role === 'owner' ? 'badge-clay' : 'badge-blue'}`}>
                        {m.role}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${m.is_active ? 'badge-green' : 'badge-muted'}`}>
                        {m.is_active ? 'active' : 'inactive'}
                      </span>
                    </td>
                    <td><span className="text-dim text-xs">{new Date(m.created_at).toLocaleDateString()}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pending Invites */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Pending Invites ({invites?.length ?? 0})</div>
          </div>
          {(!invites || invites.length === 0) ? (
            <div style={{ color: 'var(--sag-text-dim)', fontSize: 13, padding: '16px 0' }}>No pending invites.</div>
          ) : (
            <div className="table-wrap" style={{ border: 'none' }}>
              <table>
                <thead><tr><th>Email</th><th>Role</th><th>Expires</th></tr></thead>
                <tbody>
                  {invites.map((inv: any) => (
                    <tr key={inv.id}>
                      <td><span style={{ fontWeight: 500 }}>{inv.email}</span></td>
                      <td><span className="badge badge-blue">{inv.role}</span></td>
                      <td><span className="text-dim text-xs">{new Date(inv.expires_at).toLocaleDateString()}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* System Links */}
        <div className="card" style={{ gridColumn: '1 / -1' }}>
          <div className="card-header"><div className="card-title">System Management</div></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            {[
              { label: 'Audit Logs',       href: `/${tenantSlug}/app/admin/audit`,    icon: '📋' },
              { label: 'Invites',          href: `/${tenantSlug}/app/admin/invites`,  icon: '✉' },
              { label: 'Onboarding',       href: `/${tenantSlug}/app/onboarding`,     icon: '🚀' },
              { label: 'Notifications',    href: `/${tenantSlug}/app/admin/notifications`, icon: '🔔' },
              { label: 'Integrations',     href: `/${tenantSlug}/app/admin/integrations`,  icon: '🔌' },
              { label: 'Security',         href: `/${tenantSlug}/app/admin/security`,      icon: '🔒' },
              { label: 'Billing',          href: `/${tenantSlug}/app/admin/billing`,        icon: '💳' },
              { label: 'Workflows',        href: `/${tenantSlug}/app/admin/workflows`,      icon: '⚙' },
            ].map(item => (
              <a key={item.label} href={item.href} style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '12px 14px',
                background: 'var(--sag-raised)',
                border: '1px solid var(--sag-border)',
                borderRadius: 6,
                textDecoration: 'none',
                fontSize: 13, color: 'var(--sag-text)', fontWeight: 500,
              }}>
                <span>{item.icon}</span>{item.label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
