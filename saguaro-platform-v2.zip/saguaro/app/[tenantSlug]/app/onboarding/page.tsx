import { AppShell } from '../../../../components/AppShell';
import { PageHeader } from '../../../../components/PageHeader';
import { requireAuth } from '../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../lib/supabaseAdmin';

const ONBOARDING_STEPS = [
  { id: 'workspace_setup',  label: 'Set up workspace',         desc: 'Add company name, logo, and branding', href: '/admin' },
  { id: 'invite_team',      label: 'Invite team members',      desc: 'Add your PM, super, estimator, and admin', href: '/admin/invites' },
  { id: 'first_project',    label: 'Create first project',     desc: 'Set up a project with client, site, and contract details', href: '/projects/new' },
  { id: 'sql_b',            label: 'Run SQL Batch B',          desc: 'Deploy drawings, photos, RFIs, invoices, change orders, bid packages', href: '#sql' },
  { id: 'sql_c',            label: 'Run SQL Batch C',          desc: 'Deploy autopilot, schedule, permits, field modules', href: '#sql' },
  { id: 'storage_buckets',  label: 'Create storage buckets',   desc: 'project-files, project-photos in Supabase Storage', href: '#storage' },
  { id: 'autopilot',        label: 'Configure Autopilot',      desc: 'Set AUTOPILOT_CRON_SECRET and enable cron job', href: '/autopilot' },
  { id: 'compliance',       label: 'Set up compliance rules',  desc: 'Configure COI and W-9 requirements for vendors', href: '/compliance' },
  { id: 'mobile_test',      label: 'Test mobile access',       desc: 'Open /{tenantSlug}/mobile/{projectId} on your phone', href: '#mobile' },
];

export default async function OnboardingPage({ params }: { params: { tenantSlug: string } }) {
  const { tenantSlug } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin.from('tenants').select('id,name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;

  const { data: onboarding } = await supabaseAdmin
    .from('tenant_onboarding')
    .select('*')
    .eq('tenant_id', tenant.id)
    .single();

  const completed: Record<string, boolean> = onboarding?.steps_completed ?? {};
  const doneCount = Object.values(completed).filter(Boolean).length;
  const pct = Math.round((doneCount / ONBOARDING_STEPS.length) * 100);

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <PageHeader title="Onboarding" subtitle="Complete these steps to get Saguaro fully operational" />

      {/* Progress */}
      <div className="card mb-6">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div style={{ fontWeight: 600, fontSize: 14 }}>{pct}% Complete</div>
          <div style={{ fontSize: 13, color: 'var(--sag-text-dim)' }}>{doneCount} / {ONBOARDING_STEPS.length} steps done</div>
        </div>
        <div style={{ height: 8, background: 'var(--sag-raised)', borderRadius: 4, overflow: 'hidden' }}>
          <div style={{ width: `${pct}%`, height: '100%', background: pct === 100 ? 'var(--sag-green)' : 'var(--sag-blue-mid)', borderRadius: 4, transition: 'width 0.3s' }} />
        </div>
      </div>

      {/* Steps */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {ONBOARDING_STEPS.map((step, idx) => {
          const done = Boolean(completed[step.id]);
          return (
            <div key={step.id} style={{
              background: 'var(--sag-surface)',
              border: `1px solid ${done ? 'rgba(34,165,110,0.3)' : 'var(--sag-border)'}`,
              borderRadius: 8,
              padding: '16px 20px',
              display: 'flex',
              alignItems: 'center',
              gap: 16,
            }}>
              {/* Step number / check */}
              <div style={{
                width: 32, height: 32,
                borderRadius: '50%',
                background: done ? 'var(--sag-green)' : 'var(--sag-raised)',
                border: `2px solid ${done ? 'var(--sag-green)' : 'var(--sag-border)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
                fontSize: done ? 14 : 12,
                color: done ? '#fff' : 'var(--sag-text-dim)',
                fontWeight: 700,
              }}>
                {done ? '✓' : idx + 1}
              </div>

              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14, color: done ? 'var(--sag-text-dim)' : 'var(--sag-text)' }}>
                  {step.label}
                  {done && <span style={{ color: 'var(--sag-green)', marginLeft: 8, fontSize: 12 }}>Done</span>}
                </div>
                <div style={{ fontSize: 12, color: 'var(--sag-text-mute)', marginTop: 2 }}>{step.desc}</div>
              </div>

              {!done && (
                <a
                  href={step.href.startsWith('/') && !step.href.startsWith('#') ? `/${tenantSlug}/app${step.href}` : step.href}
                  className="btn btn-secondary btn-sm"
                  style={{ flexShrink: 0 }}
                >
                  Go →
                </a>
              )}
            </div>
          );
        })}
      </div>

      {/* SQL Reference */}
      <div className="card mt-6" id="sql">
        <div className="card-header"><div className="card-title">SQL Batch Reference</div></div>
        <p style={{ fontSize: 13, color: 'var(--sag-text-dim)', marginBottom: 12 }}>
          Run these in order in your Supabase SQL editor. All migration files are included in your bundle.
        </p>
        {[
          { file: '20260307_001_core.sql',      label: 'Batch A — Core: tenants, memberships, projects, audit' },
          { file: '20260307_002_project_modules.sql', label: 'Batch B — Modules: RFIs, invoices, drawings, photos, change orders, bids' },
          { file: '20260307_003_compliance.sql', label: 'Batch C — Production: autopilot, schedule, permits, inspections, field' },
          { file: '20260307_autopilot.sql',      label: 'Autopilot — AI engine tables, alerts, runs, views' },
        ].map(batch => (
          <div key={batch.file} style={{
            padding: '10px 14px',
            background: 'var(--sag-raised)',
            borderRadius: 6,
            marginBottom: 6,
            fontFamily: 'monospace',
            fontSize: 12,
          }}>
            <span style={{ color: 'var(--sag-blue-light)' }}>{batch.file}</span>
            <span style={{ color: 'var(--sag-text-dim)', marginLeft: 12 }}>{batch.label}</span>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
