import { AppShell } from '../../../../../components/AppShell';
import { PageHeader } from '../../../../../components/PageHeader';
import { requireAuth } from '../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../lib/supabaseAdmin';

export default async function ProjectsPage({ params }: { params: { tenantSlug: string } }) {
  const { tenantSlug } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin
    .from('tenants').select('id, name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;

  const { data: projects } = await supabaseAdmin
    .from('projects')
    .select('*')
    .eq('tenant_id', tenant.id)
    .order('created_at', { ascending: false });

  const all = projects ?? [];

  const statusCounts = {
    active: all.filter(p => p.status === 'active').length,
    bidding: all.filter(p => p.status === 'bidding').length,
    complete: all.filter(p => p.status === 'complete').length,
    total: all.length,
  };

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <PageHeader
        title="Portfolio"
        subtitle={`${statusCounts.total} projects across all phases`}
        actions={
          <a href={`/${tenantSlug}/app/projects/new`} className="btn btn-primary">+ New Project</a>
        }
      />

      {/* Summary pills */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
        {[
          { label: 'All',      value: statusCounts.total,   color: 'badge-muted' },
          { label: 'Active',   value: statusCounts.active,  color: 'badge-green' },
          { label: 'Bidding',  value: statusCounts.bidding, color: 'badge-blue' },
          { label: 'Complete', value: statusCounts.complete,color: 'badge-muted' },
        ].map(s => (
          <span key={s.label} className={`badge ${s.color}`} style={{ padding: '5px 12px', cursor: 'pointer', fontSize: 12 }}>
            {s.label} · {s.value}
          </span>
        ))}
      </div>

      {all.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <div className="empty-state-icon"><span style={{ fontSize: 20 }}>📁</span></div>
            <div className="empty-state-title">No projects yet</div>
            <p style={{ fontSize: 13, color: 'var(--sag-text-dim)', maxWidth: 300 }}>
              Create your first project to start managing bids, schedules, field ops, and more.
            </p>
            <div style={{ marginTop: 16 }}>
              <a href={`/${tenantSlug}/app/projects/new`} className="btn btn-primary">+ Create First Project</a>
            </div>
          </div>
        </div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Project Name</th>
                <th>Client</th>
                <th>Site</th>
                <th>PM</th>
                <th>Status</th>
                <th>Type</th>
                <th>Contract Value</th>
                <th>Start</th>
                <th>Target End</th>
                <th>Health</th>
              </tr>
            </thead>
            <tbody>
              {all.map((p: any) => (
                <tr key={p.id}>
                  <td><span className="text-dim text-xs">{p.project_number ?? '—'}</span></td>
                  <td>
                    <a href={`/${tenantSlug}/app/projects/${p.id}`} style={{ color: 'var(--sag-blue-light)', textDecoration: 'none', fontWeight: 500 }}>
                      {p.name}
                    </a>
                  </td>
                  <td><span className="text-dim">{p.client_name ?? '—'}</span></td>
                  <td><span className="text-dim">{p.site_city ?? '—'}</span></td>
                  <td><span className="text-dim">{p.pm_name ?? '—'}</span></td>
                  <td>
                    <span className={`badge ${
                      p.status === 'active' ? 'badge-green' :
                      p.status === 'bidding' ? 'badge-blue' :
                      p.status === 'complete' ? 'badge-muted' :
                      p.status === 'on hold' ? 'badge-yellow' : 'badge-muted'
                    }`}>
                      {p.status ?? 'unknown'}
                    </span>
                  </td>
                  <td><span className="text-dim text-xs">{p.project_type ?? '—'}</span></td>
                  <td>
                    <span style={{ fontWeight: 600 }}>
                      {p.contract_value ? `$${Number(p.contract_value).toLocaleString()}` : '—'}
                    </span>
                  </td>
                  <td><span className="text-dim text-xs">{p.start_date ? new Date(p.start_date).toLocaleDateString() : '—'}</span></td>
                  <td><span className="text-dim text-xs">{p.target_end_date ? new Date(p.target_end_date).toLocaleDateString() : '—'}</span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <div className={`dot ${
                        !p.health_score ? 'dot-muted' :
                        p.health_score >= 80 ? 'dot-green' :
                        p.health_score >= 60 ? 'dot-yellow' : 'dot-red'
                      }`} />
                      <span className="text-xs text-dim">{p.health_score ?? '—'}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}
