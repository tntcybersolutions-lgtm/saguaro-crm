import { ProjectSidebar } from '../../../../../../components/ProjectSidebar';
import { AppShell } from '../../../../../../components/AppShell';
import { AutopilotPanel } from '../../../../../../components/AutopilotPanel';
import { requireAuth } from '../../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../../lib/supabaseAdmin';

async function getProjectData(tenantId: string, projectId: string) {
  const [
    { data: project },
    { count: openRfis },
    { count: openInvoices },
    { count: openIssues },
    { count: taskCount },
    { data: recentActivity },
  ] = await Promise.all([
    supabaseAdmin.from('projects').select('*').eq('id', projectId).eq('tenant_id', tenantId).single(),
    supabaseAdmin.from('rfis').select('*', { count: 'exact', head: true }).eq('project_id', projectId).not('status', 'in', '("closed","answered","resolved")'),
    supabaseAdmin.from('invoices').select('*', { count: 'exact', head: true }).eq('project_id', projectId).not('status', 'in', '("paid","void","cancelled")'),
    supabaseAdmin.from('field_issues').select('*', { count: 'exact', head: true }).eq('project_id', projectId).not('status', 'in', '("closed","resolved")'),
    supabaseAdmin.from('schedule_tasks').select('*', { count: 'exact', head: true }).eq('project_id', projectId),
    supabaseAdmin.from('activity_events').select('*').eq('project_id', projectId).order('created_at', { ascending: false }).limit(10),
  ]);

  return {
    project,
    openRfis: openRfis ?? 0,
    openInvoices: openInvoices ?? 0,
    openIssues: openIssues ?? 0,
    taskCount: taskCount ?? 0,
    recentActivity: recentActivity ?? [],
  };
}

export default async function ProjectHubPage({
  params,
}: {
  params: { tenantSlug: string; projectId: string };
}) {
  const { tenantSlug, projectId } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin
    .from('tenants').select('id, name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;

  const { project, openRfis, openInvoices, openIssues, taskCount, recentActivity } =
    await getProjectData(tenant.id, projectId);

  if (!project) return <div>Project not found</div>;

  const kpis = [
    { label: 'Contract Value',  value: project.contract_value ? `$${Number(project.contract_value).toLocaleString()}` : '—', accent: 'var(--sag-blue-light)' },
    { label: 'Open RFIs',       value: openRfis,     accent: openRfis > 0 ? 'var(--sag-yellow)' : 'var(--sag-green)' },
    { label: 'Open Invoices',   value: openInvoices, accent: openInvoices > 0 ? 'var(--sag-clay-light)' : 'var(--sag-green)' },
    { label: 'Field Issues',    value: openIssues,   accent: openIssues > 0 ? 'var(--sag-red)' : 'var(--sag-green)' },
    { label: 'Schedule Tasks',  value: taskCount,    accent: 'var(--sag-blue-light)' },
  ];

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <div style={{ display: 'flex', height: 'calc(100vh - var(--topbar-h))', margin: -24, overflow: 'hidden' }}>
        <ProjectSidebar
          tenantSlug={tenantSlug}
          projectId={projectId}
          projectName={project.name}
          projectNumber={project.project_number}
          status={project.status}
        />

        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          {/* Project Header */}
          <div className="project-hub-header mb-6">
            <div>
              <div style={{ fontSize: 11, color: 'var(--sag-text-mute)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>
                {project.project_number ?? 'Project'}
              </div>
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 800 }}>{project.name}</h1>
              <div className="project-hub-meta">
                {[
                  { label: 'Client',   value: project.client_name },
                  { label: 'Site',     value: project.site_address ?? project.site_city },
                  { label: 'PM',       value: project.pm_name },
                  { label: 'Super',    value: project.superintendent_name },
                  { label: 'Start',    value: project.start_date ? new Date(project.start_date).toLocaleDateString() : null },
                  { label: 'Target',   value: project.target_end_date ? new Date(project.target_end_date).toLocaleDateString() : null },
                ].filter(m => m.value).map(meta => (
                  <div key={meta.label} className="project-hub-meta-item">
                    <strong>{meta.value}</strong>
                    {meta.label}
                  </div>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
              <span className={`badge ${
                project.status === 'active' ? 'badge-green' :
                project.status === 'bidding' ? 'badge-blue' :
                project.status === 'complete' ? 'badge-muted' : 'badge-yellow'
              }`}>{project.status ?? 'unknown'}</span>
              <button className="btn btn-secondary btn-sm">Edit Project</button>
              <button className="btn btn-secondary btn-sm">Export</button>
            </div>
          </div>

          {/* KPIs */}
          <div className="kpi-grid mb-6" style={{ gridTemplateColumns: 'repeat(5, 1fr)' }}>
            {kpis.map(kpi => (
              <div key={kpi.label} className="kpi-card" style={{ '--accent': kpi.accent } as React.CSSProperties}>
                <div className="kpi-label">{kpi.label}</div>
                <div className="kpi-value" style={{ fontSize: 22 }}>{kpi.value}</div>
              </div>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 20 }}>
            {/* Scope + Activity */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {project.scope_summary && (
                <div className="card">
                  <div className="card-header"><div className="card-title">Scope Summary</div></div>
                  <p style={{ fontSize: 13, color: 'var(--sag-text-dim)', lineHeight: 1.6 }}>{project.scope_summary}</p>
                </div>
              )}

              {/* Quick create bar */}
              <div className="card card-sm">
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {[
                    { label: '+ RFI',         href: `/${tenantSlug}/app/projects/${projectId}/rfis/new` },
                    { label: '+ Daily Log',   href: `/${tenantSlug}/app/projects/${projectId}/daily-logs/new` },
                    { label: '+ Field Issue', href: `/${tenantSlug}/app/projects/${projectId}/field-issues/new` },
                    { label: '+ Task',        href: `/${tenantSlug}/app/projects/${projectId}/schedule/new` },
                    { label: '+ Invoice',     href: `/${tenantSlug}/app/projects/${projectId}/invoices/new` },
                    { label: '+ CO',          href: `/${tenantSlug}/app/projects/${projectId}/change-orders/new` },
                  ].map(a => (
                    <a key={a.label} href={a.href} className="btn btn-secondary btn-sm">{a.label}</a>
                  ))}
                </div>
              </div>

              {/* Recent Activity */}
              <div className="card">
                <div className="card-header">
                  <div className="card-title">Activity Feed</div>
                </div>
                {recentActivity.length === 0 ? (
                  <div style={{ color: 'var(--sag-text-dim)', fontSize: 13, padding: '16px 0' }}>No activity yet.</div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    {recentActivity.map((event: any) => (
                      <div key={event.id} style={{ display: 'flex', gap: 10, fontSize: 13 }}>
                        <div style={{
                          width: 28, height: 28, borderRadius: '50%',
                          background: 'var(--sag-raised)', border: '1px solid var(--sag-border)',
                          flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: 11,
                        }}>
                          {event.event_type === 'rfi_created' ? '?' :
                           event.event_type === 'invoice_created' ? '🧾' :
                           event.event_type === 'issue_created' ? '⚠' : '📋'}
                        </div>
                        <div>
                          <div style={{ color: 'var(--sag-text)' }}>{event.description ?? event.event_type}</div>
                          <div style={{ color: 'var(--sag-text-mute)', fontSize: 11, marginTop: 2 }}>
                            {new Date(event.created_at).toLocaleString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Right: Autopilot */}
            <div>
              <AutopilotPanel
                tenantId={tenant.id}
                projectId={projectId}
                tenantSlug={tenantSlug}
                compact
              />
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
