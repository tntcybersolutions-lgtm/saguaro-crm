import { AppShell } from '../../../../../../components/AppShell';
import { ProjectSidebar } from '../../../../../../components/ProjectSidebar';
import { PageHeader } from '../../../../../../components/PageHeader';
import { requireAuth } from '../../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../../lib/supabaseAdmin';

export default async function RFIsPage({ params }: { params: { tenantSlug: string; projectId: string } }) {
  const { tenantSlug, projectId } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin.from('tenants').select('id,name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;

  const { data: project } = await supabaseAdmin.from('projects').select('name,project_number,status').eq('id', projectId).single();
  const { data: rfis } = await supabaseAdmin.from('rfis').select('*').eq('project_id', projectId).order('created_at', { ascending: false });

  const all = rfis ?? [];
  const open = all.filter(r => !['closed','answered','resolved'].includes(String(r.status).toLowerCase()));

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <div style={{ display: 'flex', height: 'calc(100vh - var(--topbar-h))', margin: -24, overflow: 'hidden' }}>
        <ProjectSidebar tenantSlug={tenantSlug} projectId={projectId} projectName={project?.name ?? ''} projectNumber={project?.project_number} status={project?.status} />
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          <PageHeader
            title="RFIs"
            subtitle={`${open.length} open · ${all.length} total`}
            breadcrumbs={[{ label: project?.name ?? 'Project', href: `/${tenantSlug}/app/projects/${projectId}` }, { label: 'RFIs' }]}
            actions={<a href={`/${tenantSlug}/app/projects/${projectId}/rfis/new`} className="btn btn-primary">+ New RFI</a>}
          />

          {all.length === 0 ? (
            <div className="card"><div className="empty-state">
              <div className="empty-state-icon"><span style={{fontSize:20}}>?</span></div>
              <div className="empty-state-title">No RFIs yet</div>
              <p style={{fontSize:13,color:'var(--sag-text-dim)'}}>Create an RFI to request information from the design team or owner.</p>
              <div style={{marginTop:12}}><a href={`/${tenantSlug}/app/projects/${projectId}/rfis/new`} className="btn btn-primary btn-sm">+ New RFI</a></div>
            </div></div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>#</th><th>Subject</th><th>Status</th><th>Spec Section</th>
                  <th>Due Date</th><th>Assigned To</th><th>Days Open</th>
                </tr></thead>
                <tbody>
                  {all.map((rfi: any) => {
                    const dueDate = rfi.due_date ?? rfi.response_due_date;
                    const daysOpen = rfi.created_at
                      ? Math.floor((Date.now() - new Date(rfi.created_at).getTime()) / 86400000)
                      : null;
                    const isOverdue = dueDate && new Date(dueDate) < new Date() && !['closed','answered','resolved'].includes(String(rfi.status).toLowerCase());
                    return (
                      <tr key={rfi.id}>
                        <td><span className="text-dim text-xs">{rfi.number ?? rfi.rfi_number ?? '—'}</span></td>
                        <td>
                          <a href={`/${tenantSlug}/app/projects/${projectId}/rfis/${rfi.id}`} style={{color:'var(--sag-blue-light)',textDecoration:'none',fontWeight:500}}>
                            {rfi.subject ?? rfi.title ?? 'Untitled RFI'}
                          </a>
                        </td>
                        <td>
                          <span className={`badge ${
                            ['closed','answered','resolved'].includes(String(rfi.status).toLowerCase()) ? 'badge-green' :
                            String(rfi.status).toLowerCase() === 'draft' ? 'badge-muted' : 'badge-yellow'
                          }`}>{rfi.status ?? 'open'}</span>
                        </td>
                        <td><span className="text-dim text-xs">{rfi.spec_section ?? '—'}</span></td>
                        <td>
                          <span style={{color: isOverdue ? 'var(--sag-critical)' : 'var(--sag-text-dim)', fontSize:12, fontWeight: isOverdue ? 600 : 400}}>
                            {dueDate ? new Date(dueDate).toLocaleDateString() : '—'}
                            {isOverdue && ' ⚠'}
                          </span>
                        </td>
                        <td><span className="text-dim text-xs">{rfi.assigned_to_name ?? '—'}</span></td>
                        <td><span className="text-dim text-xs">{daysOpen !== null ? `${daysOpen}d` : '—'}</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
