import { AppShell } from '../../../../../../components/AppShell';
import { ProjectSidebar } from '../../../../../../components/ProjectSidebar';
import { PageHeader } from '../../../../../../components/PageHeader';
import { requireAuth } from '../../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../../lib/supabaseAdmin';

export default async function InvoicesPage({ params }: { params: { tenantSlug: string; projectId: string } }) {
  const { tenantSlug, projectId } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin.from('tenants').select('id,name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;
  const { data: project } = await supabaseAdmin.from('projects').select('name,project_number,status').eq('id', projectId).single();
  const { data: invoices } = await supabaseAdmin.from('invoices').select('*').eq('project_id', projectId).order('created_at', { ascending: false });

  const all = invoices ?? [];
  const unpaid = all.filter(i => !['paid','void','cancelled','canceled'].includes(String(i.status).toLowerCase()));
  const totalUnpaid = unpaid.reduce((s, i) => s + (Number(i.amount) || 0), 0);

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <div style={{ display: 'flex', height: 'calc(100vh - var(--topbar-h))', margin: -24, overflow: 'hidden' }}>
        <ProjectSidebar tenantSlug={tenantSlug} projectId={projectId} projectName={project?.name ?? ''} projectNumber={project?.project_number} status={project?.status} />
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          <PageHeader
            title="Invoices"
            subtitle={`${unpaid.length} unpaid · $${totalUnpaid.toLocaleString()} outstanding`}
            breadcrumbs={[{ label: project?.name ?? 'Project', href: `/${tenantSlug}/app/projects/${projectId}` }, { label: 'Invoices' }]}
            actions={<a href={`/${tenantSlug}/app/projects/${projectId}/invoices/new`} className="btn btn-primary">+ New Invoice</a>}
          />

          {all.length === 0 ? (
            <div className="card"><div className="empty-state">
              <div className="empty-state-icon"><span style={{fontSize:20}}>🧾</span></div>
              <div className="empty-state-title">No invoices yet</div>
            </div></div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>Invoice #</th><th>Description</th><th>Vendor</th>
                  <th>Amount</th><th>Status</th><th>Due Date</th><th>Days Overdue</th>
                </tr></thead>
                <tbody>
                  {all.map((inv: any) => {
                    const isOverdue = inv.due_date && new Date(inv.due_date) < new Date() && !['paid','void','cancelled','canceled'].includes(String(inv.status).toLowerCase());
                    const daysOverdue = isOverdue ? Math.floor((Date.now() - new Date(inv.due_date).getTime()) / 86400000) : 0;
                    return (
                      <tr key={inv.id}>
                        <td><a href={`/${tenantSlug}/app/projects/${projectId}/invoices/${inv.id}`} style={{color:'var(--sag-blue-light)',textDecoration:'none'}}>{inv.invoice_number ?? inv.number ?? '—'}</a></td>
                        <td><span className="text-dim truncate">{inv.description ?? '—'}</span></td>
                        <td><span className="text-dim text-xs">{inv.vendor_name ?? inv.payee_name ?? '—'}</span></td>
                        <td><span style={{fontWeight:600}}>{inv.amount ? `$${Number(inv.amount).toLocaleString()}` : '—'}</span></td>
                        <td>
                          <span className={`badge ${inv.status === 'paid' ? 'badge-green' : isOverdue ? 'badge-red' : 'badge-yellow'}`}>
                            {inv.status ?? 'pending'}
                          </span>
                        </td>
                        <td><span style={{color: isOverdue ? 'var(--sag-critical)' : 'var(--sag-text-dim)', fontSize:12}}>{inv.due_date ? new Date(inv.due_date).toLocaleDateString() : '—'}</span></td>
                        <td>
                          {isOverdue ? (
                            <span className="sev-critical" style={{fontSize:12}}>{daysOverdue}d ⚠</span>
                          ) : <span className="text-dim text-xs">—</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
