import { AppShell } from '../../../../../../components/AppShell';
import { ProjectSidebar } from '../../../../../../components/ProjectSidebar';
import { PageHeader } from '../../../../../../components/PageHeader';
import { requireAuth } from '../../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../../lib/supabaseAdmin';

export default async function FieldIssuesPage({ params }: { params: { tenantSlug: string; projectId: string } }) {
  const { tenantSlug, projectId } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin.from('tenants').select('id,name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;
  const { data: project } = await supabaseAdmin.from('projects').select('name,project_number,status').eq('id', projectId).single();
  const { data: issues } = await supabaseAdmin.from('field_issues').select('*').eq('project_id', projectId).order('created_at', { ascending: false });

  const all = issues ?? [];
  const open = all.filter(i => !['closed','resolved'].includes(String(i.status).toLowerCase()));

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <div style={{ display: 'flex', height: 'calc(100vh - var(--topbar-h))', margin: -24, overflow: 'hidden' }}>
        <ProjectSidebar tenantSlug={tenantSlug} projectId={projectId} projectName={project?.name ?? ''} projectNumber={project?.project_number} status={project?.status} />
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          <PageHeader
            title="Field Issues"
            subtitle={`${open.length} open · ${all.length} total`}
            breadcrumbs={[{ label: project?.name ?? 'Project', href: `/${tenantSlug}/app/projects/${projectId}` }, { label: 'Field Issues' }]}
            actions={<a href={`/${tenantSlug}/app/projects/${projectId}/field-issues/new`} className="btn btn-primary">+ New Issue</a>}
          />

          {all.length === 0 ? (
            <div className="card"><div className="empty-state">
              <div className="empty-state-icon"><span style={{fontSize:20}}>⚠</span></div>
              <div className="empty-state-title">No field issues logged</div>
              <div style={{marginTop:12}}><a href={`/${tenantSlug}/app/projects/${projectId}/field-issues/new`} className="btn btn-primary btn-sm">+ Log Issue</a></div>
            </div></div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>Title</th><th>Category</th><th>Severity</th><th>Status</th>
                  <th>Due Date</th><th>Assigned To</th><th>Age</th>
                </tr></thead>
                <tbody>
                  {all.map((issue: any) => {
                    const ageDays = issue.created_at ? Math.floor((Date.now() - new Date(issue.created_at).getTime()) / 86400000) : 0;
                    const isOverdue = (issue.due_date ?? issue.target_date) && new Date(issue.due_date ?? issue.target_date) < new Date() && !['closed','resolved'].includes(String(issue.status).toLowerCase());
                    return (
                      <tr key={issue.id}>
                        <td>
                          <a href={`/${tenantSlug}/app/projects/${projectId}/field-issues/${issue.id}`} style={{color:'var(--sag-blue-light)',textDecoration:'none',fontWeight:500}}>
                            {issue.title ?? issue.subject ?? 'Untitled'}
                          </a>
                        </td>
                        <td><span className="text-dim text-xs">{issue.category ?? '—'}</span></td>
                        <td>
                          <span className={`badge ${
                            issue.severity === 'critical' ? 'badge-critical' :
                            issue.severity === 'high' ? 'badge-red' :
                            issue.severity === 'medium' ? 'badge-yellow' : 'badge-muted'
                          }`}>{issue.severity ?? 'medium'}</span>
                        </td>
                        <td>
                          <span className={`badge ${['closed','resolved'].includes(String(issue.status).toLowerCase()) ? 'badge-green' : 'badge-yellow'}`}>
                            {issue.status ?? 'open'}
                          </span>
                        </td>
                        <td>
                          <span style={{color: isOverdue ? 'var(--sag-critical)' : 'var(--sag-text-dim)', fontSize:12}}>
                            {issue.due_date ?? issue.target_date ? new Date(issue.due_date ?? issue.target_date).toLocaleDateString() : '—'}
                            {isOverdue && ' ⚠'}
                          </span>
                        </td>
                        <td><span className="text-dim text-xs">{issue.assigned_to_name ?? '—'}</span></td>
                        <td><span className={`text-xs ${ageDays >= 10 ? 'sev-critical' : ageDays >= 5 ? 'sev-medium' : 'text-dim'}`}>{ageDays}d</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
