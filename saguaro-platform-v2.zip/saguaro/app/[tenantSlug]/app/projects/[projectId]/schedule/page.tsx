import { AppShell } from '../../../../../../components/AppShell';
import { ProjectSidebar } from '../../../../../../components/ProjectSidebar';
import { PageHeader } from '../../../../../../components/PageHeader';
import { requireAuth } from '../../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../../lib/supabaseAdmin';

export default async function SchedulePage({ params }: { params: { tenantSlug: string; projectId: string } }) {
  const { tenantSlug, projectId } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin.from('tenants').select('id,name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;
  const { data: project } = await supabaseAdmin.from('projects').select('name,project_number,status').eq('id', projectId).single();
  const { data: tasks } = await supabaseAdmin.from('schedule_tasks').select('*').eq('project_id', projectId).order('planned_start', { ascending: true });

  const all = tasks ?? [];
  const now = new Date();
  const behind = all.filter(t => {
    const closed = ['complete','completed','done','closed'].includes(String(t.status).toLowerCase());
    const baseline = t.planned_finish ?? t.baseline_finish;
    return !closed && baseline && new Date(baseline) < now;
  });
  const critical = all.filter(t => t.is_critical_path || t.critical_path);

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <div style={{ display: 'flex', height: 'calc(100vh - var(--topbar-h))', margin: -24, overflow: 'hidden' }}>
        <ProjectSidebar tenantSlug={tenantSlug} projectId={projectId} projectName={project?.name ?? ''} projectNumber={project?.project_number} status={project?.status} />
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          <PageHeader
            title="Schedule"
            subtitle={`${all.length} tasks · ${behind.length} behind · ${critical.length} on critical path`}
            breadcrumbs={[{ label: project?.name ?? 'Project', href: `/${tenantSlug}/app/projects/${projectId}` }, { label: 'Schedule' }]}
            actions={
              <>
                <a href={`/${tenantSlug}/app/projects/${projectId}/schedule/new`} className="btn btn-primary">+ Add Task</a>
                <button className="btn btn-secondary">Export Gantt</button>
              </>
            }
          />

          {/* Summary KPIs */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
            {[
              { label: 'Total Tasks',    value: all.length,              accent: 'var(--sag-blue-light)' },
              { label: 'Behind Schedule',value: behind.length,           accent: behind.length > 0 ? 'var(--sag-red)' : 'var(--sag-green)' },
              { label: 'Critical Path',  value: critical.length,         accent: 'var(--sag-yellow)' },
              { label: '% Complete',     value: `${all.length ? Math.round(all.reduce((s, t) => s + (Number(t.percent_complete) || 0), 0) / all.length) : 0}%`, accent: 'var(--sag-green)' },
            ].map(k => (
              <div key={k.label} className="kpi-card" style={{ '--accent': k.accent } as React.CSSProperties}>
                <div className="kpi-label">{k.label}</div>
                <div className="kpi-value" style={{fontSize:22}}>{k.value}</div>
              </div>
            ))}
          </div>

          {all.length === 0 ? (
            <div className="card"><div className="empty-state">
              <div className="empty-state-icon"><span style={{fontSize:20}}>📅</span></div>
              <div className="empty-state-title">No tasks scheduled</div>
              <div style={{marginTop:12}}><a href={`/${tenantSlug}/app/projects/${projectId}/schedule/new`} className="btn btn-primary btn-sm">+ Add First Task</a></div>
            </div></div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>Task Name</th><th>Status</th><th>Critical</th>
                  <th>Planned Start</th><th>Planned Finish</th><th>% Done</th><th>Slippage</th>
                </tr></thead>
                <tbody>
                  {all.map((task: any) => {
                    const closed = ['complete','completed','done','closed'].includes(String(task.status).toLowerCase());
                    const baseline = task.planned_finish ?? task.baseline_finish;
                    const delayDays = baseline && !closed && new Date(baseline) < now
                      ? Math.floor((now.getTime() - new Date(baseline).getTime()) / 86400000)
                      : 0;
                    return (
                      <tr key={task.id}>
                        <td>
                          <a href={`/${tenantSlug}/app/projects/${projectId}/schedule/${task.id}`} style={{color:'var(--sag-blue-light)',textDecoration:'none',fontWeight:500}}>
                            {task.name ?? task.task_name ?? 'Unnamed'}
                          </a>
                        </td>
                        <td>
                          <span className={`badge ${closed ? 'badge-green' : 'badge-yellow'}`}>{task.status ?? 'in progress'}</span>
                        </td>
                        <td>
                          {(task.is_critical_path || task.critical_path) ? <span className="badge badge-red">Critical</span> : <span className="text-mute text-xs">—</span>}
                        </td>
                        <td><span className="text-dim text-xs">{task.planned_start ? new Date(task.planned_start).toLocaleDateString() : '—'}</span></td>
                        <td><span className="text-dim text-xs">{baseline ? new Date(baseline).toLocaleDateString() : '—'}</span></td>
                        <td>
                          <div style={{display:'flex',alignItems:'center',gap:6}}>
                            <div style={{width:60,height:4,background:'var(--sag-raised)',borderRadius:2,overflow:'hidden'}}>
                              <div style={{width:`${task.percent_complete ?? 0}%`,height:'100%',background:'var(--sag-blue-light)'}} />
                            </div>
                            <span className="text-xs text-dim">{task.percent_complete ?? 0}%</span>
                          </div>
                        </td>
                        <td>
                          {delayDays > 0 ? (
                            <span className={`text-xs ${delayDays >= 10 ? 'sev-critical' : delayDays >= 5 ? 'sev-high' : 'sev-medium'}`}>
                              {delayDays}d late
                            </span>
                          ) : <span className="text-mute text-xs">On track</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
