'use client';

import { useEffect, useState } from 'react';
import { getSupabaseClient } from '../../../../../../lib/supabaseClient';

type BidSession = {
  id: string;
  name: string;
  trade: string;
  status: string;
  created_at: string;
  scope_description?: string;
};

type BidSubmission = {
  id: string;
  session_id: string;
  vendor_name: string;
  total_amount: number | null;
  status: string;
  submitted_at: string | null;
  notes?: string;
};

export default function BidLevelingPage({ tenantSlug, projectId, tenantId }: { tenantSlug: string; projectId: string; tenantId: string }) {
  const [sessions, setSessions] = useState<BidSession[]>([]);
  const [selected, setSelected] = useState<BidSession | null>(null);
  const [submissions, setSubmissions] = useState<BidSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [newSession, setNewSession] = useState({ name: '', trade: '', scope_description: '' });

  useEffect(() => { loadSessions(); }, []);
  useEffect(() => { if (selected) loadSubmissions(selected.id); }, [selected]);

  async function loadSessions() {
    const supabase = getSupabaseClient();
    const { data } = await supabase
      .from('bid_leveling_sessions')
      .select('*')
      .eq('project_id', projectId)
      .order('created_at', { ascending: false });
    setSessions(data ?? []);
    setLoading(false);
  }

  async function loadSubmissions(sessionId: string) {
    const supabase = getSupabaseClient();
    const { data } = await supabase
      .from('bid_submissions')
      .select('*')
      .eq('session_id', sessionId)
      .order('total_amount', { ascending: true });
    setSubmissions(data ?? []);
  }

  async function createSession() {
    const supabase = getSupabaseClient();
    const { data } = await supabase.from('bid_leveling_sessions').insert({
      project_id: projectId,
      tenant_id: tenantId,
      ...newSession,
      status: 'open',
    }).select().single();
    if (data) {
      setSessions(prev => [data, ...prev]);
      setSelected(data);
      setShowNew(false);
      setNewSession({ name: '', trade: '', scope_description: '' });
    }
  }

  const lowestBid = submissions.length > 0 ? Math.min(...submissions.filter(s => s.total_amount).map(s => s.total_amount!)) : null;

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 800 }}>⚖ Bid Leveling</h1>
          <p style={{ fontSize: 13, color: 'var(--sag-text-dim)', marginTop: 4 }}>Compare and level subcontractor bids side by side</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowNew(true)}>+ New Session</button>
      </div>

      {showNew && (
        <div className="card mb-6">
          <div className="card-header">
            <div className="card-title">New Bid Leveling Session</div>
            <button className="btn btn-ghost btn-sm" onClick={() => setShowNew(false)}>✕</button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div className="form-group">
              <label>Session Name</label>
              <input value={newSession.name} onChange={e => setNewSession(s => ({ ...s, name: e.target.value }))} placeholder="e.g., Electrical Rough-In" />
            </div>
            <div className="form-group">
              <label>Trade / Scope</label>
              <input value={newSession.trade} onChange={e => setNewSession(s => ({ ...s, trade: e.target.value }))} placeholder="e.g., Electrical" />
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label>Scope Description</label>
              <textarea value={newSession.scope_description} onChange={e => setNewSession(s => ({ ...s, scope_description: e.target.value }))} placeholder="Describe the scope of work..." />
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
            <button className="btn btn-primary" onClick={createSession} disabled={!newSession.name}>Create Session</button>
            <button className="btn btn-ghost" onClick={() => setShowNew(false)}>Cancel</button>
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 20 }}>
        {/* Session list */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.8, textTransform: 'uppercase', color: 'var(--sag-text-mute)', marginBottom: 8 }}>
            Sessions ({sessions.length})
          </div>
          {loading ? (
            <div style={{ color: 'var(--sag-text-dim)', fontSize: 13 }}>Loading...</div>
          ) : sessions.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: 20 }}>
              <div style={{ color: 'var(--sag-text-dim)', fontSize: 13 }}>No sessions yet</div>
              <button className="btn btn-secondary btn-sm" style={{ marginTop: 10 }} onClick={() => setShowNew(true)}>
                + Create First
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {sessions.map(session => (
                <button
                  key={session.id}
                  onClick={() => setSelected(session)}
                  style={{
                    background: selected?.id === session.id ? 'var(--sag-blue-glow)' : 'var(--sag-surface)',
                    border: `1px solid ${selected?.id === session.id ? 'var(--sag-blue)' : 'var(--sag-border)'}`,
                    borderRadius: 6,
                    padding: '10px 14px',
                    cursor: 'pointer',
                    textAlign: 'left',
                    width: '100%',
                  }}
                >
                  <div style={{ fontWeight: 600, fontSize: 13, color: selected?.id === session.id ? 'var(--sag-blue-light)' : 'var(--sag-text)' }}>
                    {session.name}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--sag-text-dim)', marginTop: 2 }}>{session.trade}</div>
                  <div style={{ marginTop: 4 }}>
                    <span className={`badge ${session.status === 'awarded' ? 'badge-green' : session.status === 'open' ? 'badge-blue' : 'badge-muted'}`}>
                      {session.status}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Bid comparison */}
        <div>
          {!selected ? (
            <div className="card">
              <div className="empty-state">
                <div className="empty-state-icon"><span style={{ fontSize: 20 }}>⚖</span></div>
                <div className="empty-state-title">Select a session to level bids</div>
              </div>
            </div>
          ) : (
            <div>
              <div className="card mb-4">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 700 }}>{selected.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--sag-text-dim)', marginTop: 4 }}>{selected.scope_description}</div>
                  </div>
                  <span className={`badge ${selected.status === 'awarded' ? 'badge-green' : 'badge-blue'}`}>{selected.status}</span>
                </div>
                {lowestBid && (
                  <div style={{ marginTop: 14, padding: '10px 14px', background: 'var(--sag-raised)', borderRadius: 6, display: 'inline-flex', gap: 10, alignItems: 'center' }}>
                    <span style={{ fontSize: 12, color: 'var(--sag-text-dim)' }}>Lowest bid:</span>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: 'var(--sag-green)' }}>
                      ${lowestBid.toLocaleString()}
                    </span>
                  </div>
                )}
              </div>

              {submissions.length === 0 ? (
                <div className="card">
                  <div className="empty-state">
                    <div className="empty-state-icon"><span style={{ fontSize: 18 }}>📋</span></div>
                    <div className="empty-state-title">No bids submitted yet</div>
                    <p style={{ fontSize: 13, color: 'var(--sag-text-dim)' }}>Invite subcontractors to submit their bids for this package.</p>
                  </div>
                </div>
              ) : (
                <div className="table-wrap">
                  <table>
                    <thead>
                      <tr>
                        <th>Vendor</th><th>Total Bid</th><th>vs. Lowest</th>
                        <th>Status</th><th>Submitted</th><th>Notes</th><th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {submissions.map((sub: any, idx: number) => {
                        const diff = lowestBid && sub.total_amount ? sub.total_amount - lowestBid : null;
                        const pctAbove = diff && lowestBid ? ((diff / lowestBid) * 100).toFixed(1) : null;
                        const isLowest = sub.total_amount === lowestBid;
                        return (
                          <tr key={sub.id}>
                            <td>
                              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                {isLowest && <span style={{ fontSize: 14 }}>⭐</span>}
                                <span style={{ fontWeight: 600 }}>{sub.vendor_name}</span>
                              </div>
                            </td>
                            <td>
                              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: isLowest ? 'var(--sag-green)' : 'var(--sag-text)' }}>
                                {sub.total_amount ? `$${sub.total_amount.toLocaleString()}` : '—'}
                              </span>
                            </td>
                            <td>
                              {diff !== null && diff > 0 ? (
                                <span style={{ color: 'var(--sag-clay-light)', fontSize: 12 }}>+${diff.toLocaleString()} (+{pctAbove}%)</span>
                              ) : isLowest ? (
                                <span style={{ color: 'var(--sag-green)', fontSize: 12 }}>Lowest ✓</span>
                              ) : <span className="text-mute text-xs">—</span>}
                            </td>
                            <td>
                              <span className={`badge ${sub.status === 'awarded' ? 'badge-green' : sub.status === 'submitted' ? 'badge-blue' : 'badge-muted'}`}>
                                {sub.status}
                              </span>
                            </td>
                            <td><span className="text-dim text-xs">{sub.submitted_at ? new Date(sub.submitted_at).toLocaleDateString() : '—'}</span></td>
                            <td><span className="text-dim text-xs truncate" style={{ maxWidth: 150 }}>{sub.notes ?? '—'}</span></td>
                            <td>
                              {sub.status !== 'awarded' && (
                                <button className="btn btn-secondary btn-sm" style={{ fontSize: 11 }}>Award</button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
