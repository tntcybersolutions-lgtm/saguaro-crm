import { AppShell } from '../../../../../../components/AppShell';
import { ProjectSidebar } from '../../../../../../components/ProjectSidebar';
import { requireAuth } from '../../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../../lib/supabaseAdmin';
import BidLevelingPage from './client';

export default async function BidLevelingServerPage({ params }: { params: { tenantSlug: string; projectId: string } }) {
  const { tenantSlug, projectId } = params;
  await requireAuth(tenantSlug);

  const { data: tenant } = await supabaseAdmin.from('tenants').select('id,name').eq('slug', tenantSlug).single();
  if (!tenant) return <div>Not found</div>;
  const { data: project } = await supabaseAdmin.from('projects').select('name,project_number,status').eq('id', projectId).single();

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <div style={{ display: 'flex', height: 'calc(100vh - var(--topbar-h))', margin: -24, overflow: 'hidden' }}>
        <ProjectSidebar tenantSlug={tenantSlug} projectId={projectId} projectName={project?.name ?? ''} projectNumber={project?.project_number} status={project?.status} />
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          <BidLevelingPage tenantSlug={tenantSlug} projectId={projectId} tenantId={tenant.id} />
        </div>
      </div>
    </AppShell>
  );
}
