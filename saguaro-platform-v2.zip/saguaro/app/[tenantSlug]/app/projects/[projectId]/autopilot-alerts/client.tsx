'use client';

import { useEffect, useState } from 'react';
import { getSupabaseClient } from '../../../../../../lib/supabaseClient';

type Alert = {
  id: string;
  title: string;
  summary: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'acknowledged' | 'resolved' | 'dismissed';
  rule_code: string;
  entity_type: string;
  entity_id: string | null;
  project_id: string | null;
  last_detected_at: string;
  first_detected_at: string;
  metadata: Record<string, any>;
  assigned_to: string | null;
};

type Props = { tenantId: string; projectId?: string; tenantSlug: string };

const SEV_ORDER = { critical: 0, high: 1, medium: 2, low: 3 };
const RULE_LABELS: Record<string, string> = {
  RFI_OVERDUE:           'RFI Overdue',
  INVOICE_OVERDUE:       'Invoice Overdue',
  SCHEDULE_SLIPPAGE:     'Schedule Slippage',
  FIELD_ISSUE_UNRESOLVED:'Field Issue',
  PROJECT_RISK_ROLLUP:   'Project Risk',
};

export function AutopilotAlertsClient({ tenantId, projectId, tenantSlug }: Props) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [filter, setFilter] = useState<{ severity: string; status: string; rule: string }>({
    severity: 'all', status: 'open,acknowledged', rule: 'all',
  });
  const [selected, setSelected] = useState<Alert | null>(null);

  useEffect(() => { loadAlerts(); }, [tenantId, projectId, filter]);

  async function loadAlerts() {
    const supabase = getSupabaseClient();
    let query = supabase
      .from('autopilot_alerts')
      .select('*')
      .eq('tenant_id', tenantId)
      .order('severity', { ascending: true })
      .order('last_detected_at', { ascending: false });

    if (projectId) query = query.eq('project_id', projectId);
    if (filter.severity !== 'all') query = query.eq('severity', filter.severity);
    if (filter.rule !== 'all') query = query.eq('rule_code', filter.rule);
    if (filter.status !== 'all') {
      const statuses = filter.status.split(',');
      query = query.in('status', statuses);
    }

    const { data } = await query;
    setAlerts((data ?? []).sort((a, b) =>
      (SEV_ORDER[a.severity as keyof typeof SEV_ORDER] ?? 3)
      - (SEV_ORDER[b.severity as keyof typeof SEV_ORDER] ?? 3)
    ));
    setLoading(false);
  }

  async function triggerRun() {
    setRunning(true);
    try {
      await fetch('/api/internal/autopilot/run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.NEXT_PUBLIC_AUTOPILOT_CRON_SECRET ?? ''}`,
        },
        body: JSON.stringify({ tenantId, projectId }),
      });
      await loadAlerts();
    } finally {
      setRunning(false);
    }
  }

  async function updateStatus(id: string, status: Alert['status']) {
    const supabase = getSupabaseClient();
    await supabase.from('autopilot_alerts').update({
      status,
      ...(status === 'resolved' ? { resolved_at: new Date().toISOString() } : {}),
    }).eq('id', id);
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status } : a));
    if (selected?.id === id) setSelected(prev => prev ? { ...prev, status } : null);
  }

  const counts = {
    critical: alerts.filter(a => a.severity === 'critical' && ['open','acknowledged'].includes(a.status)).length,
    high:     alerts.filter(a => a.severity === 'high'     && ['open','acknowledged'].includes(a.status)).length,
    medium:   alerts.filter(a => a.severity === 'medium'   && ['open','acknowledged'].includes(a.status)).length,
    low:      alerts.filter(a => a.severity === 'low'      && ['open','acknowledged'].includes(a.status)).length,
  };

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 800 }}>
            ⚡ Autopilot Alerts
          </h1>
          <p style={{ fontSize: 13, color: 'var(--sag-text-dim)', marginTop: 4 }}>
            AI-generated risk signals — review, acknowledge, and resolve
          </p>
        </div>
        <button className="btn btn-primary" onClick={triggerRun} disabled={running}>
          {running ? 'Running scan...' : '▶ Run Scan Now'}
        </button>
      </div>

      {/* Severity summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
        {[
          { sev: 'critical', label: 'Critical', count: counts.critical, color: 'var(--sag-critical)', bg: 'rgba(255,59,59,0.08)' },
          { sev: 'high',     label: 'High',     count: counts.high,     color: 'var(--sag-red)',      bg: 'rgba(217,64,64,0.08)' },
          { sev: 'medium',   label: 'Medium',   count: counts.medium,   color: 'var(--sag-yellow)',   bg: 'rgba(224,160,32,0.08)' },
          { sev: 'low',      label: 'Low',      count: counts.low,      color: 'var(--sag-text-dim)', bg: 'var(--sag-raised)' },
        ].map(s => (
          <button
            key={s.sev}
            onClick={() => setFilter(f => ({ ...f, severity: filter.severity === s.sev ? 'all' : s.sev }))}
            style={{
              background: filter.severity === s.sev ? s.bg : 'var(--sag-surface)',
              border: `1px solid ${filter.severity === s.sev ? s.color : 'var(--sag-border)'}`,
              borderRadius: 8,
              padding: '14px 16px',
              cursor: 'pointer',
              textAlign: 'left',
            }}
          >
            <div style={{ fontSize: 24, fontWeight: 800, color: s.color, fontFamily: 'var(--font-display)' }}>
              {s.count}
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, color: s.color, letterSpacing: 0.8, textTransform: 'uppercase', marginTop: 2 }}>
              {s.label}
            </div>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
        <select
          value={filter.status}
          onChange={e => setFilter(f => ({ ...f, status: e.target.value }))}
          style={{ fontSize: 12, padding: '6px 10px' }}
        >
          <option value="open,acknowledged">Active</option>
          <option value="open">Open</option>
          <option value="acknowledged">Acknowledged</option>
          <option value="resolved">Resolved</option>
          <option value="all">All Status</option>
        </select>

        <select
          value={filter.rule}
          onChange={e => setFilter(f => ({ ...f, rule: e.target.value }))}
          style={{ fontSize: 12, padding: '6px 10px' }}
        >
          <option value="all">All Rule Types</option>
          {Object.entries(RULE_LABELS).map(([k, v]) => (
            <option key={k} value={k}>{v}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <div style={{ color: 'var(--sag-text-dim)', fontSize: 13, padding: 24 }}>Loading alerts...</div>
      ) : alerts.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <div className="empty-state-icon"><span style={{ fontSize: 24 }}>✓</span></div>
            <div className="empty-state-title">No alerts matching filters</div>
            <p style={{ fontSize: 13, color: 'var(--sag-text-dim)' }}>
              All clear — or adjust your filters to see resolved/dismissed alerts.
            </p>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 16 }}>
          {/* Alert list */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {alerts.map(alert => {
              const sevColor =
                alert.severity === 'critical' ? 'var(--sag-critical)' :
                alert.severity === 'high'     ? 'var(--sag-red)' :
                alert.severity === 'medium'   ? 'var(--sag-yellow)' : 'var(--sag-muted)';

              return (
                <div
                  key={alert.id}
                  onClick={() => setSelected(selected?.id === alert.id ? null : alert)}
                  style={{
                    background: selected?.id === alert.id ? 'var(--sag-raised)' : 'var(--sag-surface)',
                    border: `1px solid ${selected?.id === alert.id ? sevColor : 'var(--sag-border)'}`,
                    borderLeft: `4px solid ${sevColor}`,
                    borderRadius: '0 8px 8px 0',
                    padding: '14px 16px',
                    cursor: 'pointer',
                    transition: 'all 0.1s',
                    opacity: alert.status === 'resolved' || alert.status === 'dismissed' ? 0.5 : 1,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
                        <span className={`badge ${
                          alert.severity === 'critical' ? 'badge-critical' :
                          alert.severity === 'high' ? 'badge-red' :
                          alert.severity === 'medium' ? 'badge-yellow' : 'badge-muted'
                        }`}>{alert.severity}</span>
                        <span className="badge badge-muted">{RULE_LABELS[alert.rule_code] ?? alert.rule_code}</span>
                        {alert.status === 'acknowledged' && <span className="badge badge-blue">ACK</span>}
                        {alert.status === 'resolved' && <span className="badge badge-green">Resolved</span>}
                        <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--sag-text)' }}>{alert.title}</span>
                      </div>
                      <div style={{ fontSize: 12, color: 'var(--sag-text-dim)' }}>{alert.summary}</div>
                      <div style={{ fontSize: 11, color: 'var(--sag-text-mute)', marginTop: 4 }}>
                        Detected {new Date(alert.last_detected_at).toLocaleString()}
                      </div>
                    </div>

                    {/* Actions */}
                    <div style={{ display: 'flex', gap: 6, flexShrink: 0 }} onClick={e => e.stopPropagation()}>
                      {alert.status === 'open' && (
                        <button className="btn btn-secondary btn-sm" onClick={() => updateStatus(alert.id, 'acknowledged')}>
                          ACK
                        </button>
                      )}
                      {['open','acknowledged'].includes(alert.status) && (
                        <button className="btn btn-ghost btn-sm" onClick={() => updateStatus(alert.id, 'resolved')}>
                          Resolve
                        </button>
                      )}
                      {['open','acknowledged'].includes(alert.status) && (
                        <button className="btn btn-ghost btn-sm" onClick={() => updateStatus(alert.id, 'dismissed')}>
                          Dismiss
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Detail panel */}
          {selected && (
            <div style={{
              width: 320,
              flexShrink: 0,
              background: 'var(--sag-surface)',
              border: '1px solid var(--sag-border)',
              borderRadius: 8,
              padding: 20,
              alignSelf: 'flex-start',
              position: 'sticky',
              top: 80,
            }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14 }}>
                Alert Detail
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { label: 'Severity',     value: selected.severity },
                  { label: 'Rule',         value: RULE_LABELS[selected.rule_code] ?? selected.rule_code },
                  { label: 'Entity Type',  value: selected.entity_type },
                  { label: 'Status',       value: selected.status },
                  { label: 'First seen',   value: new Date(selected.first_detected_at).toLocaleString() },
                  { label: 'Last seen',    value: new Date(selected.last_detected_at).toLocaleString() },
                ].map(row => (
                  <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                    <span style={{ color: 'var(--sag-text-dim)' }}>{row.label}</span>
                    <span style={{ fontWeight: 600, color: 'var(--sag-text)' }}>{row.value}</span>
                  </div>
                ))}

                {Object.keys(selected.metadata ?? {}).length > 0 && (
                  <>
                    <div style={{ height: 1, background: 'var(--sag-border)', margin: '4px 0' }} />
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--sag-text-dim)', textTransform: 'uppercase', letterSpacing: 0.8 }}>
                      Metadata
                    </div>
                    {Object.entries(selected.metadata).map(([k, v]) => (
                      <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                        <span style={{ color: 'var(--sag-text-dim)' }}>{k}</span>
                        <span style={{ fontWeight: 500, color: 'var(--sag-text)' }}>{String(v)}</span>
                      </div>
                    ))}
                  </>
                )}

                <div style={{ height: 1, background: 'var(--sag-border)', margin: '4px 0' }} />
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {selected.status === 'open' && (
                    <button className="btn btn-secondary" onClick={() => updateStatus(selected.id, 'acknowledged')}>
                      Acknowledge
                    </button>
                  )}
                  {['open','acknowledged'].includes(selected.status) && (
                    <button className="btn btn-primary" onClick={() => updateStatus(selected.id, 'resolved')}>
                      Mark Resolved
                    </button>
                  )}
                  {['open','acknowledged'].includes(selected.status) && (
                    <button className="btn btn-ghost" onClick={() => updateStatus(selected.id, 'dismissed')}>
                      Dismiss
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
