import { AppShell } from '../../../../components/AppShell';
import { AutopilotPanel } from '../../../../components/AutopilotPanel';
import { PageHeader } from '../../../../components/PageHeader';
import { requireAuth } from '../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../lib/supabaseAdmin';

async function getDashboardData(tenantId: string) {
  const [
    { count: projectCount },
    { count: openRfiCount },
    { count: alertCount },
    { data: recentProjects },
  ] = await Promise.all([
    supabaseAdmin.from('projects').select('*', { count: 'exact', head: true }).eq('tenant_id', tenantId).eq('status', 'active'),
    supabaseAdmin.from('rfis').select('*', { count: 'exact', head: true }).eq('tenant_id', tenantId).not('status', 'in', '("closed","answered","resolved")'),
    supabaseAdmin.from('autopilot_alerts').select('*', { count: 'exact', head: true }).eq('tenant_id', tenantId).in('status', ['open', 'acknowledged']),
    supabaseAdmin.from('projects').select('id,name,status,contract_value,project_number,pm_name').eq('tenant_id', tenantId).order('created_at', { ascending: false }).limit(5),
  ]);

  return {
    activeProjects: projectCount ?? 0,
    openRfis: openRfiCount ?? 0,
    openAlerts: alertCount ?? 0,
    recentProjects: recentProjects ?? [],
  };
}

export default async function DashboardPage({ params }: { params: { tenantSlug: string } }) {
  const { tenantSlug } = params;
  const session = await requireAuth(tenantSlug);

  // Get tenant
  const { data: tenant } = await supabaseAdmin
    .from('tenants')
    .select('id, name')
    .eq('slug', tenantSlug)
    .single();

  if (!tenant) return <div>Tenant not found</div>;

  const stats = await getDashboardData(tenant.id);

  const kpis = [
    { label: 'Active Projects',   value: stats.activeProjects, sub: 'in progress',     accent: 'var(--sag-blue-light)' },
    { label: 'Open Alerts',       value: stats.openAlerts,     sub: 'autopilot flagged',accent: stats.openAlerts > 0 ? 'var(--sag-critical)' : 'var(--sag-green)' },
    { label: 'Open RFIs',         value: stats.openRfis,       sub: 'awaiting response', accent: 'var(--sag-yellow)' },
    { label: 'Compliance Issues',  value: 0,                   sub: 'vendors/staff',    accent: 'var(--sag-clay-light)' },
  ];

  return (
    <AppShell tenantSlug={tenantSlug} tenantName={tenant.name}>
      <PageHeader
        title="Dashboard"
        subtitle={`Welcome back — ${new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}`}
        actions={
          <>
            <a href={`/${tenantSlug}/app/projects/new`} className="btn btn-primary">+ New Project</a>
          </>
        }
      />

      {/* KPI Row */}
      <div className="kpi-grid mb-6">
        {kpis.map(kpi => (
          <div key={kpi.label} className="kpi-card" style={{ '--accent': kpi.accent } as React.CSSProperties}>
            <div className="kpi-label">{kpi.label}</div>
            <div className="kpi-value">{kpi.value}</div>
            <div className="kpi-sub">{kpi.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 20 }}>
        {/* Recent Projects */}
        <div>
          <div className="card">
            <div className="card-header">
              <div className="card-title">Active Projects</div>
              <a href={`/${tenantSlug}/app/projects`} className="btn btn-ghost btn-sm">View All</a>
            </div>
            {stats.recentProjects.length === 0 ? (
              <div className="empty-state">
                <div className="empty-state-icon"><span style={{ fontSize: 20 }}>📁</span></div>
                <div className="empty-state-title">No projects yet</div>
                <p style={{ fontSize: 13, color: 'var(--sag-text-dim)' }}>Create your first project to get started.</p>
                <div style={{ marginTop: 12 }}>
                  <a href={`/${tenantSlug}/app/projects/new`} className="btn btn-primary btn-sm">+ Create Project</a>
                </div>
              </div>
            ) : (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Project</th>
                      <th>Status</th>
                      <th>PM</th>
                      <th>Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats.recentProjects.map((p: any) => (
                      <tr key={p.id}>
                        <td><span className="text-dim text-sm">{p.project_number ?? '—'}</span></td>
                        <td>
                          <a href={`/${tenantSlug}/app/projects/${p.id}`} style={{ color: 'var(--sag-blue-light)', textDecoration: 'none', fontWeight: 500 }}>
                            {p.name}
                          </a>
                        </td>
                        <td>
                          <span className={`badge ${p.status === 'active' ? 'badge-green' : 'badge-muted'}`}>
                            {p.status}
                          </span>
                        </td>
                        <td><span className="text-dim">{p.pm_name ?? '—'}</span></td>
                        <td>
                          <span style={{ fontWeight: 600 }}>
                            {p.contract_value ? `$${Number(p.contract_value).toLocaleString()}` : '—'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Quick Actions */}
          <div className="card mt-4">
            <div className="card-header">
              <div className="card-title">Quick Actions</div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
              {[
                { label: 'New RFI',        href: `/${tenantSlug}/app/rfis/new`,         icon: '?' },
                { label: 'Daily Log',      href: `/${tenantSlug}/app/field/logs/new`,   icon: '📋' },
                { label: 'Upload Docs',    href: `/${tenantSlug}/app/documents/upload`, icon: '📁' },
                { label: 'Change Order',   href: `/${tenantSlug}/app/change-orders/new`,icon: '↔' },
                { label: 'New Invoice',    href: `/${tenantSlug}/app/invoices/new`,      icon: '🧾' },
                { label: 'Field Issue',    href: `/${tenantSlug}/app/field/issues/new`, icon: '⚠' },
              ].map(action => (
                <a
                  key={action.label}
                  href={action.href}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 8,
                    padding: '10px 12px',
                    background: 'var(--sag-raised)',
                    border: '1px solid var(--sag-border)',
                    borderRadius: 6,
                    textDecoration: 'none',
                    fontSize: 13,
                    color: 'var(--sag-text)',
                    fontWeight: 500,
                    transition: 'all 0.1s',
                  }}
                >
                  <span>{action.icon}</span>
                  {action.label}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Right column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <AutopilotPanel
            tenantId={tenant.id}
            tenantSlug={tenantSlug}
            compact
          />

          {/* Compliance summary */}
          <div className="card">
            <div className="card-header">
              <div className="card-title">Compliance</div>
              <a href={`/${tenantSlug}/app/compliance`} className="btn btn-ghost btn-sm">View</a>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { label: 'COI Expiring 30d',    count: 0, color: 'var(--sag-yellow)' },
                { label: 'Missing W-9',         count: 0, color: 'var(--sag-red)' },
                { label: 'Employee Cert Alerts', count: 0, color: 'var(--sag-clay-light)' },
              ].map(item => (
                <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 13 }}>
                  <span style={{ color: 'var(--sag-text-dim)' }}>{item.label}</span>
                  <span style={{ fontWeight: 700, color: item.count > 0 ? item.color : 'var(--sag-green)' }}>
                    {item.count > 0 ? item.count : '✓'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
