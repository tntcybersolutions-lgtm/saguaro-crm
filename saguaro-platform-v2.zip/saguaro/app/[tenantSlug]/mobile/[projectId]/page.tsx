import { MobileFieldShell } from '../../../../../components/MobileFieldShell';
import { requireAuth } from '../../../../../lib/serverAuth';
import { supabaseAdmin } from '../../../../../lib/supabaseAdmin';

export default async function MobileProjectHome({ params }: { params: { tenantSlug: string; projectId: string } }) {
  const { tenantSlug, projectId } = params;
  await requireAuth(tenantSlug);

  const { data: project } = await supabaseAdmin
    .from('projects').select('*').eq('id', projectId).single();

  const [
    { count: openIssues },
    { count: openRfis },
    { count: todayLogs },
  ] = await Promise.all([
    supabaseAdmin.from('field_issues').select('*', { count: 'exact', head: true }).eq('project_id', projectId).not('status', 'in', '("closed","resolved")'),
    supabaseAdmin.from('rfis').select('*', { count: 'exact', head: true }).eq('project_id', projectId).not('status', 'in', '("closed","answered","resolved")'),
    supabaseAdmin.from('daily_logs').select('*', { count: 'exact', head: true }).eq('project_id', projectId).gte('log_date', new Date().toISOString().split('T')[0]),
  ]);

  const projectName = project?.name ?? 'Project';

  return (
    <MobileFieldShell tenantSlug={tenantSlug} projectId={projectId} projectName={projectName}>
      {/* Today's date */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 11, color: 'var(--sag-text-mute)', letterSpacing: 1, textTransform: 'uppercase' }}>
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 800, marginTop: 4 }}>
          {projectName}
        </h1>
      </div>

      {/* KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
        {[
          { label: 'Open Issues',   value: openIssues ?? 0,  color: openIssues ? 'var(--sag-red)' : 'var(--sag-green)', icon: '⚠' },
          { label: 'Open RFIs',     value: openRfis ?? 0,    color: openRfis ? 'var(--sag-yellow)' : 'var(--sag-green)', icon: '?' },
          { label: "Today's Logs",  value: todayLogs ?? 0,   color: 'var(--sag-blue-light)', icon: '📋' },
          { label: 'Status',        value: project?.status ?? '—', color: 'var(--sag-text-dim)', icon: '⬡' },
        ].map(kpi => (
          <div key={kpi.label} style={{
            background: 'var(--sag-surface)',
            border: '1px solid var(--sag-border)',
            borderRadius: 10,
            padding: '14px 14px',
          }}>
            <div style={{ fontSize: 20 }}>{kpi.icon}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 800, color: kpi.color, marginTop: 6 }}>
              {kpi.value}
            </div>
            <div style={{ fontSize: 11, color: 'var(--sag-text-dim)', marginTop: 2 }}>{kpi.label}</div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 1, textTransform: 'uppercase', color: 'var(--sag-text-mute)', marginBottom: 10 }}>
          Quick Actions
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {[
            { label: 'Add Photo',     href: `/${tenantSlug}/mobile/${projectId}/photos`,       icon: '📷', color: 'var(--sag-blue)' },
            { label: 'Daily Log',     href: `/${tenantSlug}/mobile/${projectId}/daily-logs`,   icon: '📋', color: 'var(--sag-clay)' },
            { label: 'Log Issue',     href: `/${tenantSlug}/mobile/${projectId}/field-issues`, icon: '⚠', color: 'var(--sag-red)' },
            { label: 'Schedule',      href: `/${tenantSlug}/mobile/${projectId}/schedule`,     icon: '📅', color: 'var(--sag-green)' },
          ].map(action => (
            <a key={action.label} href={action.href} style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              padding: '14px 14px',
              background: 'var(--sag-surface)',
              border: '1px solid var(--sag-border)',
              borderLeft: `3px solid ${action.color}`,
              borderRadius: '0 10px 10px 0',
              textDecoration: 'none',
              color: 'var(--sag-text)',
              fontSize: 14,
              fontWeight: 600,
            }}>
              <span style={{ fontSize: 20 }}>{action.icon}</span>
              {action.label}
            </a>
          ))}
        </div>
      </div>

      {/* Weather placeholder */}
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 24 }}>🌤</span>
          <div>
            <div style={{ fontWeight: 600 }}>Phoenix, AZ</div>
            <div style={{ fontSize: 12, color: 'var(--sag-text-dim)' }}>Weather integration available in production</div>
          </div>
        </div>
      </div>
    </MobileFieldShell>
  );
}
