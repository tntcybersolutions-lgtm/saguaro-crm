'use client';

import { useState } from 'react';
import { MobileFieldShell } from '../../../../../../components/MobileFieldShell';

export default function MobileDailyLogsPage({ params }: { params: { tenantSlug: string; projectId: string } }) {
  const { tenantSlug, projectId } = params;
  const [showForm, setShowForm] = useState(false);
  const [log, setLog] = useState({
    weather: 'clear',
    temp: '',
    work_performed: '',
    labor_count: '',
    delays: '',
    safety_notes: '',
  });

  return (
    <MobileFieldShell tenantSlug={tenantSlug} projectId={projectId} projectName="Project">
      <div style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 800 }}>Daily Logs</h2>
        <button className="btn btn-primary btn-sm" onClick={() => setShowForm(!showForm)}>
          {showForm ? '✕ Cancel' : '+ New Log'}
        </button>
      </div>

      {showForm && (
        <div className="card mb-4">
          <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>
            📋 {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="form-group">
              <label>Weather</label>
              <select value={log.weather} onChange={e => setLog(l => ({ ...l, weather: e.target.value }))}>
                <option value="clear">☀ Clear</option>
                <option value="cloudy">⛅ Cloudy</option>
                <option value="rain">🌧 Rain</option>
                <option value="wind">💨 Windy</option>
                <option value="storm">⛈ Storm</option>
              </select>
            </div>
            <div className="form-group">
              <label>Temp (°F)</label>
              <input type="number" value={log.temp} onChange={e => setLog(l => ({ ...l, temp: e.target.value }))} placeholder="75" />
            </div>
            <div className="form-group">
              <label>Workers on Site</label>
              <input type="number" value={log.labor_count} onChange={e => setLog(l => ({ ...l, labor_count: e.target.value }))} placeholder="0" />
            </div>
            <div className="form-group">
              <label>Work Performed</label>
              <textarea value={log.work_performed} onChange={e => setLog(l => ({ ...l, work_performed: e.target.value }))} placeholder="Describe work completed today..." style={{ minHeight: 80 }} />
            </div>
            <div className="form-group">
              <label>Delays / Issues</label>
              <textarea value={log.delays} onChange={e => setLog(l => ({ ...l, delays: e.target.value }))} placeholder="Any delays or issues?" style={{ minHeight: 60 }} />
            </div>
            <div className="form-group">
              <label>Safety Notes</label>
              <textarea value={log.safety_notes} onChange={e => setLog(l => ({ ...l, safety_notes: e.target.value }))} placeholder="Safety observations..." style={{ minHeight: 60 }} />
            </div>
            <button className="btn btn-primary" style={{ justifyContent: 'center' }}>
              Save Daily Log
            </button>
          </div>
        </div>
      )}

      <div className="empty-state">
        <div className="empty-state-icon"><span style={{ fontSize: 20 }}>📋</span></div>
        <div className="empty-state-title">No logs yet today</div>
        <p style={{ fontSize: 13, color: 'var(--sag-text-dim)' }}>Tap "New Log" to record today's field activity.</p>
      </div>
    </MobileFieldShell>
  );
}
