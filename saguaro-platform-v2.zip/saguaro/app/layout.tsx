import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Saguaro Construction Intelligence Platform',
  description: 'Enterprise construction management — one system, three portals.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>{children}</body>
    </html>
  );
}
