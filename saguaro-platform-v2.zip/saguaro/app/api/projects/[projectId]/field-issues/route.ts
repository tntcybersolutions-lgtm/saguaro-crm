import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabase } from '../../../../../lib/serverAuth';

export async function POST(req: NextRequest, { params }: { params: { projectId: string } }) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();

  // Auto-number
  const { count } = await supabase.from('field_issues').select('*', { count: 'exact', head: true }).eq('project_id', params.projectId);

  const { data, error } = await supabase.from('field_issues').insert({
    project_id: params.projectId,
    number: (count ?? 0) + 1,
    title: body.title,
    category: body.category,
    severity: body.severity,
    location: body.location,
    description: body.description,
    status: 'open',
    created_by: user.id,
  }).select().single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
