import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabase } from '../../../../../lib/serverAuth';

export async function POST(req: NextRequest, { params }: { params: { projectId: string } }) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const today = new Date().toISOString().split('T')[0];

  const { data, error } = await supabase.from('daily_logs').insert({
    project_id: params.projectId,
    log_date: today,
    weather_conditions: body.conditions,
    temp_low: body.tempLow ? parseInt(body.tempLow) : null,
    temp_high: body.tempHigh ? parseInt(body.tempHigh) : null,
    manpower_count: body.manpower ? parseInt(body.manpower) : 0,
    work_performed: body.workPerformed,
    delays: body.delays,
    safety_notes: body.safetyNotes,
    created_by: user.id,
    is_submitted: false,
  }).select().single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
