import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '../../../lib/supabaseAdmin';

export async function POST(request: NextRequest) {
  const { name, slug, email, password, fullName } = await request.json();

  if (!name || !slug || !email || !password || !fullName) {
    return NextResponse.json({ error: 'All fields required' }, { status: 400 });
  }

  // Create auth user
  const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });

  if (authError) return NextResponse.json({ error: authError.message }, { status: 400 });

  // Create tenant
  const { data: tenant, error: tenantError } = await supabaseAdmin
    .from('tenants')
    .insert({ name, slug })
    .select('id')
    .single();

  if (tenantError) return NextResponse.json({ error: tenantError.message }, { status: 400 });

  // Create user profile with master role
  const { error: profileError } = await supabaseAdmin.from('users').insert({
    id: authUser.user.id,
    tenant_id: tenant.id,
    email,
    full_name: fullName,
    role: 'master',
    portal: 'internal',
    is_master: true,
  });

  if (profileError) return NextResponse.json({ error: profileError.message }, { status: 400 });

  return NextResponse.json({ ok: true, tenantId: tenant.id });
}
