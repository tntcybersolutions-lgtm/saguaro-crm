-- ============================================================
-- SAGUARO CONSTRUCTION INTELLIGENCE PLATFORM
-- Migration 001: Core Foundation
-- ============================================================

create extension if not exists pgcrypto;
create extension if not exists "uuid-ossp";

-- ──────────────────────────────────────────────
-- ENUMS
-- ──────────────────────────────────────────────
do $$ begin create type portal_type as enum ('internal','customer','trade'); exception when duplicate_object then null; end $$;
do $$ begin create type user_role as enum ('master','owner_exec','pm','superintendent','estimator','dispatcher','accounting','warehouse','tech','quality','safety','admin','customer','subcontractor','vendor'); exception when duplicate_object then null; end $$;
do $$ begin create type project_status as enum ('lead','precon','active','punch','closeout','complete','archived'); exception when duplicate_object then null; end $$;
do $$ begin create type contract_type as enum ('lump_sum','gmp','cost_plus','unit_price','time_material'); exception when duplicate_object then null; end $$;
do $$ begin create type alert_severity as enum ('info','low','medium','high','critical'); exception when duplicate_object then null; end $$;
do $$ begin create type alert_status as enum ('open','acknowledged','resolved','dismissed'); exception when duplicate_object then null; end $$;
do $$ begin create type doc_visibility as enum ('internal','customer','trade','public'); exception when duplicate_object then null; end $$;

-- ──────────────────────────────────────────────
-- HELPER FUNCTIONS
-- ──────────────────────────────────────────────
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

create or replace function public.generate_project_number()
returns text language plpgsql as $$
declare
  next_num integer;
begin
  select coalesce(max(cast(regexp_replace(project_number,'[^0-9]','','g') as integer)),1000) + 1
  into next_num from public.projects;
  return 'PRJ-' || lpad(next_num::text, 5, '0');
end;
$$;

-- ──────────────────────────────────────────────
-- TENANTS (multi-tenant foundation)
-- ──────────────────────────────────────────────
create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  logo_url text,
  primary_color text default '#1E4D8C',
  accent_color text default '#C9663C',
  domain_internal text,
  domain_customer text,
  domain_trade text,
  settings jsonb not null default '{}',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- USERS (profile layer on top of Supabase auth)
-- ──────────────────────────────────────────────
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  tenant_id uuid references public.tenants(id),
  email text not null,
  full_name text not null,
  phone text,
  title text,
  avatar_url text,
  role user_role not null default 'customer',
  portal portal_type not null default 'customer',
  is_master boolean not null default false,
  is_active boolean not null default true,
  mfa_enabled boolean not null default false,
  last_sign_in_at timestamptz,
  preferences jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- PROJECTS
-- ──────────────────────────────────────────────
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_number text not null,
  name text not null,
  description text,
  status project_status not null default 'precon',
  type text,                          -- 'ground_up', 'renovation', 'service', 'design_build'
  site_address text,
  site_city text,
  site_state text,
  site_zip text,
  site_lat numeric,
  site_lng numeric,
  client_id uuid,                     -- references contacts
  pm_id uuid references public.users(id),
  super_id uuid references public.users(id),
  contract_type contract_type,
  contract_value numeric(15,2),
  retainage_pct numeric(5,2) default 10,
  bonding boolean default false,
  start_date date,
  target_finish_date date,
  actual_finish_date date,
  health_score integer check (health_score between 0 and 100),
  publish_to_portfolio boolean default false,
  is_archived boolean default false,
  tags text[],
  metadata jsonb not null default '{}',
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- PROJECT MEMBERS
-- ──────────────────────────────────────────────
create table if not exists public.project_members (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  role text not null,                 -- project-level role override
  can_view boolean default true,
  can_edit boolean default false,
  can_approve boolean default false,
  added_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  unique (project_id, user_id)
);

-- ──────────────────────────────────────────────
-- AUDIT LOGS (non-negotiable)
-- ──────────────────────────────────────────────
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  user_id uuid references public.users(id),
  impersonated_by uuid references public.users(id),  -- Robert impersonation
  portal portal_type,
  action text not null,               -- 'create','update','delete','approve','export','login','override'
  table_name text,
  record_id uuid,
  old_data jsonb,
  new_data jsonb,
  diff jsonb,
  ip_address inet,
  user_agent text,
  override_reason text,               -- when Robert overrides a gate
  created_at timestamptz not null default now()
);

create index if not exists idx_audit_logs_tenant_created on public.audit_logs(tenant_id, created_at desc);
create index if not exists idx_audit_logs_record on public.audit_logs(table_name, record_id);

-- ──────────────────────────────────────────────
-- TENANT INVITES
-- ──────────────────────────────────────────────
create table if not exists public.tenant_invites (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  email text not null,
  role user_role not null,
  portal portal_type not null,
  token text not null unique default encode(gen_random_bytes(32),'hex'),
  invited_by uuid references public.users(id),
  expires_at timestamptz not null default now() + interval '7 days',
  accepted_at timestamptz,
  created_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- ACTIVITY EVENTS
-- ──────────────────────────────────────────────
create table if not exists public.activity_events (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid references public.projects(id),
  user_id uuid references public.users(id),
  event_type text not null,
  entity_type text,
  entity_id uuid,
  summary text not null,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index if not exists idx_activity_events_project on public.activity_events(project_id, created_at desc);

-- ──────────────────────────────────────────────
-- NOTIFICATIONS
-- ──────────────────────────────────────────────
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  user_id uuid not null references public.users(id),
  project_id uuid references public.projects(id),
  alert_id uuid,
  title text not null,
  body text,
  severity alert_severity not null default 'info',
  channel text not null default 'in_app',  -- 'in_app','email','teams','sms','push'
  is_read boolean not null default false,
  read_at timestamptz,
  action_url text,
  created_at timestamptz not null default now()
);

create index if not exists idx_notifications_user on public.notifications(user_id, is_read, created_at desc);

-- ──────────────────────────────────────────────
-- TRIGGERS
-- ──────────────────────────────────────────────
do $$ declare
  t text;
begin
  foreach t in array array['tenants','users','projects','project_members'] loop
    execute format('drop trigger if exists trg_%s_updated_at on public.%s', t, t);
    execute format('create trigger trg_%s_updated_at before update on public.%s for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

-- ──────────────────────────────────────────────
-- RLS (Row Level Security)
-- ──────────────────────────────────────────────
alter table public.projects enable row level security;
alter table public.users enable row level security;
alter table public.audit_logs enable row level security;
alter table public.notifications enable row level security;

-- Service role bypasses all RLS
create policy "service_role_all_projects" on public.projects using (true) with check (true);
create policy "service_role_all_users" on public.users using (true) with check (true);
