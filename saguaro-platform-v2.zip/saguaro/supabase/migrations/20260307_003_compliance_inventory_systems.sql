-- ============================================================
-- SAGUARO CONSTRUCTION INTELLIGENCE PLATFORM
-- Migration 003: Compliance, Inventory, Systems, Autopilot
-- ============================================================

-- ──────────────────────────────────────────────
-- VENDOR COMPLIANCE
-- ──────────────────────────────────────────────
create table if not exists public.vendor_compliance (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  company_id uuid not null references public.companies(id),
  doc_type text not null,             -- 'coi','w9','tax_cert','prequal','license'
  status text default 'missing',     -- 'missing','pending','active','expiring','expired','rejected'
  doc_id uuid references public.documents(id),
  expiration_date date,
  effective_date date,
  coverage_amount numeric(12,2),      -- for COI
  notes text,
  verified_by uuid references public.users(id),
  verified_at timestamptz,
  gate_status text default 'clear',  -- 'clear','warning','blocked'
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, doc_type)
);

-- ──────────────────────────────────────────────
-- EMPLOYEE COMPLIANCE
-- ──────────────────────────────────────────────
create table if not exists public.employee_compliance (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  user_id uuid not null references public.users(id),
  cert_type text not null,            -- 'osha10','osha30','first_aid','forklift','license','other'
  cert_name text not null,
  status text default 'active',
  doc_id uuid references public.documents(id),
  issued_date date,
  expiration_date date,
  issuing_body text,
  cert_number text,
  block_dispatch boolean default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- INVENTORY
-- ──────────────────────────────────────────────
create table if not exists public.inventory_locations (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  type text not null,                 -- 'warehouse','truck','jobsite','rma'
  name text not null,
  address text,
  responsible_user_id uuid references public.users(id),
  is_active boolean default true,
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_catalog (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  sku text not null,
  description text not null,
  category text,
  unit text default 'ea',
  unit_cost numeric(10,2),
  default_vendor_id uuid references public.companies(id),
  reorder_point numeric(10,2) default 0,
  substitutes text[],
  barcode text,
  qr_code text,
  is_active boolean default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, sku)
);

create table if not exists public.inventory_stock (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  item_id uuid not null references public.inventory_catalog(id),
  location_id uuid not null references public.inventory_locations(id),
  quantity_on_hand numeric(10,2) default 0,
  quantity_reserved numeric(10,2) default 0,
  quantity_available numeric(10,2) generated always as (quantity_on_hand - quantity_reserved) stored,
  last_counted_at timestamptz,
  updated_at timestamptz not null default now(),
  unique (item_id, location_id)
);

create table if not exists public.stock_moves (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  item_id uuid not null references public.inventory_catalog(id),
  from_location_id uuid references public.inventory_locations(id),
  to_location_id uuid references public.inventory_locations(id),
  project_id uuid references public.projects(id),
  move_type text not null,            -- 'receipt','issue','transfer','return','adjustment','reservation'
  quantity numeric(10,2) not null,
  unit_cost numeric(10,2),
  reference text,
  reason text,
  approved_by uuid references public.users(id),
  created_by uuid not null references public.users(id),
  created_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- TOOLS & EQUIPMENT
-- ──────────────────────────────────────────────
create table if not exists public.tools (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  asset_tag text not null,
  qr_code text,
  type text not null,
  make text,
  model text,
  serial_number text,
  purchase_date date,
  purchase_cost numeric(10,2),
  location_id uuid references public.inventory_locations(id),
  assigned_to uuid references public.users(id),
  assigned_project_id uuid references public.projects(id),
  status text default 'available',   -- 'available','checked_out','maintenance','retired'
  maintenance_interval_days integer,
  last_maintenance_date date,
  next_maintenance_date date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, asset_tag)
);

-- ──────────────────────────────────────────────
-- VEHICLES
-- ──────────────────────────────────────────────
create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  asset_tag text,
  make text not null,
  model text not null,
  year integer,
  vin text,
  license_plate text,
  assigned_user_id uuid references public.users(id),
  insurance_policy text,
  insurance_expiry date,
  insurance_doc_id uuid references public.documents(id),
  registration_expiry date,
  truck_stock_baseline jsonb default '[]',  -- [{sku, qty}]
  odometer integer,
  maintenance_notes text,
  is_active boolean default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- SYSTEMS (LV/Networking/Smart Building)
-- ──────────────────────────────────────────────
create table if not exists public.project_systems (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  -- Internet / ISP
  isp_type text,
  isp_provider text,
  upload_speed_mbps integer,
  download_speed_mbps integer,
  sla text,
  failover_method text,
  -- Network Infrastructure
  router_model text,
  mdf_location text,
  idf_locations jsonb default '[]',
  switch_config jsonb default '[]',   -- [{location, model, ports, poe_budget, vlans}]
  vlan_plan jsonb default '[]',
  redundancy_config text,
  -- Cabling
  cable_library jsonb default '[]',   -- [{type, spec, qty, runs}]
  fiber_spec jsonb default '{}',
  port_count integer,
  patch_panels integer,
  rack_count integer,
  -- WiFi
  wifi_aps jsonb default '[]',        -- [{model, location, floor, pin_x, pin_y}]
  -- CCTV
  cctv_cameras jsonb default '[]',    -- [{type, location, resolution, retention_days, nvr_channel}]
  nvr_model text,
  -- Access Control
  access_doors jsonb default '[]',
  -- Voice / Intercom
  voice_zones jsonb default '[]',
  pa_zones jsonb default '[]',
  -- AV
  av_zones jsonb default '[]',
  -- Smart Building
  automation_rules jsonb default '[]',
  command_center jsonb default '{}',
  -- Meta
  design_notes text,
  last_updated_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (project_id)
);

-- ──────────────────────────────────────────────
-- ASSETS (installed devices become assets)
-- ──────────────────────────────────────────────
create table if not exists public.assets (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid references public.projects(id),
  client_id uuid references public.contacts(id),
  asset_tag text,
  qr_code text,
  name text not null,
  category text,
  system_type text,
  make text,
  model text,
  serial_number text,
  mac_address text,
  ip_address inet,
  firmware_version text,
  install_date date,
  install_location text,
  floor_level text,
  room text,
  warranty_expires date,
  warranty_doc_id uuid references public.documents(id),
  service_schedule text,
  status text default 'active',
  notes text,
  inventory_item_id uuid references public.inventory_catalog(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- SERVICE TICKETS
-- ──────────────────────────────────────────────
create table if not exists public.service_tickets (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  ticket_number text not null,
  client_id uuid references public.contacts(id),
  project_id uuid references public.projects(id),
  category text,                      -- 'service','warranty','pm','emergency'
  system_type text,
  priority text default 'normal',
  sla_hours integer,
  title text not null,
  description text,
  status text default 'open',
  related_assets uuid[],
  scheduled_window_start timestamptz,
  scheduled_window_end timestamptz,
  assigned_tech_id uuid references public.users(id),
  assigned_team text[],
  dispatch_notes text,
  resolution text,
  closed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- PROCUREMENT
-- ──────────────────────────────────────────────
create table if not exists public.procurement_items (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  item_description text not null,
  quantity numeric(10,2),
  unit text,
  needed_by_date date,
  lead_time_days integer,
  expected_ship_date date,
  expected_delivery_date date,
  vendor_id uuid references public.companies(id),
  cost_code_id uuid references public.cost_codes(id),
  status text default 'pending',     -- 'pending','ordered','in_transit','received','damaged'
  is_long_lead boolean default false,
  risk_flag boolean default false,
  delivery_appointment timestamptz,
  received_qty numeric(10,2),
  received_date date,
  damage_noted boolean default false,
  damage_notes text,
  po_number text,
  unit_cost numeric(10,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- AUTOPILOT (from engine.ts)
-- ──────────────────────────────────────────────
create extension if not exists pgcrypto;

do $$ begin create type autopilot_severity as enum ('low','medium','high','critical'); exception when duplicate_object then null; end $$;
do $$ begin create type autopilot_alert_status as enum ('open','acknowledged','resolved','dismissed'); exception when duplicate_object then null; end $$;

create table if not exists public.autopilot_rule_settings (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  rule_code text not null,
  is_enabled boolean not null default true,
  thresholds jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, rule_code)
);

create table if not exists public.autopilot_runs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid references public.projects(id),
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  status text not null default 'running' check (status in ('running','succeeded','failed')),
  summary jsonb not null default '{}',
  error text
);

create table if not exists public.autopilot_alerts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid references public.projects(id),
  entity_type text not null check (entity_type in ('rfi','invoice','schedule_task','field_issue','project')),
  entity_id uuid,
  rule_code text not null,
  title text not null,
  summary text not null,
  severity autopilot_severity not null,
  status autopilot_alert_status not null default 'open',
  fingerprint text not null,
  metadata jsonb not null default '{}',
  first_detected_at timestamptz not null default now(),
  last_detected_at timestamptz not null default now(),
  resolved_at timestamptz,
  assigned_to uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, fingerprint)
);

create index if not exists idx_autopilot_alerts_tenant_status on public.autopilot_alerts(tenant_id, status, severity);
create index if not exists idx_autopilot_alerts_project on public.autopilot_alerts(project_id, last_detected_at desc);
create index if not exists idx_autopilot_runs_tenant on public.autopilot_runs(tenant_id, started_at desc);

create or replace view public.autopilot_project_risk_summary as
select
  tenant_id,
  project_id,
  count(*) filter (where status in ('open','acknowledged')) as open_count,
  count(*) filter (where status in ('open','acknowledged') and severity = 'high') as high_count,
  count(*) filter (where status in ('open','acknowledged') and severity = 'critical') as critical_count,
  max(last_detected_at) as last_detected_at
from public.autopilot_alerts
group by 1, 2;

-- ──────────────────────────────────────────────
-- ASSEMBLIES LIBRARY
-- ──────────────────────────────────────────────
create table if not exists public.assemblies (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  name text not null,
  category text,
  system_type text,
  description text,
  bom_lines jsonb default '[]',       -- [{sku, qty_formula, unit_cost}]
  labor_lines jsonb default '[]',     -- [{role, hours, rate_rule}]
  tools_required jsonb default '[]',
  qa_checklist_id uuid,
  commissioning_checklist_id uuid,
  closeout_requirements text,
  version integer default 1,
  is_active boolean default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- SAFETY
-- ──────────────────────────────────────────────
create table if not exists public.safety_incidents (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  incident_type text not null,        -- 'injury','near_miss','property_damage','environmental'
  severity text not null,             -- 'minor','moderate','serious','critical'
  incident_date timestamptz not null,
  location text,
  description text not null,
  injured_party text,
  witness_names text[],
  immediate_actions text,
  root_cause text,
  corrective_actions jsonb default '[]',
  osha_recordable boolean default false,
  reported_by uuid references public.users(id),
  reviewed_by uuid references public.users(id),
  reviewed_at timestamptz,
  status text default 'open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.toolbox_talks (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  topic text not null,
  conducted_at timestamptz not null,
  facilitator_id uuid references public.users(id),
  attendees jsonb default '[]',       -- [{name, company, signature_url}]
  notes text,
  doc_id uuid references public.documents(id),
  created_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- QUALITY
-- ──────────────────────────────────────────────
create table if not exists public.qc_checklists (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  template_name text not null,
  category text,
  items jsonb not null default '[]',  -- [{item, result, notes, evidence_url}]
  completed_by uuid references public.users(id),
  completed_at timestamptz,
  passed boolean,
  created_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- INDEXES
-- ──────────────────────────────────────────────
create index if not exists idx_vendor_compliance_company on public.vendor_compliance(company_id, doc_type);
create index if not exists idx_vendor_compliance_expiry on public.vendor_compliance(expiration_date) where status = 'active';
create index if not exists idx_stock_moves_project on public.stock_moves(project_id, created_at desc);
create index if not exists idx_inventory_stock_location on public.inventory_stock(location_id);
create index if not exists idx_assets_project on public.assets(project_id, status);
create index if not exists idx_procurement_project on public.procurement_items(project_id, status);
create index if not exists idx_service_tickets_client on public.service_tickets(client_id, status);

-- ──────────────────────────────────────────────
-- UPDATED_AT TRIGGERS
-- ──────────────────────────────────────────────
do $$ declare t text; begin
  foreach t in array array[
    'vendor_compliance','employee_compliance','inventory_catalog','inventory_stock',
    'tools','vehicles','project_systems','assets','service_tickets','procurement_items',
    'assemblies','safety_incidents','qc_checklists','autopilot_rule_settings','autopilot_alerts',
    'companies','contacts'
  ] loop
    execute format('drop trigger if exists trg_%s_updated_at on public.%s', t, t);
    execute format('create trigger trg_%s_updated_at before update on public.%s for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;
