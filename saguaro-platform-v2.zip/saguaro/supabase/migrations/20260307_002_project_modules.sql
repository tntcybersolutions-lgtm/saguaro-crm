-- ============================================================
-- SAGUARO CONSTRUCTION INTELLIGENCE PLATFORM
-- Migration 002: Project Modules
-- ============================================================

-- ──────────────────────────────────────────────
-- CONTACTS / COMPANIES
-- ──────────────────────────────────────────────
create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  name text not null,
  type text not null,                 -- 'client','sub','vendor','supplier'
  website text,
  address text,
  city text,
  state text,
  zip text,
  phone text,
  license_number text,
  license_expiry date,
  notes text,
  is_active boolean default true,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  company_id uuid references public.companies(id),
  first_name text not null,
  last_name text not null,
  email text,
  phone text,
  title text,
  is_primary boolean default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- COST CODES
-- ──────────────────────────────────────────────
create table if not exists public.cost_codes (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid references public.projects(id),
  code text not null,
  description text not null,
  phase text,
  trade text,
  budget numeric(15,2) default 0,
  budget_revisions numeric(15,2) default 0,
  committed numeric(15,2) default 0,
  actuals numeric(15,2) default 0,
  forecast numeric(15,2) default 0,
  eac numeric(15,2) generated always as (budget + budget_revisions + committed + actuals) stored,
  variance numeric(15,2) generated always as (budget - (committed + actuals)) stored,
  variance_note text,
  retainage_held numeric(15,2) default 0,
  is_locked boolean default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- RFIs
-- ──────────────────────────────────────────────
do $$ begin create type rfi_status as enum ('draft','submitted','under_review','answered','closed'); exception when duplicate_object then null; end $$;

create table if not exists public.rfis (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  number integer not null,
  subject text not null,
  question text not null,
  spec_section text,
  drawing_refs text[],
  drawing_pin jsonb,                  -- {sheet_id, x, y}
  status rfi_status not null default 'draft',
  priority text default 'normal',
  submitted_by uuid references public.users(id),
  assigned_to uuid references public.users(id),
  due_date date,
  response_due_date date,
  response text,
  responded_by uuid references public.users(id),
  responded_at timestamptz,
  schedule_impact boolean default false,
  cost_impact boolean default false,
  cost_impact_amount numeric(12,2),
  tags text[],
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (project_id, number)
);

-- ──────────────────────────────────────────────
-- INVOICES
-- ──────────────────────────────────────────────
do $$ begin create type invoice_status as enum ('draft','pending','approved','paid','void','cancelled'); exception when duplicate_object then null; end $$;

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  invoice_number text not null,
  company_id uuid references public.companies(id),
  type text not null default 'sub',  -- 'sub','vendor','owner'
  status invoice_status not null default 'draft',
  amount numeric(15,2) not null default 0,
  retainage_pct numeric(5,2) default 0,
  retainage_held numeric(15,2) default 0,
  net_due numeric(15,2) generated always as (amount - retainage_held) stored,
  invoice_date date,
  due_date date,
  period_start date,
  period_end date,
  cost_code_id uuid references public.cost_codes(id),
  approved_by uuid references public.users(id),
  approved_at timestamptz,
  paid_at timestamptz,
  payment_ref text,
  notes text,
  lien_waiver_required boolean default true,
  lien_waiver_received boolean default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- CHANGE ORDERS
-- ──────────────────────────────────────────────
do $$ begin create type co_status as enum ('draft','pending_internal','pending_client','approved','rejected','void'); exception when duplicate_object then null; end $$;

create table if not exists public.change_requests (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  number integer not null,
  source text,                        -- 'owner','field','design','rfi','unforeseen'
  title text not null,
  description text,
  status text default 'open',
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.pcos (                  -- Potential Change Orders
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  change_request_id uuid references public.change_requests(id),
  number integer not null,
  title text not null,
  description text,
  status text default 'draft',
  labor_cost numeric(12,2) default 0,
  material_cost numeric(12,2) default 0,
  equipment_cost numeric(12,2) default 0,
  sub_cost numeric(12,2) default 0,
  markup_pct numeric(5,2) default 15,
  total_cost numeric(12,2),
  schedule_impact_days integer default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.change_orders (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  pco_id uuid references public.pcos(id),
  number integer not null,
  title text not null,
  description text,
  status co_status not null default 'draft',
  amount numeric(12,2) not null default 0,
  time_extension_days integer default 0,
  client_id uuid references public.contacts(id),
  submitted_at timestamptz,
  approved_by uuid references public.users(id),
  approved_at timestamptz,
  client_signed_at timestamptz,
  signature_data text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- SCHEDULE TASKS
-- ──────────────────────────────────────────────
do $$ begin create type task_status as enum ('not_started','in_progress','complete','on_hold','cancelled'); exception when duplicate_object then null; end $$;

create table if not exists public.schedule_tasks (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  parent_id uuid references public.schedule_tasks(id),
  name text not null,
  phase text,
  trade text,
  cost_code_id uuid references public.cost_codes(id),
  status task_status not null default 'not_started',
  planned_start date,
  planned_finish date,
  actual_start date,
  actual_finish date,
  baseline_start date,
  baseline_finish date,
  percent_complete numeric(5,2) default 0 check (percent_complete between 0 and 100),
  duration_days integer,
  is_critical_path boolean default false,
  is_milestone boolean default false,
  assigned_to uuid[],
  assigned_company_id uuid references public.companies(id),
  notes text,
  constraints_json jsonb default '[]',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.schedule_dependencies (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id),
  predecessor_id uuid not null references public.schedule_tasks(id) on delete cascade,
  successor_id uuid not null references public.schedule_tasks(id) on delete cascade,
  type text default 'FS',             -- FS, FF, SS, SF
  lag_days integer default 0,
  unique (predecessor_id, successor_id)
);

-- ──────────────────────────────────────────────
-- FIELD ISSUES / PUNCH
-- ──────────────────────────────────────────────
create table if not exists public.field_issues (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  number integer not null,
  title text not null,
  description text,
  category text,                      -- 'punch','deficiency','safety','quality','ncr'
  severity text default 'medium',
  status text not null default 'open',
  location text,
  floor_level text,
  room text,
  assigned_to uuid references public.users(id),
  assigned_company_id uuid references public.companies(id),
  due_date date,
  target_date date,
  resolved_at timestamptz,
  resolved_by uuid references public.users(id),
  root_cause text,
  corrective_action text,
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- DAILY LOGS
-- ──────────────────────────────────────────────
create table if not exists public.daily_logs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  log_date date not null,
  created_by uuid references public.users(id),
  weather_conditions text,
  temp_high integer,
  temp_low integer,
  wind_speed text,
  precipitation text,
  work_performed text,
  manpower_count integer default 0,
  labor_by_trade jsonb default '[]',  -- [{trade, company, headcount, hours}]
  visitors jsonb default '[]',
  deliveries jsonb default '[]',
  delays text,
  delay_type text,
  safety_notes text,
  general_notes text,
  is_submitted boolean default false,
  submitted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (project_id, log_date)
);

-- ──────────────────────────────────────────────
-- PHOTOS
-- ──────────────────────────────────────────────
create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  daily_log_id uuid references public.daily_logs(id),
  storage_path text not null,
  signed_url text,
  signed_url_expires_at timestamptz,
  file_name text not null,
  file_size integer,
  mime_type text,
  width integer,
  height integer,
  caption text,
  tags text[],
  location text,
  floor_level text,
  room text,
  taken_at timestamptz,
  taken_by uuid references public.users(id),
  visibility doc_visibility default 'internal',
  annotation_data jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- DOCUMENTS / DRAWINGS
-- ──────────────────────────────────────────────
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid references public.projects(id),
  folder text,
  file_name text not null,
  storage_path text not null,
  version integer default 1,
  is_current_version boolean default true,
  parent_doc_id uuid references public.documents(id),
  doc_type text,                      -- 'drawing','spec','submittal','rfi','contract','permit','photo','other'
  discipline text,                    -- 'architectural','structural','mep','civil','lv','other'
  sheet_number text,
  sheet_title text,
  revision text,
  is_current_set boolean default false,
  is_locked boolean default false,
  visibility doc_visibility default 'internal',
  uploaded_by uuid references public.users(id),
  file_size integer,
  mime_type text,
  virus_scanned boolean default false,
  tags text[],
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- SUBMITTALS
-- ──────────────────────────────────────────────
do $$ begin create type submittal_status as enum ('draft','submitted','under_review','approved','approved_as_noted','revise_resubmit','rejected'); exception when duplicate_object then null; end $$;

create table if not exists public.submittals (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  number text not null,
  spec_section text,
  title text not null,
  company_id uuid references public.companies(id),
  status submittal_status not null default 'draft',
  revision integer default 1,
  required_by date,
  distribution jsonb default '[]',
  reviewer_id uuid references public.users(id),
  reviewed_at timestamptz,
  review_notes text,
  triggers_procurement boolean default false,
  procurement_triggered_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- BID PACKAGES
-- ──────────────────────────────────────────────
create table if not exists public.bid_packages (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  number integer not null,
  title text not null,
  trade text,
  scope_summary text,
  status text default 'draft',       -- 'draft','invitations_sent','quotes_received','leveling','awarded','void'
  due_date timestamptz,
  bid_walkthrough_date timestamptz,
  awarded_to uuid references public.companies(id),
  awarded_amount numeric(12,2),
  awarded_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.bid_invitations (
  id uuid primary key default gen_random_uuid(),
  bid_package_id uuid not null references public.bid_packages(id),
  company_id uuid not null references public.companies(id),
  contact_id uuid references public.contacts(id),
  status text default 'invited',     -- 'invited','viewed','declined','submitted'
  sent_at timestamptz,
  viewed_at timestamptz,
  responded_at timestamptz,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.bid_submissions (
  id uuid primary key default gen_random_uuid(),
  bid_package_id uuid not null references public.bid_packages(id),
  company_id uuid not null references public.companies(id),
  amount numeric(12,2) not null,
  is_alternate boolean default false,
  notes text,
  exclusions text,
  submitted_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- PERMITS & INSPECTIONS
-- ──────────────────────────────────────────────
create table if not exists public.permits (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  permit_type text not null,
  permit_number text,
  issuing_authority text,
  status text default 'pending',     -- 'pending','submitted','approved','active','expired','void'
  applied_date date,
  issued_date date,
  expiration_date date,
  fee numeric(10,2),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.inspections (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  permit_id uuid references public.permits(id),
  inspection_type text not null,
  scheduled_date date,
  completed_date date,
  result text,                        -- 'passed','failed','partial','cancelled'
  inspector_name text,
  agency text,
  notes text,
  corrective_tasks text[],
  next_inspection_id uuid references public.inspections(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- MEETINGS
-- ──────────────────────────────────────────────
create table if not exists public.meetings (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  meeting_type text not null,         -- 'oac','internal','safety','kickoff','closeout'
  title text not null,
  scheduled_at timestamptz not null,
  location text,
  virtual_link text,
  attendees jsonb default '[]',
  agenda text,
  minutes text,
  action_items jsonb default '[]',
  decisions_log jsonb default '[]',
  published_at timestamptz,
  published_by uuid references public.users(id),
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- TRANSMITTALS
-- ──────────────────────────────────────────────
create table if not exists public.transmittals (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  number integer not null,
  title text not null,
  to_company_id uuid references public.companies(id),
  to_contact_id uuid references public.contacts(id),
  from_user_id uuid references public.users(id),
  purpose text,
  notes text,
  document_ids uuid[],
  sent_at timestamptz,
  acknowledged_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- CLOSEOUT
-- ──────────────────────────────────────────────
create table if not exists public.closeout_items (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  project_id uuid not null references public.projects(id),
  category text not null,             -- 'punch','asbuilt','om_manual','warranty','training','permit_final','lien_waiver','final_invoice'
  title text not null,
  status text default 'pending',
  required boolean default true,
  notes text,
  doc_id uuid references public.documents(id),
  completed_by uuid references public.users(id),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ──────────────────────────────────────────────
-- INDEXES
-- ──────────────────────────────────────────────
create index if not exists idx_rfis_project on public.rfis(project_id, status);
create index if not exists idx_invoices_project on public.invoices(project_id, status);
create index if not exists idx_schedule_tasks_project on public.schedule_tasks(project_id, status);
create index if not exists idx_field_issues_project on public.field_issues(project_id, status);
create index if not exists idx_daily_logs_project on public.daily_logs(project_id, log_date desc);
create index if not exists idx_photos_project on public.photos(project_id, taken_at desc);
create index if not exists idx_documents_project on public.documents(project_id, doc_type);
create index if not exists idx_cost_codes_project on public.cost_codes(project_id);

-- Triggers for updated_at
do $$ declare t text; begin
  foreach t in array array['companies','contacts','cost_codes','rfis','invoices','change_orders','change_requests','pcos','schedule_tasks','field_issues','daily_logs','photos','documents','submittals','bid_packages','bid_submissions','permits','inspections','meetings','transmittals','closeout_items'] loop
    execute format('drop trigger if exists trg_%s_updated_at on public.%s', t, t);
    execute format('create trigger trg_%s_updated_at before update on public.%s for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;
