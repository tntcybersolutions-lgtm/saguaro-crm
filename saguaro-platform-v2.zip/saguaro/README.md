# Saguaro Construction Intelligence Platform

Enterprise construction CRM and project management OS. One system, three portals.

## Stack
- **Next.js 14** (App Router, TypeScript)
- **Supabase** (Auth, Postgres, Storage)
- **Hosting**: Vercel / Replit

## Portals
| Portal | URL | Users |
|--------|-----|-------|
| Internal CRM | `/app` | PM, Super, Estimator, Accounting, Admin, Robert (Master) |
| Customer Portal | `/client` | Owners, clients |
| Trade Portal | `/trade` | Subcontractors, vendors |

## Quick Start

### 1. Install
\`\`\`bash
npm install
\`\`\`

### 2. Environment Variables
Copy `.env.example` to `.env.local` and fill in your Supabase credentials:
\`\`\`bash
cp .env.example .env.local
\`\`\`

### 3. Database Setup
Run SQL migrations in order in Supabase SQL Editor:
1. `supabase/migrations/20260307_001_core.sql`
2. `supabase/migrations/20260307_002_project_modules.sql`
3. `supabase/migrations/20260307_003_compliance_inventory_systems.sql`

### 4. Create First Tenant
\`\`\`bash
npm run dev
# Open http://localhost:3000/setup
\`\`\`

### 5. Run Autopilot
\`\`\`bash
# CLI
npm run autopilot <tenant-id>

# HTTP (cron/webhook)
curl -X POST https://your-app.com/api/internal/autopilot/run \\
  -H "Authorization: Bearer $AUTOPILOT_CRON_SECRET" \\
  -H "Content-Type: application/json" \\
  -d '{"tenantId":"<uuid>"}'
\`\`\`

## Module Coverage

### Internal CRM Modules
- Dashboard (executive KPIs, portfolio overview)
- Portfolio / Projects list
- Per-project hub with 16 tabs:
  - Overview · Autopilot ⚡ · Schedule · Financials · Change Orders
  - Procurement · RFIs · Submittals · Field Issues · Daily Logs
  - Photos · Quality · Safety · Documents · Drawings · Systems/LV
  - Permits · Inspections · Meetings · Bid Packages · Bid Leveling · Closeout
- Compliance Center (COI/W-9 gates)
- Inventory (catalog, stock, locations, tools, vehicles)
- Reports (8 standard report types)
- Admin (users, roles, audit logs, invites)

### Autopilot AI Engine
5 rule codes, configurable thresholds, auto-resolve, project rollup:
- `RFI_OVERDUE` — overdue response by 1/4/8 days
- `INVOICE_OVERDUE` — unpaid invoices by 1/7/14 days + balance thresholds
- `SCHEDULE_SLIPPAGE` — baseline vs actual finish by 1/5/10 days
- `FIELD_ISSUE_UNRESOLVED` — open issues by 2/5/10 days
- `PROJECT_RISK_ROLLUP` — aggregated project-level risk escalation

### Robert Master Control
- `is_master: true` flag on user
- Override gates with reason logging
- Full audit trail
- All portals accessible

## File Structure
\`\`\`
app/
  setup/                    # First-time setup
  login/                    # Smart login router
  app/                      # Internal CRM
    page.tsx                # Executive dashboard
    projects/               # Portfolio + project hub
    compliance/             # Vendor compliance center
    inventory/              # Inventory management
    reports/                # Report builder
    admin/                  # User/role admin
  mobile/[projectId]/       # Mobile field app
  api/
    provision-tenant/       # Tenant creation API
    internal/autopilot/run/ # Autopilot HTTP trigger
components/
  AppShell.tsx              # Main app layout + sidebar
  AutopilotPanel.tsx        # Live alert panel
  ProjectSidebar.tsx        # Per-project nav
  PageHeader.tsx            # Standard page header
  EmptyState.tsx            # Empty state component
lib/
  supabaseClient.ts         # Browser client
  supabaseAdmin.ts          # Server admin client
  serverAuth.ts             # SSR auth helpers
  useTenantRole.ts          # Role hook
  audit.ts                  # Audit log helper
src/lib/
  autopilot/engine.ts       # Autopilot AI engine
  supabase/admin.ts         # Engine supabase client
scripts/
  run-autopilot.ts          # CLI runner
supabase/migrations/
  001_core.sql              # Tenants, users, projects, audit
  002_project_modules.sql   # RFIs, invoices, schedule, etc.
  003_compliance_inventory_systems.sql
\`\`\`

## Robert Master Control Setup
To make a user the master controller:
\`\`\`sql
UPDATE users SET is_master = true, role = 'master' WHERE email = 'robert@yourcompany.com';
\`\`\`
