# Build Order

1. `supabase/migrations/20260307_autopilot.sql`
2. `supabase/migrations/20260307_bid_portal.sql`
3. Verify `project-files` bucket exists
4. Start app with `npm run dev`
5. Test routes:
   - `/setup`
   - `/{tenantSlug}/app/projects/{projectId}/bid-packages`
   - `/{tenantSlug}/portal/invite/{token}`
   - `/api/internal/autopilot/run?tenantId=<tenant-id>&token=<AUTOPILOT_CRON_SECRET>`
