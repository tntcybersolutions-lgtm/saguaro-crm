import { PageHeader } from '@/components/PageHeader';

export default function SetupPage() {
  return (
    <main className="container" style={{ padding: '32px 0 48px' }}>
      <div className="stack">
        <PageHeader
          title="Tenant setup"
          description="Use this page after the SQL rollout to create the first tenant record in Replit or Supabase."
        />
        <div className="card stack">
          <strong>Suggested first step</strong>
          <p className="muted" style={{ margin: 0 }}>
            POST to <code>/api/provision-tenant</code> with <code>name</code> and <code>slug</code>, or create the
            tenant directly in Supabase.
          </p>
        </div>
      </div>
    </main>
  );
}
