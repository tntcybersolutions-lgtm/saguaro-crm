import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default async function Page() {
  return <ModulePlaceholder title="Request access" description="Access request scaffold." />;
}
