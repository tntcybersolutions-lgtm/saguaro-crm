import Link from 'next/link';

import { PageHeader } from '@/components/PageHeader';

export default async function TenantLandingPage({ params }: { params: Promise<{ tenantSlug: string }> }) {
  const { tenantSlug } = await params;

  return (
    <main className="container" style={{ padding: '32px 0 48px' }}>
      <div className="stack">
        <PageHeader title={`${tenantSlug} portal`} description="Tenant landing page scaffold." />
        <div className="card row">
          <Link href={`/${tenantSlug}/login`}>Login</Link>
          <Link href={`/${tenantSlug}/app`}>Open app</Link>
          <Link href={`/${tenantSlug}/request-access`}>Request access</Link>
        </div>
      </div>
    </main>
  );
}
