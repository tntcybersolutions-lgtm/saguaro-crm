import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default async function Page() {
  return <ModulePlaceholder title="Logout" description="Tenant logout route scaffold." />;
}
