import type { ReactNode } from 'react';
export default function PortalLayout({ children }: { children: ReactNode }) {
  return <main className="portal-shell">{children}</main>;
}
