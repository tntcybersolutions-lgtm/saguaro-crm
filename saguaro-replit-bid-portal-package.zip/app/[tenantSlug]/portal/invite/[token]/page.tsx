'use client';

import { useParams, useRouter } from 'next/navigation';
import { useState } from 'react';

import { PageHeader } from '@/components/PageHeader';

export default function PortalInvitePage() {
  const router = useRouter();
  const params = useParams<{ tenantSlug: string; token: string }>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function continueToPortal() {
    if (!params?.tenantSlug || !params?.token) return;
    setLoading(true);
    setError(null);

    const response = await fetch('/api/portal/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tenantSlug: params.tenantSlug, token: params.token }),
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setError(result.error ?? 'Could not open portal.');
      setLoading(false);
      return;
    }

    router.push(result.redirectTo);
    router.refresh();
  }

  return (
    <div className="stack">
      <PageHeader title="Subcontractor bid portal" description="Open your invite to access the bid submission workspace." />
      <div className="card stack">
        <div className="notice">This invite route establishes a signed portal session tied to the bid submission.</div>
        {error ? <div className="error">{error}</div> : null}
        <div className="row">
          <button type="button" onClick={continueToPortal} disabled={!params?.tenantSlug || !params?.token || loading}>
            {loading ? 'Opening…' : 'Open bid portal'}
          </button>
        </div>
      </div>
    </div>
  );
}
