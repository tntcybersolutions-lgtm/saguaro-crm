import { redirect } from 'next/navigation';

import { BidSubmissionEditor } from '@/components/BidSubmissionEditor';
import { EmptyState } from '@/components/EmptyState';
import { PageHeader } from '@/components/PageHeader';
import { getPortalSubmissionPageData } from '@/lib/bids/queries';

export default async function PortalSubmissionPage({
  params,
}: {
  params: Promise<{ tenantSlug: string; submissionId: string }>;
}) {
  const { tenantSlug, submissionId } = await params;
  const data = await getPortalSubmissionPageData(submissionId);

  if (!data.authorized) {
    return (
      <EmptyState
        title="Portal session missing"
        description="Open the original invite link again to establish a subcontractor portal session."
      />
    );
  }

  if (!data.submission || !data.bidPackage) {
    return <EmptyState title="Submission not found" description="The submission or bid package could not be loaded." />;
  }

  const canEdit = data.submission.status !== 'awarded' && data.submission.status !== 'rejected';

  return (
    <div className="stack">
      <PageHeader
        title={`${data.bidPackage.code} — ${data.bidPackage.name}`}
        description={`Subcontractor portal for tenant ${tenantSlug}.`}
      />
      <div className="card stack">
        <div className="row">
          <span className="badge">Bid portal</span>
          <span className="muted">Submission ID: {data.submission.id}</span>
        </div>
        {data.bidPackage.description ? <div className="muted">{data.bidPackage.description}</div> : null}
        {data.bidPackage.due_at ? <div className="muted">Due: {new Date(data.bidPackage.due_at).toLocaleString()}</div> : null}
      </div>
      <BidSubmissionEditor
        submissionId={data.submission.id}
        canEdit={canEdit}
        initialStatus={data.submission.status}
        initialContactName={data.submission.contact_name ?? ''}
        initialContactEmail={data.submission.contact_email ?? data.session.email}
        initialContactPhone={data.submission.contact_phone ?? ''}
        initialNotes={data.submission.notes ?? ''}
        initialItems={data.items}
        initialAttachments={data.documents as Array<{ id: string; file_name: string; storage_path: string; created_at: string }>}
      />
    </div>
  );
}
