import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Mobile schedule" description="Mobile schedule scaffold." />;
}
