import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Mobile home" description="Mobile project home scaffold." />;
}
