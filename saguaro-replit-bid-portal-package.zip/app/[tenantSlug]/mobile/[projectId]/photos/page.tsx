import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Mobile photos" description="Mobile photos scaffold." />;
}
