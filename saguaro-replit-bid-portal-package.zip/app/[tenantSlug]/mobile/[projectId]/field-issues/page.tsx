import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Mobile field issues" description="Mobile field issues scaffold." />;
}
