import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Mobile inspections" description="Mobile inspections scaffold." />;
}
