import { MobileFieldShell } from '@/components/MobileFieldShell';
import type { ReactNode } from 'react';

export default async function MobileLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ tenantSlug: string; projectId: string }>;
}) {
  const { tenantSlug, projectId } = await params;
  return <MobileFieldShell tenantSlug={tenantSlug} projectId={projectId}>{children}</MobileFieldShell>;
}
