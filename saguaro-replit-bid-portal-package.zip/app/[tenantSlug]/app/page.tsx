import { PageHeader } from '@/components/PageHeader';

export default async function TenantDashboardPage({ params }: { params: Promise<{ tenantSlug: string }> }) {
  const { tenantSlug } = await params;
  return (
    <div className="stack">
      <PageHeader title={`${tenantSlug} dashboard`} description="Organized Replit handoff dashboard." />
      <div className="grid three">
        <div className="kpi"><span className="muted">Projects</span><strong>--</strong></div>
        <div className="kpi"><span className="muted">Open RFIs</span><strong>--</strong></div>
        <div className="kpi"><span className="muted">Autopilot alerts</span><strong>--</strong></div>
      </div>
    </div>
  );
}
