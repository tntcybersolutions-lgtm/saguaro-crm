import { AppShell } from '@/components/AppShell';
import type { ReactNode } from 'react';

export default async function TenantAppLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ tenantSlug: string }>;
}) {
  const { tenantSlug } = await params;
  return <AppShell tenantSlug={tenantSlug}>{children}</AppShell>;
}
