import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default async function Page() {
  return <ModulePlaceholder title="Admin" description="Admin module scaffold." />;
}
