import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default async function Page() {
  return <ModulePlaceholder title="Audit logs" description="Audit log viewer scaffold." />;
}
