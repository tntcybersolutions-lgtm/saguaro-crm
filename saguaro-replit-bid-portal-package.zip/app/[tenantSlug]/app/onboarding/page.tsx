import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default async function Page() {
  return <ModulePlaceholder title="Onboarding" description="Tenant onboarding scaffold." />;
}
