import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="RFI detail" description="RFI detail scaffold." />;
}
