import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="RFIs" description="RFI list scaffold." />;
}
