import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Photo detail" description="Photo detail scaffold." />;
}
