import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Field issue detail" description="Field issue detail scaffold." />;
}
