import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Task detail" description="Schedule task detail scaffold." />;
}
