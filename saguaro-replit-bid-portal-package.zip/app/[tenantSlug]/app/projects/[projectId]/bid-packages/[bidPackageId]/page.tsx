import { BidAwardButton } from '@/components/BidAwardButton';
import { BidInviteForm } from '@/components/BidInviteForm';
import { BidPackageItemsEditor } from '@/components/BidPackageItemsEditor';
import { EmptyState } from '@/components/EmptyState';
import { PageHeader } from '@/components/PageHeader';
import { getBidPackageDetail } from '@/lib/bids/queries';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

async function getCompanyNames(companyIds: string[]) {
  if (companyIds.length === 0) return new Map<string, string>();
  const { data } = await supabaseAdmin.from('subcontractor_companies').select('id, name').in('id', companyIds);
  return new Map((data ?? []).map((row: { id: string; name: string }) => [row.id, row.name]));
}

export default async function BidPackageDetailPage({
  params,
}: {
  params: Promise<{ tenantSlug: string; projectId: string; bidPackageId: string }>;
}) {
  const { tenantSlug, projectId, bidPackageId } = await params;
  const data = await getBidPackageDetail(tenantSlug, projectId, bidPackageId);

  if (!data.tenant) {
    return <EmptyState title="Tenant not found" description="Create the tenant first or confirm the URL." />;
  }

  if (!data.bidPackage) {
    return <EmptyState title="Bid package not found" description="Create the package first from the bid packages list." />;
  }

  const companyNames = await getCompanyNames(
    [...new Set(data.submissions.map((submission) => submission.subcontractor_company_id).filter(Boolean) as string[])],
  );

  return (
    <div className="stack">
      <PageHeader
        title={`${data.bidPackage.code} — ${data.bidPackage.name}`}
        description={data.bidPackage.description ?? 'Bid package detail and subcontractor portal management.'}
      />

      <div className="grid two">
        <div className="card stack">
          <strong>Package status</strong>
          <div className="row">
            <span className="badge">{data.bidPackage.status}</span>
            <span className="muted">Due: {data.bidPackage.due_at ? new Date(data.bidPackage.due_at).toLocaleString() : '—'}</span>
          </div>
        </div>
        <div className="card stack">
          <strong>Workflow</strong>
          <div className="muted">1) Add items 2) Invite subs 3) Review bids 4) Award winner</div>
        </div>
      </div>

      <BidPackageItemsEditor tenantId={data.tenant.id} bidPackageId={bidPackageId} />

      <div className="card stack">
        <strong>Scope items</strong>
        {data.items.length === 0 ? (
          <div className="muted">No scope items yet.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Code</th>
                <th>Title</th>
                <th>Qty</th>
                <th>UOM</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((item) => (
                <tr key={item.id}>
                  <td>{item.code}</td>
                  <td>
                    <div>{item.title}</div>
                    {item.description ? <div className="muted">{item.description}</div> : null}
                  </td>
                  <td>{Number(item.quantity).toFixed(2)}</td>
                  <td>{item.uom}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <BidInviteForm
        tenantId={data.tenant.id}
        tenantSlug={tenantSlug}
        projectId={projectId}
        bidPackageId={bidPackageId}
      />

      <div className="card stack">
        <strong>Invites</strong>
        {data.invites.length === 0 ? (
          <div className="muted">No invites yet.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Company</th>
                <th>Email</th>
                <th>Status</th>
                <th>Sent</th>
                <th>Opened</th>
                <th>Accepted</th>
              </tr>
            </thead>
            <tbody>
              {data.invites.map((invite) => (
                <tr key={invite.id}>
                  <td>{invite.company_name}</td>
                  <td>{invite.email}</td>
                  <td>{invite.status}</td>
                  <td>{invite.last_sent_at ? new Date(invite.last_sent_at).toLocaleString() : '—'}</td>
                  <td>{invite.opened_at ? new Date(invite.opened_at).toLocaleString() : '—'}</td>
                  <td>{invite.accepted_at ? new Date(invite.accepted_at).toLocaleString() : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card stack">
        <strong>Submissions</strong>
        {data.submissions.length === 0 ? (
          <div className="muted">No submissions yet.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Company</th>
                <th>Status</th>
                <th>Total</th>
                <th>Submitted</th>
                <th>Award</th>
              </tr>
            </thead>
            <tbody>
              {data.submissions.map((submission) => (
                <tr key={submission.id}>
                  <td>{submission.subcontractor_company_id ? companyNames.get(submission.subcontractor_company_id) ?? 'Subcontractor' : 'Subcontractor'}</td>
                  <td>{submission.status}</td>
                  <td>${Number(submission.total_amount ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                  <td>{submission.submitted_at ? new Date(submission.submitted_at).toLocaleString() : '—'}</td>
                  <td>
                    {submission.status === 'awarded' ? (
                      <span className="badge">Awarded</span>
                    ) : (
                      <BidAwardButton bidPackageId={bidPackageId} submissionId={submission.id} />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
