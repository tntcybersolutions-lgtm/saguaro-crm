import Link from 'next/link';

import { BidPackageCreateForm } from '@/components/BidPackageCreateForm';
import { EmptyState } from '@/components/EmptyState';
import { PageHeader } from '@/components/PageHeader';
import { getBidPackagesForProject } from '@/lib/bids/queries';

export default async function BidPackagesPage({
  params,
}: {
  params: Promise<{ tenantSlug: string; projectId: string }>;
}) {
  const { tenantSlug, projectId } = await params;
  const { tenant, bidPackages } = await getBidPackagesForProject(tenantSlug, projectId);

  return (
    <div className="stack">
      <PageHeader
        title="Bid packages"
        description="Create scopes, invite subcontractors, and track submissions end to end."
      />

      {tenant ? (
        <BidPackageCreateForm tenantId={tenant.id} tenantSlug={tenantSlug} projectId={projectId} />
      ) : (
        <EmptyState
          title="Tenant not found"
          description="Create the tenant first or confirm the tenant slug in the URL."
        />
      )}

      <div className="card stack">
        <strong>Existing bid packages</strong>
        {bidPackages.length === 0 ? (
          <div className="muted">No bid packages yet.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Status</th>
                <th>Due</th>
              </tr>
            </thead>
            <tbody>
              {bidPackages.map((pkg) => (
                <tr key={pkg.id}>
                  <td>
                    <Link href={`/${tenantSlug}/app/projects/${projectId}/bid-packages/${pkg.id}`}>{pkg.code}</Link>
                  </td>
                  <td>{pkg.name}</td>
                  <td>{pkg.status}</td>
                  <td>{pkg.due_at ? new Date(pkg.due_at).toLocaleString() : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
