import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Drawing detail" description="Drawing detail scaffold." />;
}
