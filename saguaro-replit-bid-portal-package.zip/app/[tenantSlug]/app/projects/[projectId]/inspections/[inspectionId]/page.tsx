import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Inspection detail" description="Inspection detail scaffold." />;
}
