import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Bid leveling" description="Bid leveling scaffold." />;
}
