import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Autopilot alerts" description="Autopilot alerts scaffold." />;
}
