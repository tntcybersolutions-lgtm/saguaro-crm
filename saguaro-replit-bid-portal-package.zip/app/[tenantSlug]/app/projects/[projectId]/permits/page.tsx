import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Permits" description="Permits list scaffold." />;
}
