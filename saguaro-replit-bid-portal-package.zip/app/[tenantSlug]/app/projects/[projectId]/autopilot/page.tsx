import { AutopilotPanel } from '@/components/AutopilotPanel';
import { PageHeader } from '@/components/PageHeader';

export default function ProjectAutopilotPage() {
  return (
    <div className="stack">
      <PageHeader title="Autopilot" description="Autopilot dashboard scaffold." />
      <AutopilotPanel />
    </div>
  );
}
