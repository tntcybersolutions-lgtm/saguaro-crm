import { ProjectSidebar } from '@/components/ProjectSidebar';
import type { ReactNode } from 'react';

export default async function ProjectLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ tenantSlug: string; projectId: string }>;
}) {
  const { tenantSlug, projectId } = await params;
  return (
    <div className="stack">
      <ProjectSidebar tenantSlug={tenantSlug} projectId={projectId} />
      {children}
    </div>
  );
}
