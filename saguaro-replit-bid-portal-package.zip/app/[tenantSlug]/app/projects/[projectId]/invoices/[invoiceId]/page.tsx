import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default function Page() {
  return <ModulePlaceholder title="Invoice detail" description="Invoice detail scaffold." />;
}
