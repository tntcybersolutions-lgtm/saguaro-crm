import Link from 'next/link';

import { PageHeader } from '@/components/PageHeader';

export default async function ProjectHomePage({
  params,
}: {
  params: Promise<{ tenantSlug: string; projectId: string }>;
}) {
  const { tenantSlug, projectId } = await params;

  return (
    <div className="stack">
      <PageHeader title={`Project ${projectId}`} description="Project home scaffold with key entry points." />
      <div className="grid three">
        <div className="kpi"><span className="muted">RFIs</span><strong>--</strong></div>
        <div className="kpi"><span className="muted">Invoices</span><strong>--</strong></div>
        <div className="kpi"><span className="muted">Field issues</span><strong>--</strong></div>
      </div>
      <div className="card row">
        <Link href={`/${tenantSlug}/app/projects/${projectId}/bid-packages`}>Open bid packages</Link>
        <Link href={`/${tenantSlug}/app/projects/${projectId}/autopilot`}>Open autopilot</Link>
      </div>
    </div>
  );
}
