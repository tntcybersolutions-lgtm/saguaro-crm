import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default async function Page() {
  return <ModulePlaceholder title="Invite acceptance" description="Tenant invite acceptance scaffold." />;
}
