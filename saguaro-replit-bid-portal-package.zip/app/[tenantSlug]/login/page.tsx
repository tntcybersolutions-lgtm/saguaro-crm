import { ModulePlaceholder } from '@/components/ModulePlaceholder';

export default async function Page() {
  return <ModulePlaceholder title="Login" description="Tenant login route scaffold." />;
}
