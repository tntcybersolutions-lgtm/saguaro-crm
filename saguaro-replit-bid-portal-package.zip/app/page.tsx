import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="container" style={{ padding: '48px 0' }}>
      <div className="card stack">
        <span className="badge">Saguaro CRM</span>
        <h1 style={{ margin: 0 }}>Replit-ready handoff package</h1>
        <p className="muted" style={{ margin: 0 }}>
          Start with setup, then open a tenant route or the bid package module.
        </p>
        <div className="row">
          <Link href="/setup">Open setup</Link>
          <Link href="/demo/app/projects/demo-project/bid-packages">Open bid packages demo route</Link>
        </div>
      </div>
    </main>
  );
}
