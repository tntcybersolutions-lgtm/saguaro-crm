import { NextRequest, NextResponse } from 'next/server';

import { awardBidSubmission } from '@/lib/bids/invitations';

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({} as Record<string, unknown>));

  try {
    const awarded = await awardBidSubmission({
      bidPackageId: String(body.bidPackageId ?? ''),
      submissionId: String(body.submissionId ?? ''),
    });

    return NextResponse.json({ ok: true, submission: awarded });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not award bid' },
      { status: 500 },
    );
  }
}
