import { NextRequest, NextResponse } from 'next/server';

import { createBidInvite } from '@/lib/bids/invitations';

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({} as Record<string, unknown>));

  try {
    const result = await createBidInvite({
      tenantId: String(body.tenantId ?? ''),
      tenantSlug: String(body.tenantSlug ?? ''),
      projectId: String(body.projectId ?? ''),
      bidPackageId: String(body.bidPackageId ?? ''),
      companyName: String(body.companyName ?? ''),
      email: String(body.email ?? ''),
      contactName: String(body.contactName ?? ''),
      phone: String(body.phone ?? ''),
    });

    return NextResponse.json({
      ok: true,
      invite: result.invite,
      submission: result.submission,
      inviteUrl: result.inviteUrl,
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Invite creation failed' },
      { status: 500 },
    );
  }
}
