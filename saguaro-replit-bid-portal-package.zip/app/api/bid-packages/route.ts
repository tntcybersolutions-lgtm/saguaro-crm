import { NextRequest, NextResponse } from 'next/server';

import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { writeAuditEvent } from '@/lib/audit';

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({} as Record<string, unknown>));

  const tenantId = String(body.tenantId ?? '');
  const projectId = String(body.projectId ?? '');
  const code = String(body.code ?? '').trim();
  const name = String(body.name ?? '').trim();
  const description = String(body.description ?? '').trim() || null;
  const dueAt = String(body.dueAt ?? '').trim() || null;

  if (!tenantId || !projectId || !code || !name) {
    return NextResponse.json({ error: 'tenantId, projectId, code, and name are required' }, { status: 400 });
  }

  const { data, error } = await supabaseAdmin
    .from('bid_packages')
    .insert({
      tenant_id: tenantId,
      project_id: projectId,
      code,
      name,
      description,
      due_at: dueAt ? new Date(dueAt).toISOString() : null,
      status: 'draft',
    })
    .select('*')
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  await writeAuditEvent({
    tenantId,
    projectId,
    action: 'bid.package.created',
    entityType: 'bid_package',
    entityId: data.id,
    metadata: { code, name },
  });

  return NextResponse.json({ ok: true, bidPackage: data });
}
