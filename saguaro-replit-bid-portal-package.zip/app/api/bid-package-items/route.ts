import { NextRequest, NextResponse } from 'next/server';

import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({} as Record<string, unknown>));
  const tenantId = String(body.tenantId ?? '');
  const bidPackageId = String(body.bidPackageId ?? '');
  const code = String(body.code ?? '').trim();
  const title = String(body.title ?? '').trim();
  const description = String(body.description ?? '').trim() || null;
  const uom = String(body.uom ?? '').trim();
  const quantity = Number(body.quantity ?? 0);

  if (!tenantId || !bidPackageId || !code || !title || !uom) {
    return NextResponse.json({ error: 'tenantId, bidPackageId, code, title, and uom are required' }, { status: 400 });
  }

  const { count } = await supabaseAdmin
    .from('bid_package_items')
    .select('id', { count: 'exact', head: true })
    .eq('bid_package_id', bidPackageId);

  const { data, error } = await supabaseAdmin
    .from('bid_package_items')
    .insert({
      bid_package_id: bidPackageId,
      sort_order: count ?? 0,
      code,
      title,
      description,
      uom,
      quantity,
    })
    .select('*')
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true, item: data });
}
