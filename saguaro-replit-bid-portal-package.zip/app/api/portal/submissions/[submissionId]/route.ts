import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';

import { PORTAL_COOKIE_NAME, readPortalSession } from '@/lib/bids/portalSession';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ submissionId: string }> },
) {
  const { submissionId } = await context.params;
  const cookieStore = await cookies();
  const session = readPortalSession(cookieStore.get(PORTAL_COOKIE_NAME)?.value);

  if (!session || session.submissionId !== submissionId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await request.json().catch(() => ({} as Record<string, unknown>));
  const action = String(body.action ?? 'draft');
  const items = Array.isArray(body.items) ? body.items : [];
  const contactName = String(body.contactName ?? '');
  const contactEmail = String(body.contactEmail ?? '');
  const contactPhone = String(body.contactPhone ?? '');
  const notes = String(body.notes ?? '');

  let totalAmount = 0;
  const rows = items.map((item) => {
    const quantity = Number((item as Record<string, unknown>).quantity ?? 0);
    const unitPrice = Number((item as Record<string, unknown>).unitPrice ?? 0);
    const included = Boolean((item as Record<string, unknown>).included ?? true);
    totalAmount += included ? quantity * unitPrice : 0;

    return {
      submission_id: submissionId,
      bid_package_item_id: String((item as Record<string, unknown>).bidPackageItemId ?? ''),
      quantity,
      unit_price: unitPrice,
      included,
      lead_time_days: Number((item as Record<string, unknown>).leadTimeDays ?? 0),
      notes: String((item as Record<string, unknown>).notes ?? ''),
    };
  });

  if (rows.some((row) => !row.bid_package_item_id)) {
    return NextResponse.json({ error: 'All bid rows must include a bidPackageItemId' }, { status: 400 });
  }

  const now = new Date().toISOString();

  const { error: rowError } = await supabaseAdmin
    .from('bid_submission_items')
    .upsert(rows, { onConflict: 'submission_id,bid_package_item_id' });

  if (rowError) {
    return NextResponse.json({ error: rowError.message }, { status: 500 });
  }

  const nextStatus = action === 'submitted' ? 'submitted' : 'draft';
  const { data: submission, error: submissionError } = await supabaseAdmin
    .from('bid_submissions')
    .update({
      status: nextStatus,
      contact_name: contactName || null,
      contact_email: contactEmail || null,
      contact_phone: contactPhone || null,
      notes: notes || null,
      total_amount: totalAmount,
      submitted_at: action === 'submitted' ? now : null,
    })
    .eq('id', submissionId)
    .select('*')
    .single();

  if (submissionError) {
    return NextResponse.json({ error: submissionError.message }, { status: 500 });
  }

  if (action === 'submitted') {
    await supabaseAdmin
      .from('subcontractor_invites')
      .update({ status: 'accepted', accepted_at: now })
      .eq('id', session.inviteId);
  }

  return NextResponse.json({ ok: true, submission });
}
