import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';

import { PORTAL_COOKIE_NAME, readPortalSession } from '@/lib/bids/portalSession';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ submissionId: string }> },
) {
  const { submissionId } = await context.params;
  const cookieStore = await cookies();
  const session = readPortalSession(cookieStore.get(PORTAL_COOKIE_NAME)?.value);

  if (!session || session.submissionId !== submissionId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const formData = await request.formData();
  const files = formData.getAll('files');
  if (files.length === 0) {
    return NextResponse.json({ error: 'No files uploaded' }, { status: 400 });
  }

  const documents = [] as Record<string, unknown>[];

  for (const entry of files) {
    if (!(entry instanceof File)) continue;

    const safeName = entry.name.replace(/[^a-zA-Z0-9._-]/g, '-');
    const storagePath = `tenant/${session.tenantId}/project/${session.projectId}/bids/${submissionId}/${Date.now()}-${safeName}`;

    const { error: uploadError } = await supabaseAdmin.storage
      .from('project-files')
      .upload(storagePath, entry, {
        upsert: false,
        contentType: entry.type || undefined,
      });

    if (uploadError) {
      return NextResponse.json({ error: uploadError.message }, { status: 500 });
    }

    const { data, error } = await supabaseAdmin
      .from('bid_submission_documents')
      .insert({
        submission_id: submissionId,
        bucket_name: 'project-files',
        storage_path: storagePath,
        file_name: entry.name,
        file_size: entry.size,
        content_type: entry.type || null,
      })
      .select('*')
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    documents.push(data as Record<string, unknown>);
  }

  return NextResponse.json({ ok: true, documents });
}
