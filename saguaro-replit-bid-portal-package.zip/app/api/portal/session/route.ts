import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';

import { getInviteByRawToken } from '@/lib/bids/queries';
import { PORTAL_COOKIE_NAME, signPortalSession } from '@/lib/bids/portalSession';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({} as Record<string, unknown>));
  const tenantSlug = String(body.tenantSlug ?? '');
  const token = String(body.token ?? '');

  if (!tenantSlug || !token) {
    return NextResponse.json({ error: 'tenantSlug and token are required' }, { status: 400 });
  }

  const inviteData = await getInviteByRawToken(tenantSlug, token);
  if (!inviteData?.invite || !inviteData.submission || !inviteData.bidPackage) {
    return NextResponse.json({ error: 'Invalid invite token' }, { status: 404 });
  }

  if (inviteData.invite.expires_at && new Date(inviteData.invite.expires_at).getTime() <= Date.now()) {
    return NextResponse.json({ error: 'Invite has expired' }, { status: 410 });
  }

  const sessionToken = signPortalSession({
    inviteId: inviteData.invite.id,
    submissionId: inviteData.submission.id,
    tenantId: inviteData.tenant.id,
    projectId: inviteData.invite.project_id,
    bidPackageId: inviteData.bidPackage.id,
    email: inviteData.invite.email,
    expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(),
  });

  const cookieStore = await cookies();
  cookieStore.set(PORTAL_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });

  await supabaseAdmin
    .from('subcontractor_invites')
    .update({ status: 'opened', opened_at: new Date().toISOString() })
    .eq('id', inviteData.invite.id);

  return NextResponse.json({
    ok: true,
    redirectTo: `/${tenantSlug}/portal/submissions/${inviteData.submission.id}`,
  });
}
