import { cookies } from 'next/headers';

import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { hashInviteToken } from '@/lib/bids/invitations';
import { PORTAL_COOKIE_NAME, readPortalSession } from '@/lib/bids/portalSession';
import type {
  BidInviteRecord,
  BidPackageItemRecord,
  BidPackageRecord,
  BidSubmissionRecord,
  TenantRecord,
} from '@/lib/bids/types';

export async function getTenantBySlug(tenantSlug: string): Promise<TenantRecord | null> {
  const { data } = await supabaseAdmin
    .from('tenants')
    .select('id, slug, name')
    .eq('slug', tenantSlug)
    .limit(1)
    .maybeSingle();

  return (data as TenantRecord | null) ?? null;
}

async function safeSelect<T>(query: PromiseLike<{ data: T[] | null; error: unknown }>) {
  const result = await query;
  if ((result as { error?: unknown }).error) {
    console.warn('Safe select query failed.');
    return [] as T[];
  }
  return result.data ?? [];
}

export async function getBidPackagesForProject(tenantSlug: string, projectId: string) {
  const tenant = await getTenantBySlug(tenantSlug);
  if (!tenant) return { tenant: null, bidPackages: [] as BidPackageRecord[] };

  const bidPackages = await safeSelect<BidPackageRecord>(
    supabaseAdmin
      .from('bid_packages')
      .select('*')
      .eq('tenant_id', tenant.id)
      .eq('project_id', projectId)
      .order('created_at', { ascending: false }),
  );

  return { tenant, bidPackages };
}

export async function getBidPackageDetail(tenantSlug: string, projectId: string, bidPackageId: string) {
  const tenant = await getTenantBySlug(tenantSlug);
  if (!tenant) {
    return {
      tenant: null,
      bidPackage: null,
      items: [] as BidPackageItemRecord[],
      invites: [] as BidInviteRecord[],
      submissions: [] as BidSubmissionRecord[],
    };
  }

  const { data: bidPackage } = await supabaseAdmin
    .from('bid_packages')
    .select('*')
    .eq('tenant_id', tenant.id)
    .eq('project_id', projectId)
    .eq('id', bidPackageId)
    .maybeSingle();

  const [items, invites, submissions] = await Promise.all([
    safeSelect<BidPackageItemRecord>(
      supabaseAdmin
        .from('bid_package_items')
        .select('*')
        .eq('bid_package_id', bidPackageId)
        .order('sort_order', { ascending: true }),
    ),
    safeSelect<BidInviteRecord>(
      supabaseAdmin
        .from('subcontractor_invites')
        .select('*')
        .eq('tenant_id', tenant.id)
        .eq('project_id', projectId)
        .eq('bid_package_id', bidPackageId)
        .order('created_at', { ascending: false }),
    ),
    safeSelect<BidSubmissionRecord>(
      supabaseAdmin
        .from('bid_submissions')
        .select('*')
        .eq('tenant_id', tenant.id)
        .eq('project_id', projectId)
        .eq('bid_package_id', bidPackageId)
        .order('created_at', { ascending: false }),
    ),
  ]);

  return {
    tenant,
    bidPackage: (bidPackage as BidPackageRecord | null) ?? null,
    items,
    invites,
    submissions,
  };
}

export async function getInviteByRawToken(tenantSlug: string, rawToken: string) {
  const tokenHash = hashInviteToken(rawToken);
  const tenant = await getTenantBySlug(tenantSlug);
  if (!tenant) return null;

  const { data: invite } = await supabaseAdmin
    .from('subcontractor_invites')
    .select('*')
    .eq('tenant_id', tenant.id)
    .eq('invite_token_hash', tokenHash)
    .limit(1)
    .maybeSingle();

  if (!invite) return null;

  const [bidPackageResult, submissionResult, itemsResult] = await Promise.all([
    supabaseAdmin.from('bid_packages').select('*').eq('id', invite.bid_package_id).maybeSingle(),
    supabaseAdmin.from('bid_submissions').select('*').eq('id', invite.portal_submission_id).maybeSingle(),
    supabaseAdmin.from('bid_package_items').select('*').eq('bid_package_id', invite.bid_package_id).order('sort_order', { ascending: true }),
  ]);

  return {
    tenant,
    invite: invite as BidInviteRecord,
    bidPackage: (bidPackageResult.data as BidPackageRecord | null) ?? null,
    submission: (submissionResult.data as BidSubmissionRecord | null) ?? null,
    items: (itemsResult.data as BidPackageItemRecord[] | null) ?? [],
  };
}

export async function getPortalSubmissionPageData(submissionId: string) {
  const cookieStore = await cookies();
  const session = readPortalSession(cookieStore.get(PORTAL_COOKIE_NAME)?.value);
  if (!session || session.submissionId !== submissionId) {
    return { authorized: false as const };
  }

  const [submissionResult, itemsResult, rowsResult, docsResult, bidPackageResult] = await Promise.all([
    supabaseAdmin.from('bid_submissions').select('*').eq('id', submissionId).maybeSingle(),
    supabaseAdmin
      .from('bid_package_items')
      .select('*')
      .eq('bid_package_id', session.bidPackageId)
      .order('sort_order', { ascending: true }),
    supabaseAdmin.from('bid_submission_items').select('*').eq('submission_id', submissionId),
    supabaseAdmin.from('bid_submission_documents').select('*').eq('submission_id', submissionId).order('created_at', { ascending: false }),
    supabaseAdmin.from('bid_packages').select('*').eq('id', session.bidPackageId).maybeSingle(),
  ]);

  const submission = submissionResult.data as BidSubmissionRecord | null;
  const packageItems = (itemsResult.data as BidPackageItemRecord[] | null) ?? [];
  const rowMap = new Map(((rowsResult.data as Record<string, unknown>[] | null) ?? []).map((row) => [String(row.bid_package_item_id), row]));

  const editorItems = packageItems.map((item) => {
    const row = rowMap.get(item.id);
    return {
      bidPackageItemId: item.id,
      code: item.code,
      title: item.title,
      description: item.description,
      uom: item.uom,
      quantity: Number(row?.quantity ?? item.quantity ?? 0),
      unitPrice: Number(row?.unit_price ?? 0),
      included: Boolean(row?.included ?? true),
      leadTimeDays: Number(row?.lead_time_days ?? 0),
      notes: String(row?.notes ?? ''),
    };
  });

  return {
    authorized: true as const,
    session,
    submission,
    bidPackage: (bidPackageResult.data as BidPackageRecord | null) ?? null,
    items: editorItems,
    documents: (docsResult.data as Record<string, unknown>[] | null) ?? [],
  };
}
