import { createHmac, timingSafeEqual } from 'node:crypto';

export const PORTAL_COOKIE_NAME = 'saguaro_portal_session';

type PortalSessionPayload = {
  inviteId: string;
  submissionId: string;
  tenantId: string;
  projectId: string;
  bidPackageId: string;
  email: string;
  expiresAt: string;
};

function getSecret() {
  return process.env.PORTAL_SESSION_SECRET || 'local-dev-portal-secret';
}

function base64UrlEncode(value: string) {
  return Buffer.from(value, 'utf8').toString('base64url');
}

function base64UrlDecode(value: string) {
  return Buffer.from(value, 'base64url').toString('utf8');
}

export function signPortalSession(payload: PortalSessionPayload) {
  const encodedPayload = base64UrlEncode(JSON.stringify(payload));
  const signature = createHmac('sha256', getSecret()).update(encodedPayload).digest('base64url');
  return `${encodedPayload}.${signature}`;
}

export function readPortalSession(token: string | undefined | null): PortalSessionPayload | null {
  if (!token) return null;
  const [encodedPayload, signature] = token.split('.');
  if (!encodedPayload || !signature) return null;

  const expectedSignature = createHmac('sha256', getSecret()).update(encodedPayload).digest('base64url');
  const actual = Buffer.from(signature);
  const expected = Buffer.from(expectedSignature);
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
    return null;
  }

  const payload = JSON.parse(base64UrlDecode(encodedPayload)) as PortalSessionPayload;
  if (new Date(payload.expiresAt).getTime() <= Date.now()) {
    return null;
  }

  return payload;
}
