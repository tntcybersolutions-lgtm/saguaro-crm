import { createHash, randomBytes } from 'node:crypto';

import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { writeAuditEvent } from '@/lib/audit';

export function hashInviteToken(rawToken: string) {
  return createHash('sha256').update(rawToken).digest('hex');
}

function makeRawInviteToken() {
  return randomBytes(24).toString('base64url');
}

async function ensureSubcontractorCompany(args: { tenantId: string; companyName: string; email: string }) {
  const email = args.email.trim().toLowerCase();

  const { data: existing } = await supabaseAdmin
    .from('subcontractor_companies')
    .select('*')
    .eq('tenant_id', args.tenantId)
    .or(`primary_email.eq.${email},name.eq.${args.companyName}`)
    .limit(1)
    .maybeSingle();

  if (existing) return existing;

  const { data, error } = await supabaseAdmin
    .from('subcontractor_companies')
    .insert({
      tenant_id: args.tenantId,
      name: args.companyName,
      primary_email: email,
      status: 'active',
    })
    .select('*')
    .single();

  if (error) throw error;
  return data;
}

async function ensureBidSubmission(args: {
  tenantId: string;
  projectId: string;
  bidPackageId: string;
  subcontractorCompanyId: string;
  contactName?: string;
  email: string;
  phone?: string;
}) {
  const { data: existing } = await supabaseAdmin
    .from('bid_submissions')
    .select('*')
    .eq('bid_package_id', args.bidPackageId)
    .eq('subcontractor_company_id', args.subcontractorCompanyId)
    .limit(1)
    .maybeSingle();

  if (existing) return existing;

  const { data, error } = await supabaseAdmin
    .from('bid_submissions')
    .insert({
      tenant_id: args.tenantId,
      project_id: args.projectId,
      bid_package_id: args.bidPackageId,
      subcontractor_company_id: args.subcontractorCompanyId,
      status: 'draft',
      contact_name: args.contactName ?? null,
      contact_email: args.email,
      contact_phone: args.phone ?? null,
      notes: null,
      total_amount: 0,
    })
    .select('*')
    .single();

  if (error) throw error;
  return data;
}

export async function createBidInvite(args: {
  tenantId: string;
  tenantSlug: string;
  projectId: string;
  bidPackageId: string;
  companyName: string;
  email: string;
  contactName?: string;
  phone?: string;
  actorId?: string | null;
}) {
  const company = await ensureSubcontractorCompany({
    tenantId: args.tenantId,
    companyName: args.companyName,
    email: args.email,
  });

  const submission = await ensureBidSubmission({
    tenantId: args.tenantId,
    projectId: args.projectId,
    bidPackageId: args.bidPackageId,
    subcontractorCompanyId: company.id,
    contactName: args.contactName,
    email: args.email,
    phone: args.phone,
  });

  const rawToken = makeRawInviteToken();
  const tokenHash = hashInviteToken(rawToken);
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 14).toISOString();

  const { data: invite, error } = await supabaseAdmin
    .from('subcontractor_invites')
    .insert({
      tenant_id: args.tenantId,
      project_id: args.projectId,
      bid_package_id: args.bidPackageId,
      subcontractor_company_id: company.id,
      portal_submission_id: submission.id,
      email: args.email.trim().toLowerCase(),
      company_name: args.companyName,
      contact_name: args.contactName ?? null,
      phone: args.phone ?? null,
      invite_token_hash: tokenHash,
      status: 'pending',
      expires_at: expiresAt,
      last_sent_at: new Date().toISOString(),
    })
    .select('*')
    .single();

  if (error) throw error;

  await supabaseAdmin.from('bid_submissions').update({ invite_id: invite.id }).eq('id', submission.id);

  await writeAuditEvent({
    tenantId: args.tenantId,
    projectId: args.projectId,
    action: 'bid.invite.created',
    entityType: 'subcontractor_invite',
    entityId: invite.id,
    actorId: args.actorId ?? null,
    metadata: { bidPackageId: args.bidPackageId, email: args.email, companyId: company.id },
  });

  const baseUrl = (process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000').replace(/\/$/, '');
  const inviteUrl = `${baseUrl}/${args.tenantSlug}/portal/invite/${rawToken}`;

  return {
    invite,
    submission,
    inviteUrl,
    rawToken,
  };
}

export async function awardBidSubmission(args: { bidPackageId: string; submissionId: string }) {
  const now = new Date().toISOString();

  const { error: rejectError } = await supabaseAdmin
    .from('bid_submissions')
    .update({ status: 'rejected' })
    .eq('bid_package_id', args.bidPackageId)
    .neq('id', args.submissionId)
    .in('status', ['draft', 'submitted', 'rejected']);

  if (rejectError) throw rejectError;

  const { data: awarded, error: awardError } = await supabaseAdmin
    .from('bid_submissions')
    .update({ status: 'awarded', awarded_at: now })
    .eq('id', args.submissionId)
    .select('*')
    .single();

  if (awardError) throw awardError;

  const { error: packageError } = await supabaseAdmin
    .from('bid_packages')
    .update({ status: 'awarded', awarded_submission_id: args.submissionId })
    .eq('id', args.bidPackageId);

  if (packageError) throw packageError;

  return awarded;
}
