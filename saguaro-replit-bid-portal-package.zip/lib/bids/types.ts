export type TenantRecord = {
  id: string;
  slug: string;
  name: string | null;
};

export type BidPackageRecord = {
  id: string;
  tenant_id: string;
  project_id: string;
  code: string;
  name: string;
  description: string | null;
  status: string;
  due_at: string | null;
  awarded_submission_id: string | null;
  created_at: string;
};

export type BidPackageItemRecord = {
  id: string;
  bid_package_id: string;
  code: string;
  title: string;
  description: string | null;
  uom: string;
  quantity: number;
  sort_order: number;
};

export type BidInviteRecord = {
  id: string;
  tenant_id: string;
  project_id: string;
  bid_package_id: string;
  subcontractor_company_id: string | null;
  portal_submission_id: string | null;
  email: string;
  company_name: string;
  contact_name: string | null;
  phone: string | null;
  status: string;
  expires_at: string | null;
  opened_at: string | null;
  accepted_at: string | null;
  last_sent_at: string | null;
  created_at: string;
};

export type BidSubmissionRecord = {
  id: string;
  tenant_id: string;
  project_id: string;
  bid_package_id: string;
  subcontractor_company_id: string | null;
  invite_id: string | null;
  status: string;
  contact_name: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  notes: string | null;
  total_amount: number;
  submitted_at: string | null;
  awarded_at: string | null;
  created_at: string;
};
