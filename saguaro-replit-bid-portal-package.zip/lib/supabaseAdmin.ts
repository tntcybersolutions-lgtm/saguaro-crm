import { createClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !serviceRoleKey) {
  console.warn('Supabase admin client environment variables are not fully configured yet.');
}

export const supabaseAdmin = createClient(url ?? 'https://example.invalid', serviceRoleKey ?? 'service-role-missing', {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});
