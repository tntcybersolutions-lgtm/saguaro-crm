import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function writeAuditEvent(args: {
  tenantId: string;
  projectId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  actorId?: string | null;
  metadata?: Record<string, unknown>;
}) {
  try {
    await supabaseAdmin.from('audit_logs').insert({
      tenant_id: args.tenantId,
      project_id: args.projectId ?? null,
      action: args.action,
      entity_type: args.entityType,
      entity_id: args.entityId ?? null,
      actor_id: args.actorId ?? null,
      metadata: args.metadata ?? {},
    });
  } catch (error) {
    console.warn('Audit logging skipped:', error instanceof Error ? error.message : error);
  }
}
