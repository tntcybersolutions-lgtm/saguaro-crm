import { cookies } from 'next/headers';

export type ViewerRole = 'internal' | 'client' | 'subcontractor';

export async function getViewerContext() {
  const cookieStore = await cookies();
  const role = (cookieStore.get('saguaro-role')?.value as ViewerRole | undefined) ?? 'internal';
  const userId = cookieStore.get('saguaro-user-id')?.value ?? null;
  return { role, userId };
}

export async function requireInternalUser() {
  const viewer = await getViewerContext();
  if (viewer.role !== 'internal') {
    throw new Error('Internal access required.');
  }
  return viewer;
}
