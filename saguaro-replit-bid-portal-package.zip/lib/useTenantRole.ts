'use client';

import { useMemo } from 'react';

export function useTenantRole() {
  return useMemo(() => ({ role: 'internal' as const, loading: false }), []);
}
