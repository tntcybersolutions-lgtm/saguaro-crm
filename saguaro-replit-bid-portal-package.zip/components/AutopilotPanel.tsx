export function AutopilotPanel() {
  return (
    <div className="grid three">
      <div className="kpi">
        <span className="muted">Open alerts</span>
        <strong>--</strong>
      </div>
      <div className="kpi">
        <span className="muted">Critical alerts</span>
        <strong>--</strong>
      </div>
      <div className="kpi">
        <span className="muted">Last run</span>
        <strong>--</strong>
      </div>
    </div>
  );
}
