import Link from 'next/link';
import type { ReactNode } from 'react';

const mainLinks = [
  ['Dashboard', 'app'],
  ['Projects', 'app/projects'],
  ['Reports', 'app/reports'],
  ['Onboarding', 'app/onboarding'],
  ['Admin', 'app/admin'],
  ['Invites', 'app/admin/invites'],
  ['Audit Logs', 'app/admin/audit'],
];

export function AppShell({ tenantSlug, children }: { tenantSlug: string; children: ReactNode }) {
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="stack" style={{ marginBottom: 20 }}>
          <span className="badge">{tenantSlug}</span>
          <strong>Saguaro CRM</strong>
          <span className="muted">White-label construction ops</span>
        </div>
        <nav>
          {mainLinks.map(([label, path]) => (
            <Link key={path} href={`/${tenantSlug}/${path}`}>
              {label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="content">{children}</main>
    </div>
  );
}
