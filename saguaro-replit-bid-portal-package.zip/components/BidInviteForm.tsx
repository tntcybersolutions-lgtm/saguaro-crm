'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export function BidInviteForm({
  tenantId,
  tenantSlug,
  projectId,
  bidPackageId,
}: {
  tenantId: string;
  tenantSlug: string;
  projectId: string;
  bidPackageId: string;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [inviteUrl, setInviteUrl] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setLoading(true);
    setError(null);
    setInviteUrl(null);

    const body = {
      tenantId,
      tenantSlug,
      projectId,
      bidPackageId,
      companyName: String(formData.get('companyName') ?? ''),
      email: String(formData.get('email') ?? ''),
      contactName: String(formData.get('contactName') ?? ''),
      phone: String(formData.get('phone') ?? ''),
    };

    const response = await fetch('/api/bid-invites', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setError(result.error ?? 'Invite failed.');
      setLoading(false);
      return;
    }

    setInviteUrl(result.inviteUrl ?? null);
    setLoading(false);
    router.refresh();
  }

  async function copyLink() {
    if (!inviteUrl) return;
    await navigator.clipboard.writeText(inviteUrl);
  }

  return (
    <form action={handleSubmit} className="card stack">
      <strong>Invite subcontractor</strong>
      <div className="grid two">
        <label className="stack">
          <span>Company name</span>
          <input name="companyName" placeholder="Acme Concrete" required />
        </label>
        <label className="stack">
          <span>Invite email</span>
          <input name="email" type="email" placeholder="estimating@acmeconcrete.com" required />
        </label>
      </div>
      <div className="grid two">
        <label className="stack">
          <span>Contact name</span>
          <input name="contactName" placeholder="Jane Estimator" />
        </label>
        <label className="stack">
          <span>Phone</span>
          <input name="phone" placeholder="602-555-0100" />
        </label>
      </div>
      {error ? <div className="error">{error}</div> : null}
      {inviteUrl ? (
        <div className="notice stack">
          <strong>Invite created</strong>
          <div style={{ wordBreak: 'break-all' }}>{inviteUrl}</div>
          <div className="row">
            <button type="button" className="secondary" onClick={copyLink}>Copy invite link</button>
          </div>
        </div>
      ) : null}
      <div className="row">
        <button type="submit" disabled={loading}>{loading ? 'Creating invite…' : 'Create invite link'}</button>
      </div>
    </form>
  );
}
