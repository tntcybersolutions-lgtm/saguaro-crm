import type { ReactNode } from 'react';
export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="section-header">
      <div>
        <h1 style={{ margin: '0 0 6px' }}>{title}</h1>
        {description ? <p className="muted" style={{ margin: 0 }}>{description}</p> : null}
      </div>
      {actions ? <div>{actions}</div> : null}
    </div>
  );
}
