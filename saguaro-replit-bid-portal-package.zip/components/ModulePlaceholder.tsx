import { PageHeader } from '@/components/PageHeader';
import { EmptyState } from '@/components/EmptyState';

export function ModulePlaceholder({
  title,
  description,
  hint,
}: {
  title: string;
  description: string;
  hint?: string;
}) {
  return (
    <div className="stack">
      <PageHeader title={title} description={description} />
      <EmptyState
        title={`${title} scaffold is in place`}
        description={hint ?? 'This route is organized and ready for the next implementation pass.'}
      />
    </div>
  );
}
