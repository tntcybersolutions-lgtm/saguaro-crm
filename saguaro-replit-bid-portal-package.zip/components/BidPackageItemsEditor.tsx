'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export function BidPackageItemsEditor({ tenantId, bidPackageId }: { tenantId: string; bidPackageId: string }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(formData: FormData) {
    setLoading(true);
    setError(null);

    const body = {
      tenantId,
      bidPackageId,
      code: String(formData.get('code') ?? ''),
      title: String(formData.get('title') ?? ''),
      description: String(formData.get('description') ?? ''),
      uom: String(formData.get('uom') ?? ''),
      quantity: Number(formData.get('quantity') ?? 0),
    };

    const response = await fetch('/api/bid-package-items', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setError(result.error ?? 'Could not add bid item.');
      setLoading(false);
      return;
    }

    (document.getElementById('bid-item-form') as HTMLFormElement | null)?.reset();
    setLoading(false);
    router.refresh();
  }

  return (
    <form id="bid-item-form" action={handleSubmit} className="card stack">
      <strong>Add scope item</strong>
      <div className="grid three">
        <label className="stack">
          <span>Code</span>
          <input name="code" placeholder="03-3000" required />
        </label>
        <label className="stack">
          <span>UOM</span>
          <input name="uom" placeholder="LS / EA / CY" required />
        </label>
        <label className="stack">
          <span>Quantity</span>
          <input name="quantity" type="number" min="0" step="0.01" defaultValue="1" required />
        </label>
      </div>
      <label className="stack">
        <span>Title</span>
        <input name="title" placeholder="Slab on grade" required />
      </label>
      <label className="stack">
        <span>Description</span>
        <textarea name="description" placeholder="Reinforcing, vapor barrier, finish, cure" />
      </label>
      {error ? <div className="error">{error}</div> : null}
      <div className="row">
        <button type="submit" disabled={loading}>{loading ? 'Saving…' : 'Add item'}</button>
      </div>
    </form>
  );
}
