'use client';

import { useMemo, useState } from 'react';

type LineItem = {
  bidPackageItemId: string;
  code: string;
  title: string;
  description: string | null;
  uom: string;
  quantity: number;
  unitPrice: number;
  included: boolean;
  leadTimeDays: number;
  notes: string;
};

type Attachment = {
  id: string;
  file_name: string;
  storage_path: string;
  created_at: string;
};

export function BidSubmissionEditor({
  submissionId,
  canEdit,
  initialStatus,
  initialContactName,
  initialContactEmail,
  initialContactPhone,
  initialNotes,
  initialItems,
  initialAttachments,
}: {
  submissionId: string;
  canEdit: boolean;
  initialStatus: string;
  initialContactName: string;
  initialContactEmail: string;
  initialContactPhone: string;
  initialNotes: string;
  initialItems: LineItem[];
  initialAttachments: Attachment[];
}) {
  const [status, setStatus] = useState(initialStatus);
  const [contactName, setContactName] = useState(initialContactName);
  const [contactEmail, setContactEmail] = useState(initialContactEmail);
  const [contactPhone, setContactPhone] = useState(initialContactPhone);
  const [notes, setNotes] = useState(initialNotes);
  const [items, setItems] = useState(initialItems);
  const [attachments, setAttachments] = useState(initialAttachments);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const total = useMemo(
    () => items.reduce((sum, item) => sum + (item.included ? item.quantity * item.unitPrice : 0), 0),
    [items],
  );

  function updateItem(index: number, patch: Partial<LineItem>) {
    setItems((current) => current.map((item, i) => (i === index ? { ...item, ...patch } : item)));
  }

  async function save(nextAction: 'draft' | 'submitted') {
    setSaving(true);
    setError(null);
    setMessage(null);

    const response = await fetch(`/api/portal/submissions/${submissionId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: nextAction,
        contactName,
        contactEmail,
        contactPhone,
        notes,
        items,
      }),
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setError(result.error ?? 'Could not save submission.');
      setSaving(false);
      return;
    }

    setStatus(result.submission?.status ?? nextAction);
    setMessage(nextAction === 'submitted' ? 'Bid submitted.' : 'Draft saved.');
    setSaving(false);
  }

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(true);
    setError(null);
    setMessage(null);

    const formData = new FormData();
    Array.from(files).forEach((file) => formData.append('files', file));

    const response = await fetch(`/api/portal/submissions/${submissionId}/attachments`, {
      method: 'POST',
      body: formData,
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setError(result.error ?? 'Could not upload documents.');
      setUploading(false);
      return;
    }

    setAttachments((current) => [...current, ...(result.documents ?? [])]);
    setMessage('Documents uploaded.');
    setUploading(false);
  }

  return (
    <div className="stack">
      <div className="card stack">
        <div className="row">
          <span className="badge">Status: {status}</span>
          <strong>Total: ${total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
        </div>
        <div className="grid three">
          <label className="stack">
            <span>Contact name</span>
            <input value={contactName} onChange={(event) => setContactName(event.target.value)} disabled={!canEdit} />
          </label>
          <label className="stack">
            <span>Contact email</span>
            <input value={contactEmail} onChange={(event) => setContactEmail(event.target.value)} disabled={!canEdit} />
          </label>
          <label className="stack">
            <span>Contact phone</span>
            <input value={contactPhone} onChange={(event) => setContactPhone(event.target.value)} disabled={!canEdit} />
          </label>
        </div>
        <label className="stack">
          <span>Submission notes</span>
          <textarea value={notes} onChange={(event) => setNotes(event.target.value)} disabled={!canEdit} />
        </label>
      </div>

      <div className="card stack">
        <strong>Bid line items</strong>
        <div style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr>
                <th>Include</th>
                <th>Item</th>
                <th>Qty</th>
                <th>UOM</th>
                <th>Unit price</th>
                <th>Lead time</th>
                <th>Notes</th>
                <th>Line total</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, index) => (
                <tr key={item.bidPackageItemId}>
                  <td>
                    <input
                      type="checkbox"
                      checked={item.included}
                      onChange={(event) => updateItem(index, { included: event.target.checked })}
                      disabled={!canEdit}
                    />
                  </td>
                  <td>
                    <div>
                      <strong>{item.code}</strong>
                    </div>
                    <div>{item.title}</div>
                    {item.description ? <div className="muted">{item.description}</div> : null}
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      value={item.quantity}
                      onChange={(event) => updateItem(index, { quantity: Number(event.target.value) })}
                      disabled={!canEdit}
                    />
                  </td>
                  <td>{item.uom}</td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      value={item.unitPrice}
                      onChange={(event) => updateItem(index, { unitPrice: Number(event.target.value) })}
                      disabled={!canEdit}
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="1"
                      value={item.leadTimeDays}
                      onChange={(event) => updateItem(index, { leadTimeDays: Number(event.target.value) })}
                      disabled={!canEdit}
                    />
                  </td>
                  <td>
                    <textarea
                      value={item.notes}
                      onChange={(event) => updateItem(index, { notes: event.target.value })}
                      disabled={!canEdit}
                    />
                  </td>
                  <td>
                    ${item.included ? (item.quantity * item.unitPrice).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card stack">
        <strong>Attachments</strong>
        {attachments.length === 0 ? <div className="muted">No documents uploaded yet.</div> : null}
        {attachments.length > 0 ? (
          <ul>
            {attachments.map((attachment) => (
              <li key={attachment.id}>
                {attachment.file_name} <span className="muted">({attachment.storage_path})</span>
              </li>
            ))}
          </ul>
        ) : null}
        <label className="stack">
          <span>Upload documents</span>
          <input type="file" multiple disabled={!canEdit || uploading} onChange={(event) => handleFiles(event.target.files)} />
        </label>
      </div>

      {message ? <div className="success">{message}</div> : null}
      {error ? <div className="error">{error}</div> : null}

      {canEdit ? (
        <div className="row">
          <button type="button" className="secondary" disabled={saving} onClick={() => save('draft')}>
            {saving ? 'Saving…' : 'Save draft'}
          </button>
          <button type="button" disabled={saving} onClick={() => save('submitted')}>
            {saving ? 'Submitting…' : 'Submit bid'}
          </button>
        </div>
      ) : (
        <div className="notice">This submission is locked.</div>
      )}
    </div>
  );
}
