import Link from 'next/link';
import type { ReactNode } from 'react';

const mobileLinks = [
  ['Home', ''],
  ['Photos', 'photos'],
  ['Logs', 'daily-logs'],
  ['Issues', 'field-issues'],
  ['Schedule', 'schedule'],
  ['Inspect', 'inspections'],
];

export function MobileFieldShell({
  tenantSlug,
  projectId,
  children,
}: {
  tenantSlug: string;
  projectId: string;
  children: ReactNode;
}) {
  return (
    <main className="container" style={{ padding: '20px 0 48px' }}>
      <div className="card stack">
        <strong>Mobile Field Portal</strong>
        <div className="row">
          {mobileLinks.map(([label, path]) => {
            const href = path
              ? `/${tenantSlug}/mobile/${projectId}/${path}`
              : `/${tenantSlug}/mobile/${projectId}`;
            return (
              <Link key={path || 'home'} href={href}>
                {label}
              </Link>
            );
          })}
        </div>
      </div>
      <div style={{ marginTop: 16 }}>{children}</div>
    </main>
  );
}
