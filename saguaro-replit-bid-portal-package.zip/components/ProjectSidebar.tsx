import Link from 'next/link';

const projectLinks = [
  ['Overview', ''],
  ['Autopilot', 'autopilot'],
  ['Drawings', 'drawings'],
  ['Photos', 'photos'],
  ['RFIs', 'rfis'],
  ['Files', 'files'],
  ['Invoices', 'invoices'],
  ['Change Orders', 'change-orders'],
  ['Bid Packages', 'bid-packages'],
  ['Schedule', 'schedule'],
  ['Permits', 'permits'],
  ['Inspections', 'inspections'],
  ['Daily Logs', 'daily-logs'],
  ['Field Issues', 'field-issues'],
  ['Bid Leveling', 'bid-leveling'],
  ['Autopilot Alerts', 'autopilot-alerts'],
];

export function ProjectSidebar({ tenantSlug, projectId }: { tenantSlug: string; projectId: string }) {
  return (
    <aside className="card" style={{ marginBottom: 16 }}>
      <div className="stack">
        <strong>Project Navigation</strong>
        <div className="grid two">
          {projectLinks.map(([label, path]) => {
            const href = path
              ? `/${tenantSlug}/app/projects/${projectId}/${path}`
              : `/${tenantSlug}/app/projects/${projectId}`;
            return (
              <Link key={path || 'home'} href={href}>
                {label}
              </Link>
            );
          })}
        </div>
      </div>
    </aside>
  );
}
