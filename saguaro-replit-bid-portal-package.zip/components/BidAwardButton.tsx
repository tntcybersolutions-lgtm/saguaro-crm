'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export function BidAwardButton({ bidPackageId, submissionId }: { bidPackageId: string; submissionId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleClick() {
    setLoading(true);
    setError(null);

    const response = await fetch('/api/bid-awards', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bidPackageId, submissionId }),
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setError(result.error ?? 'Award failed.');
      setLoading(false);
      return;
    }

    setLoading(false);
    router.refresh();
  }

  return (
    <div className="stack">
      <button type="button" onClick={handleClick} disabled={loading}>
        {loading ? 'Awarding…' : 'Award bid'}
      </button>
      {error ? <span className="error">{error}</span> : null}
    </div>
  );
}
