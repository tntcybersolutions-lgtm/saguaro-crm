'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export function BidPackageCreateForm({ tenantId, tenantSlug, projectId }: { tenantId: string; tenantSlug: string; projectId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setLoading(true);
    setError(null);

    const body = {
      tenantId,
      tenantSlug,
      projectId,
      code: String(formData.get('code') ?? ''),
      name: String(formData.get('name') ?? ''),
      description: String(formData.get('description') ?? ''),
      dueAt: String(formData.get('dueAt') ?? ''),
    };

    const response = await fetch('/api/bid-packages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const result = await response.json().catch(() => ({}));

    if (!response.ok) {
      setError(result.error ?? 'Could not create bid package.');
      setLoading(false);
      return;
    }

    router.push(`/${tenantSlug}/app/projects/${projectId}/bid-packages/${result.bidPackage.id}`);
    router.refresh();
  }

  return (
    <form action={handleSubmit} className="card stack">
      <strong>Create bid package</strong>
      <div className="grid two">
        <label className="stack">
          <span>Package code</span>
          <input name="code" placeholder="BP-001" required />
        </label>
        <label className="stack">
          <span>Due at</span>
          <input name="dueAt" type="datetime-local" />
        </label>
      </div>
      <label className="stack">
        <span>Name</span>
        <input name="name" placeholder="Concrete scope" required />
      </label>
      <label className="stack">
        <span>Description</span>
        <textarea name="description" placeholder="Scope, inclusions, alternates, clarifications" />
      </label>
      {error ? <div className="error">{error}</div> : null}
      <div className="row">
        <button type="submit" disabled={loading}>{loading ? 'Creating…' : 'Create package'}</button>
      </div>
    </form>
  );
}
