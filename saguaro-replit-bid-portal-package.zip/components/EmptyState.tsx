export function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="card stack">
      <strong>{title}</strong>
      <p className="muted" style={{ margin: 0 }}>{description}</p>
    </div>
  );
}
